package com.speakercorepurger.app.audio

import com.speakercorepurger.app.data.CheckQualityLevel
import com.speakercorepurger.app.data.CheckQualityReason
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthQualityAnalyzerTest {

    @Test
    fun quietConsistentUnclippedRecordingIsGood() {
        val result = HealthQualityAnalyzer.classify(metrics())

        assertEquals(CheckQualityLevel.GOOD, result.level)
        assertTrue(result.reasons.isEmpty())
    }

    @Test
    fun moderateRoomNoiseMakesResultUsable() {
        val result = HealthQualityAnalyzer.classify(metrics(roomNoiseDbfs = -40f))

        assertEquals(CheckQualityLevel.USABLE, result.level)
        assertTrue(CheckQualityReason.ROOM_NOISE in result.reasons)
    }

    @Test
    fun veryLoudRoomNoiseRecommendsRetry() {
        val result = HealthQualityAnalyzer.classify(metrics(roomNoiseDbfs = -28f))

        assertEquals(CheckQualityLevel.RETRY_RECOMMENDED, result.level)
        assertTrue(CheckQualityReason.ROOM_NOISE in result.reasons)
    }

    @Test
    fun weakRepeatedSignalsAndLargeDifferencesRecommendRetry() {
        val result = HealthQualityAnalyzer.classify(
            metrics(
                repeatedToneSnrDb = listOf(4f, 25f),
                repeatDifferenceDb = listOf(8f, 1f),
            ),
        )

        assertEquals(CheckQualityLevel.RETRY_RECOMMENDED, result.level)
        assertTrue(CheckQualityReason.LOW_SIGNAL in result.reasons)
        assertTrue(CheckQualityReason.REPEAT_VARIATION in result.reasons)
    }

    @Test
    fun smallRepeatDifferenceRemainsGoodButModerateDifferenceIsUsable() {
        val good = HealthQualityAnalyzer.classify(metrics(repeatDifferenceDb = listOf(2.9f, 2f)))
        val usable = HealthQualityAnalyzer.classify(metrics(repeatDifferenceDb = listOf(3.1f, 2f)))

        assertEquals(CheckQualityLevel.GOOD, good.level)
        assertEquals(CheckQualityLevel.USABLE, usable.level)
        assertTrue(CheckQualityReason.REPEAT_VARIATION in usable.reasons)
    }

    @Test
    fun clippedOrIncompleteCaptureRecommendsRetry() {
        val clipped = HealthQualityAnalyzer.classify(metrics(clippedFraction = 0.01f))
        val incomplete = HealthQualityAnalyzer.classify(metrics(completeCapture = false))

        assertEquals(CheckQualityLevel.RETRY_RECOMMENDED, clipped.level)
        assertTrue(CheckQualityReason.RECORDING_CLIPPED in clipped.reasons)
        assertEquals(CheckQualityLevel.RETRY_RECOMMENDED, incomplete.level)
        assertTrue(CheckQualityReason.INCOMPLETE_CAPTURE in incomplete.reasons)
    }

    @Test
    fun missingRepeatMeasurementsCannotBeMarkedGood() {
        val result = HealthQualityAnalyzer.classify(
            metrics(repeatedToneSnrDb = emptyList(), repeatDifferenceDb = emptyList()),
        )

        assertEquals(CheckQualityLevel.RETRY_RECOMMENDED, result.level)
        assertTrue(CheckQualityReason.INCOMPLETE_CAPTURE in result.reasons)
    }

    private fun metrics(
        roomNoiseDbfs: Float = -55f,
        repeatedToneSnrDb: List<Float> = listOf(24f, 26f),
        repeatDifferenceDb: List<Float> = listOf(1f, 2f),
        clippedFraction: Float = 0f,
        completeCapture: Boolean = true,
    ) = HealthQualityMetrics(
        roomNoiseDbfs = roomNoiseDbfs,
        repeatedToneSnrDb = repeatedToneSnrDb,
        repeatDifferenceDb = repeatDifferenceDb,
        clippedFraction = clippedFraction,
        completeCapture = completeCapture,
    )
}
