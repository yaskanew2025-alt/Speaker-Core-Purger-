package com.speakercorepurger.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class HealthResultQualityCodecTest {

    private val bands = listOf(
        HealthBand(hz = 250, peakDb = -21.5f, snrDb = 28.4f),
        HealthBand(hz = 500, peakDb = -20f, snrDb = 25f),
    )

    @Test
    fun oldSavedFormatStillDecodesWithoutQuality() {
        val result = HealthResult.decode("1700000000000;250,-21.5,28.4|500,-20.0,25.0")

        assertNotNull(result)
        assertNull(result?.quality)
        assertEquals(bands, result?.bands)
    }

    @Test
    fun qualityAndBandsSurviveRoundTrip() {
        val quality = CheckQuality(
            CheckQualityLevel.USABLE,
            listOf(CheckQualityReason.ROOM_NOISE, CheckQualityReason.REPEAT_VARIATION),
        )
        val result = HealthResult(1_700_000_000_000, bands, quality)

        assertEquals(result, HealthResult.decode(result.encode()))
    }

    @Test
    fun malformedQualityDoesNotDiscardLegacyMeasurements() {
        val result = HealthResult.decode("1700000000000;250,-21.5,28.4;q2|EXCELLENT|-")

        assertNotNull(result)
        assertEquals(bands.first(), result?.bands?.first())
        assertNull(result?.quality)
    }
}
