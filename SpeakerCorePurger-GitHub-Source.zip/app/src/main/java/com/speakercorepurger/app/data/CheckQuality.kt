package com.speakercorepurger.app.data

/** Reliability of one speaker health measurement, separate from the speaker score itself. */
enum class CheckQualityLevel {
    GOOD,
    USABLE,
    RETRY_RECOMMENDED,
}

/** Machine-readable reasons shown in the health result and shared report. */
enum class CheckQualityReason {
    ROOM_NOISE,
    LOW_SIGNAL,
    REPEAT_VARIATION,
    RECORDING_CLIPPED,
    INCOMPLETE_CAPTURE,
}

data class CheckQuality(
    val level: CheckQualityLevel,
    val reasons: List<CheckQualityReason>,
)
