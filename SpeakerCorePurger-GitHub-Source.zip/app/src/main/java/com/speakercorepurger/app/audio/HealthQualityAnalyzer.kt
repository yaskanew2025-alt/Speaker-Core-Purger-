package com.speakercorepurger.app.audio

import com.speakercorepurger.app.data.CheckQuality
import com.speakercorepurger.app.data.CheckQualityLevel
import com.speakercorepurger.app.data.CheckQualityReason
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.sqrt

data class HealthQualityMetrics(
    val roomNoiseDbfs: Float,
    val repeatedToneSnrDb: List<Float>,
    val repeatDifferenceDb: List<Float>,
    val clippedFraction: Float,
    val completeCapture: Boolean,
)

/**
 * Assesses whether the conditions were consistent enough to trust the score. These are relative
 * microphone measurements, not calibrated room-noise or sound-pressure measurements.
 */
object HealthQualityAnalyzer {
    private const val FRAME = 4_096
    private const val HOP = 2_048
    private const val ROOM_NOISE_USABLE_DBFS = -42f
    private const val ROOM_NOISE_RETRY_DBFS = -30f
    private const val REPEAT_USABLE_DB = 3f
    private const val REPEAT_RETRY_DB = 6f
    private const val LOW_SIGNAL_USABLE_SNR_DB = 10f
    private const val LOW_SIGNAL_RETRY_SNR_DB = 5f
    private const val CLIPPED_USABLE_FRACTION = 0.001f
    private const val CLIPPED_RETRY_FRACTION = 0.005f
    private const val CLIP_SAMPLE = 32_760

    fun analyze(
        samples: ShortArray,
        count: Int,
        sampleRate: Int = HealthAnalyzer.SAMPLE_RATE,
    ): CheckQuality {
        require(count in 0..samples.size) { "count out of range" }
        require(sampleRate > 0) { "sampleRate must be positive" }

        val baselineEnd = minOf(count, (HealthCheckSpec.BASELINE_SEC * sampleRate).toInt())
        val roomNoiseDbfs = rmsDbfs(samples, 0, baselineEnd)
        val clippedCount = (0 until count).count { abs(samples[it].toInt()) >= CLIP_SAMPLE }
        val clippedFraction = if (count == 0) 0f else clippedCount.toFloat() / count
        val completeCapture = count >= (
            (HealthCheckSpec.LEAD_IN_SEC +
                (HealthCheckSpec.PLAYBACK_HZ.size - 1) * HealthCheckSpec.STEP_SEC +
                HealthCheckSpec.TONE_SEC) * sampleRate
            ).toInt()

        val repeatSnrs = mutableListOf<Float>()
        val repeatDifferences = mutableListOf<Float>()
        for ((firstIndex, secondIndex) in HealthCheckSpec.REPEAT_PAIRS) {
            val hz = HealthCheckSpec.PLAYBACK_HZ[firstIndex]
            val firstDb = tonePeakDb(samples, count, firstIndex, hz, sampleRate)
            val secondDb = tonePeakDb(samples, count, secondIndex, hz, sampleRate)
            val roomToneDb = tonePeakDb(samples, baselineEnd, null, hz, sampleRate)
            repeatSnrs += minOf(firstDb, secondDb) - roomToneDb
            repeatDifferences += abs(firstDb - secondDb)
        }

        return classify(
            HealthQualityMetrics(
                roomNoiseDbfs = roomNoiseDbfs,
                repeatedToneSnrDb = repeatSnrs,
                repeatDifferenceDb = repeatDifferences,
                clippedFraction = clippedFraction,
                completeCapture = completeCapture,
            ),
        )
    }

    fun classify(metrics: HealthQualityMetrics): CheckQuality {
        val reasons = linkedSetOf<CheckQualityReason>()
        val repeatsComplete =
            metrics.repeatedToneSnrDb.size == HealthCheckSpec.REPEAT_PAIRS.size &&
                metrics.repeatDifferenceDb.size == HealthCheckSpec.REPEAT_PAIRS.size
        var retry = !metrics.completeCapture || !repeatsComplete
        var usable = false

        if (!metrics.completeCapture || !repeatsComplete) {
            reasons += CheckQualityReason.INCOMPLETE_CAPTURE
        }

        if (metrics.roomNoiseDbfs >= ROOM_NOISE_USABLE_DBFS) {
            reasons += CheckQualityReason.ROOM_NOISE
            usable = true
            if (metrics.roomNoiseDbfs >= ROOM_NOISE_RETRY_DBFS) retry = true
        }

        if (metrics.repeatedToneSnrDb.any { it < LOW_SIGNAL_USABLE_SNR_DB }) {
            reasons += CheckQualityReason.LOW_SIGNAL
            usable = true
            if (metrics.repeatedToneSnrDb.any { it < LOW_SIGNAL_RETRY_SNR_DB }) retry = true
        }

        if (metrics.repeatDifferenceDb.any { it > REPEAT_USABLE_DB }) {
            reasons += CheckQualityReason.REPEAT_VARIATION
            usable = true
            if (metrics.repeatDifferenceDb.any { it > REPEAT_RETRY_DB }) retry = true
        }

        if (metrics.clippedFraction >= CLIPPED_USABLE_FRACTION) {
            reasons += CheckQualityReason.RECORDING_CLIPPED
            usable = true
            if (metrics.clippedFraction >= CLIPPED_RETRY_FRACTION) retry = true
        }

        val level = when {
            retry -> CheckQualityLevel.RETRY_RECOMMENDED
            usable -> CheckQualityLevel.USABLE
            else -> CheckQualityLevel.GOOD
        }
        return CheckQuality(level, reasons.toList())
    }

    private fun rmsDbfs(samples: ShortArray, start: Int, end: Int): Float {
        if (end <= start) return -120f
        var sumSquares = 0.0
        for (index in start until end) {
            val normalized = samples[index] / 32_768.0
            sumSquares += normalized * normalized
        }
        val rms = sqrt(sumSquares / (end - start))
        return (20.0 * log10(rms + 1e-9)).toFloat()
    }

    /**
     * Finds the strongest Goertzel frame inside one expected tone slot. A null slot index means
     * analyze the supplied range directly (used for the quiet lead-in).
     */
    private fun tonePeakDb(
        samples: ShortArray,
        count: Int,
        slotIndex: Int?,
        hz: Int,
        sampleRate: Int,
    ): Float {
        val slotStart = if (slotIndex == null) {
            0
        } else {
            ((HealthCheckSpec.LEAD_IN_SEC + slotIndex * HealthCheckSpec.STEP_SEC + 0.12) * sampleRate).toInt()
        }
        val slotEnd = if (slotIndex == null) {
            minOf(count, (HealthCheckSpec.BASELINE_SEC * sampleRate).toInt())
        } else {
            ((HealthCheckSpec.LEAD_IN_SEC + slotIndex * HealthCheckSpec.STEP_SEC +
                HealthCheckSpec.TONE_SEC - 0.08) * sampleRate).toInt().coerceAtMost(count)
        }
        if (slotEnd - slotStart < FRAME || slotStart < 0 || slotEnd > count) return -120f

        val window = DoubleArray(FRAME) { 0.5 - 0.5 * cos(2.0 * PI * it / (FRAME - 1)) }
        val windowSum = window.sum()
        val coefficient = 2.0 * cos(2.0 * PI * hz / sampleRate)
        var peak = 0.0
        var start = slotStart
        while (start + FRAME <= slotEnd) {
            var s1 = 0.0
            var s2 = 0.0
            for (offset in 0 until FRAME) {
                val s0 = samples[start + offset] * window[offset] + coefficient * s1 - s2
                s2 = s1
                s1 = s0
            }
            val power = (s1 * s1 + s2 * s2 - coefficient * s1 * s2).coerceAtLeast(0.0)
            val amplitude = 2.0 * sqrt(power) / windowSum / 32_768.0
            peak = maxOf(peak, amplitude)
            start += HOP
        }
        return (20.0 * log10(peak + 1e-9)).toFloat()
    }
}
