# Speaker Core Purger

Native Android app (Kotlin, Jetpack Compose, Android 6.0+ / API 23 and newer) that clears water and dust
from the phone speaker with tuned tones and vibration. No WebView.

## Build the APK on GitHub (no Android Studio needed)

1. Create a GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab and run **Build Speaker Core Purger** (it also runs on every push).
3. When the run is green, open it and download the **SpeakerCorePurger-apks** artifact.
   `app-debug.apk` and `app-release.apk` are both installable.

## Add your real AdMob IDs

Never commit fake IDs. Either:

- edit `ads.properties` (four values: app ID, banner, interstitial, rewarded), or
- add GitHub repository secrets with the same names (`ADMOB_APP_ID`, `ADMOB_BANNER_ID`,
  `ADMOB_INTERSTITIAL_ID`, `ADMOB_REWARDED_ID`). Secrets override the file.

Any ad format whose ID is empty is switched off. If `ADMOB_APP_ID` is empty the ad SDK is never started.

Ads in the app: an adaptive banner, an interstitial after a finished purge (at most one every 3 minutes),
and a rewarded ad that unlocks the 5-minute purge for 24 hours. Consent (UMP) is shown where required.

## Release signing (optional, for Google Play)

Without a keystore the release APK is signed with the debug key, which is fine for installing but not for Play.
For Play, add secrets `KEYSTORE_BASE64`, `SIGNING_STORE_PASSWORD`, `SIGNING_KEY_ALIAS`, `SIGNING_KEY_PASSWORD`.

## Local build

Android Studio (Ladybug or newer, JDK 17): open this folder and run the `app` configuration, or `./gradlew assembleDebug`.
