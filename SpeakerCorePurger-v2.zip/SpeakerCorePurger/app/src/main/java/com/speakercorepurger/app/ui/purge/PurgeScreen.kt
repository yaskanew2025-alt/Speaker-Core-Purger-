package com.speakercorepurger.app.ui.purge

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.speakercorepurger.app.R
import com.speakercorepurger.app.ads.AdsManager
import com.speakercorepurger.app.audio.CUSTOM_MAX_HZ
import com.speakercorepurger.app.audio.CUSTOM_MIN_HZ
import com.speakercorepurger.app.audio.EXTENDED_DURATION_SEC
import com.speakercorepurger.app.audio.PURGE_DURATIONS_SEC
import com.speakercorepurger.app.audio.PurgeMode
import com.speakercorepurger.app.ui.PurgeMessage
import com.speakercorepurger.app.ui.PurgePhase
import com.speakercorepurger.app.ui.PurgeUiState
import com.speakercorepurger.app.ui.PurgeViewModel
import com.speakercorepurger.app.ui.descriptionRes
import com.speakercorepurger.app.ui.durationLabel
import com.speakercorepurger.app.ui.findActivity
import com.speakercorepurger.app.ui.formatClock
import com.speakercorepurger.app.ui.textRes
import com.speakercorepurger.app.ui.titleRes
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

@Composable
fun PurgeScreen(
    vm: PurgeViewModel,
    ads: AdsManager,
    snackbarHostState: SnackbarHostState,
    modifier: Modifier = Modifier,
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Keep volume and audio-route info fresh while the screen is visible.
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refreshSystemState()
                delay(1_000)
            }
        }
    }

    val running = state.phase == PurgePhase.RUNNING
    DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }

    var showUnlockDialog by rememberSaveable { mutableStateOf(false) }
    val adNotReady = stringResource(R.string.unlock_not_ready)
    val unlocked = stringResource(R.string.unlock_success)
    val unlockFailed = stringResource(R.string.unlock_failed)

    fun watchAdToUnlock() {
        val activity = context.findActivity() ?: return
        if (!ads.rewardedLoaded.value) {
            scope.launch { snackbarHostState.showSnackbar(adNotReady) }
            return
        }
        ads.showRewarded(activity) { earned ->
            if (earned) {
                vm.unlockExtended()
                scope.launch { snackbarHostState.showSnackbar(unlocked) }
            } else {
                scope.launch { snackbarHostState.showSnackbar(unlockFailed) }
            }
        }
    }

    fun finishAndMaybeShowAd() {
        context.findActivity()?.let { ads.showInterstitialIfEligible(it) }
        vm.acknowledgeCompletion()
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        // Copy the constraints: nested layout scopes cannot read this scope's values directly.
        val availableWidth = maxWidth
        val availableHeight = maxHeight
        val wide = availableWidth >= 560.dp && availableWidth > availableHeight
        if (wide) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(32.dp),
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center,
                ) {
                    val orbSize = minOf(availableWidth / 2 - 48.dp, availableHeight - 32.dp, 360.dp).coerceAtLeast(160.dp)
                    OrbSection(state = state, size = orbSize)
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Header()
                    Controls(
                        state = state,
                        vm = vm,
                        onLockedDurationTapped = { showUnlockDialog = true },
                        onDone = ::finishAndMaybeShowAd,
                    )
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 560.dp)
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Header(modifier = Modifier.fillMaxWidth())
                    val orbSize = minOf(availableWidth - 32.dp, 300.dp).coerceAtLeast(160.dp)
                    OrbSection(state = state, size = orbSize)
                    Controls(
                        state = state,
                        vm = vm,
                        onLockedDurationTapped = { showUnlockDialog = true },
                        onDone = ::finishAndMaybeShowAd,
                    )
                }
            }
        }
    }

    if (showUnlockDialog) {
        AlertDialog(
            onDismissRequest = { showUnlockDialog = false },
            title = { Text(stringResource(R.string.unlock_title)) },
            text = { Text(stringResource(R.string.unlock_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showUnlockDialog = false
                        watchAdToUnlock()
                    },
                ) { Text(stringResource(R.string.unlock_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { showUnlockDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}

@Composable
private fun Header(modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.semantics { heading() },
        )
        Text(
            text = stringResource(R.string.purge_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun OrbSection(state: PurgeUiState, size: Dp) {
    val running = state.phase == PurgePhase.RUNNING
    val completed = state.phase == PurgePhase.COMPLETED
    val description = when {
        running -> stringResource(
            R.string.orb_desc_running,
            formatClock(state.remainingSec),
            state.frequencyHz,
        )
        completed -> stringResource(R.string.orb_desc_done)
        else -> stringResource(R.string.orb_desc_idle)
    }
    val checkScale by animateFloatAsState(
        targetValue = if (completed) 1f else 0.6f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "checkScale",
    )

    PurgeOrb(
        running = running,
        active = running || completed,
        progress = if (running || completed) state.progress else -1f,
        size = size,
        modifier = Modifier.semantics(mergeDescendants = true) { contentDescription = description },
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            when {
                running -> {
                    Text(
                        text = formatClock(state.remainingSec),
                        color = Color.White,
                        fontSize = (size.value * 0.15f).sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                    Text(
                        text = stringResource(R.string.orb_hz, state.frequencyHz),
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                    )
                }
                completed -> {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .size(size * 0.22f)
                            .scale(checkScale),
                    )
                    Text(
                        text = stringResource(R.string.orb_done),
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                }
                else -> {
                    Text(
                        text = stringResource(R.string.orb_ready),
                        color = Color.White,
                        fontSize = (size.value * 0.11f).sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                    Text(
                        text = durationLabel(state.durationSec),
                        color = Color.White.copy(alpha = 0.85f),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Controls(
    state: PurgeUiState,
    vm: PurgeViewModel,
    onLockedDurationTapped: () -> Unit,
    onDone: () -> Unit,
) {
    val running = state.phase == PurgePhase.RUNNING
    val completed = state.phase == PurgePhase.COMPLETED

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        state.message?.let { message ->
            MessageCard(message = message, onDismiss = vm::dismissMessage)
        }

        if (state.externalOutput && !running) {
            NoticeCard(
                title = stringResource(R.string.warn_headphones_title),
                body = stringResource(R.string.warn_headphones_body),
                isError = true,
            )
        }

        if (completed) {
            CompletedCard()
        }

        // Mode selection
        SectionTitle(stringResource(R.string.section_mode))
        Column(
            modifier = Modifier.selectableGroup(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            PurgeMode.entries.chunked(2).forEach { rowModes ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Max),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    rowModes.forEach { mode ->
                        ModeCard(
                            mode = mode,
                            selected = mode == state.mode,
                            enabled = !running,
                            onClick = { vm.selectMode(mode) },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                        )
                    }
                }
            }
        }

        AnimatedVisibility(visible = state.mode == PurgeMode.CUSTOM) {
            var draft by remember(state.customHz) { mutableFloatStateOf(state.customHz) }
            val logMin = ln(CUSTOM_MIN_HZ)
            val logMax = ln(CUSTOM_MAX_HZ)
            Column {
                Text(
                    text = stringResource(R.string.custom_frequency_label, draft.roundToInt()),
                    style = MaterialTheme.typography.titleSmall,
                )
                Slider(
                    value = (ln(draft) - logMin) / (logMax - logMin),
                    onValueChange = { draft = exp(logMin + it * (logMax - logMin)) },
                    onValueChangeFinished = { vm.setCustomHz(draft) },
                    valueRange = 0f..1f,
                    enabled = !running,
                    modifier = Modifier.semantics {
                        contentDescription = "${draft.roundToInt()} Hz"
                    },
                )
            }
        }

        // Duration
        SectionTitle(stringResource(R.string.section_duration))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            PURGE_DURATIONS_SEC.forEach { seconds ->
                val locked = seconds == EXTENDED_DURATION_SEC && state.extendedLocked
                FilterChip(
                    selected = state.durationSec == seconds,
                    onClick = { if (locked) onLockedDurationTapped() else vm.selectDuration(seconds) },
                    enabled = !running,
                    label = { Text(durationLabel(seconds)) },
                    leadingIcon = if (locked) {
                        {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = stringResource(R.string.cd_locked),
                                modifier = Modifier.size(FilterChipDefaults.IconSize),
                            )
                        }
                    } else {
                        null
                    },
                )
            }
        }

        // Volume
        VolumeSection(state = state, onMaximize = vm::maximizeVolume)

        // Primary actions
        when {
            running -> Button(
                onClick = vm::stop,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError,
                ),
            ) {
                Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(20.dp))
                Text(
                    text = stringResource(R.string.action_stop),
                    modifier = Modifier.padding(start = 8.dp),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
            completed -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onDone,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp),
                ) {
                    Text(stringResource(R.string.action_done), style = MaterialTheme.typography.titleMedium)
                }
                OutlinedButton(
                    onClick = vm::start,
                    enabled = !state.externalOutput,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp),
                ) {
                    Text(stringResource(R.string.action_again))
                }
            }
            else -> Button(
                onClick = vm::start,
                enabled = !state.externalOutput,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 56.dp),
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
                Text(
                    text = stringResource(R.string.action_start),
                    modifier = Modifier.padding(start = 8.dp),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
        }

        Text(
            text = stringResource(R.string.info_safety),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.semantics { heading() },
    )
}

@Composable
private fun ModeCard(
    mode: PurgeMode,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(16.dp)
    val scheme = MaterialTheme.colorScheme
    Card(
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (selected) scheme.primaryContainer else scheme.surfaceContainer,
            contentColor = if (selected) scheme.onPrimaryContainer else scheme.onSurface,
        ),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) scheme.primary else scheme.outlineVariant,
        ),
        modifier = modifier
            .alpha(if (enabled || selected) 1f else 0.6f)
            .clip(shape)
            .selectable(
                selected = selected,
                enabled = enabled,
                role = Role.RadioButton,
                onClick = onClick,
            ),
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(mode.titleRes()),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                if (selected) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
            Text(
                text = stringResource(mode.descriptionRes()),
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun VolumeSection(state: PurgeUiState, onMaximize: () -> Unit) {
    val percent = (state.volume * 100).roundToInt()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionTitle(stringResource(R.string.section_volume))
            Text(
                text = "$percent%",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(1f),
            )
        }
        LinearProgressIndicator(
            progress = { state.volume },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .semantics { contentDescription = "$percent%" },
        )
        if (state.autoMaxVolume) {
            Text(
                text = stringResource(R.string.info_auto_volume),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else if (state.volume < 0.99f && state.phase != PurgePhase.RUNNING) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.warn_volume_low),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = onMaximize) { Text(stringResource(R.string.action_set_max)) }
            }
        }
    }
}

@Composable
private fun MessageCard(message: PurgeMessage, onDismiss: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Warning, contentDescription = null)
            Text(
                text = stringResource(message.textRes()),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
            )
            IconButton(onClick = onDismiss) {
                Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.action_dismiss))
            }
        }
    }
}

@Composable
private fun NoticeCard(title: String, body: String, isError: Boolean) {
    val container = if (isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer
    val content = if (isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer
    Card(
        colors = CardDefaults.cardColors(containerColor = container, contentColor = content),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(if (isError) Icons.Filled.Warning else Icons.Filled.Info, contentDescription = null)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(body, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun CompletedCard() {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
            contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Filled.CheckCircle, contentDescription = null)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    stringResource(R.string.completed_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                )
                Text(stringResource(R.string.completed_body), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
