package com.speakercorepurger.app.audio

const val CUSTOM_MIN_HZ = 150f
const val CUSTOM_MAX_HZ = 10_000f
const val DEFAULT_CUSTOM_HZ = 1_000f

/** Allowed purge lengths in seconds. The last one is the "extended" length. */
val PURGE_DURATIONS_SEC = listOf(30, 60, 120, 300)
const val DEFAULT_DURATION_SEC = 60
const val FALLBACK_DURATION_SEC = 120
const val EXTENDED_DURATION_SEC = 300

/**
 * The sound programs the app can play. Each one has its own character (pulses, chirps, noise,
 * clipped bursts) instead of a smooth sweep, so they are easy to tell apart.
 */
enum class PurgeMode(val id: String) {
    /** Stepped, pulsed low and mid tones (150-800 Hz) to push water out. */
    WATER("water"),

    /** Fast high chirps (2-10 kHz) to shake dust loose. */
    DUST("dust"),

    /** 40-second cycle of water pulses, noise, dust chirps and power bursts. */
    DEEP("deep"),

    /** Very loud clipped bursts jumping across 150-10,000 Hz. */
    POWER("power"),

    /** Band-limited noise "shhh" in several bands. */
    NOISE("noise"),

    /** One steady tone (with harmonics) at a frequency chosen by the user. */
    CUSTOM("custom");

    fun createVoice(customHz: Float): Voice = when (this) {
        WATER -> WaterVoice()
        DUST -> DustVoice()
        DEEP -> DeepVoice()
        POWER -> PowerVoice()
        NOISE -> NoiseVoice()
        CUSTOM -> CustomVoice(customHz.toDouble())
    }

    /** Frequency shown at the start of a session. */
    fun frequencyAt(tSec: Double, customHz: Float): Double =
        createVoice(customHz).let { it.next(tSec); it.hz }

    companion object {
        fun fromId(id: String?): PurgeMode = entries.firstOrNull { it.id == id } ?: WATER
    }
}
