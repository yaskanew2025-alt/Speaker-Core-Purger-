package com.speakercorepurger.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.math.min

class AudioFailureException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * Streams a synthesized sound program to the phone's media output using [AudioTrack].
 *
 * [play] is cancellable: cancelling the calling coroutine fades the tone out over a few
 * milliseconds (to avoid a loud click) and releases the audio hardware.
 */
class ToneEngine {

    /**
     * Plays [mode] for [durationMs] milliseconds. Returns normally when the whole program
     * finished, throws [CancellationException] when stopped, and throws
     * [AudioFailureException] if the audio hardware could not be used.
     *
     * [onProgress] is invoked roughly ten times per second from a background thread.
     */
    suspend fun play(
        mode: PurgeMode,
        customHz: Float,
        durationMs: Long,
        onProgress: (playedMs: Long, hz: Float) -> Unit,
    ) = withContext(Dispatchers.Default) {
        val track = createTrack()
        val totalSamples = durationMs * SAMPLE_RATE / 1000L
        val buffer = ShortArray(CHUNK_SAMPLES)
        val voice = mode.createVoice(customHz)
        var lastHz = mode.frequencyAt(0.0, customHz)
        var written = 0L
        var lastReport = 0L

        try {
            track.play()
            while (written < totalSamples) {
                ensureActive()
                val count = min(CHUNK_SAMPLES.toLong(), totalSamples - written).toInt()
                for (i in 0 until count) {
                    val n = written + i
                    val raw = voice.next(n.toDouble() / SAMPLE_RATE)
                    lastHz = voice.hz
                    val gain = envelope(n, totalSamples) * AMPLITUDE
                    buffer[i] = (raw * gain).coerceIn(-1.0, 1.0).times(32767.0).toInt().toShort()
                }
                writeFully(track, buffer, count)
                written += count
                if (written - lastReport >= SAMPLE_RATE / 10) {
                    lastReport = written
                    onProgress(written * 1000L / SAMPLE_RATE, lastHz.toFloat())
                }
            }
            onProgress(durationMs, lastHz.toFloat())
            // In stream mode stop() lets already queued samples (which are faded to silence) finish.
            track.stop()
            Thread.sleep(TAIL_WAIT_MS)
        } catch (e: CancellationException) {
            withContext(NonCancellable) { fadeOut(track, voice, written) }
            throw e
        } finally {
            track.release()
        }
    }

    private fun createTrack(): AudioTrack {
        val minBuffer = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        if (minBuffer <= 0) throw AudioFailureException("Unsupported audio configuration ($minBuffer)")
        val bufferBytes = maxOf(minBuffer, CHUNK_SAMPLES * 2 * 2)

        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                )
                .setBufferSizeInBytes(bufferBytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            throw AudioFailureException("Could not create AudioTrack", e)
        }

        if (track.state != AudioTrack.STATE_INITIALIZED) {
            track.release()
            throw AudioFailureException("AudioTrack failed to initialize")
        }
        return track
    }

    private fun writeFully(track: AudioTrack, data: ShortArray, count: Int) {
        var offset = 0
        while (offset < count) {
            val result = track.write(data, offset, count - offset)
            when {
                result < 0 -> throw AudioFailureException("AudioTrack.write failed ($result)")
                result == 0 -> {
                    if (track.playState != AudioTrack.PLAYSTATE_PLAYING) {
                        throw AudioFailureException("AudioTrack stopped unexpectedly")
                    }
                    Thread.sleep(2)
                }
                else -> offset += result
            }
        }
    }

    /** Keeps the sound going for a few milliseconds while fading it out, so a manual stop does not click. */
    private fun fadeOut(track: AudioTrack, voice: Voice, startSample: Long) {
        try {
            val samples = SAMPLE_RATE * CANCEL_FADE_MS / 1000
            val data = ShortArray(samples)
            for (i in 0 until samples) {
                val raw = voice.next((startSample + i).toDouble() / SAMPLE_RATE)
                val gain = AMPLITUDE * (1.0 - i.toDouble() / samples)
                data[i] = (raw * gain).coerceIn(-1.0, 1.0).times(32767.0).toInt().toShort()
            }
            writeFully(track, data, samples)
            track.stop()
            Thread.sleep(TAIL_WAIT_MS)
        } catch (e: Exception) {
            // Best effort only; the track is released by the caller either way.
        }
    }

    private fun envelope(sampleIndex: Long, totalSamples: Long): Double {
        val fadeIn = if (sampleIndex < FADE_IN_SAMPLES) sampleIndex.toDouble() / FADE_IN_SAMPLES else 1.0
        val remaining = totalSamples - sampleIndex
        val fadeOut = if (remaining < FADE_OUT_SAMPLES) remaining.toDouble() / FADE_OUT_SAMPLES else 1.0
        return min(fadeIn, fadeOut)
    }

    private companion object {
        const val SAMPLE_RATE = 44_100
        const val CHUNK_SAMPLES = 1_024
        const val AMPLITUDE = 0.98
        const val FADE_IN_SAMPLES = SAMPLE_RATE * 150 / 1000
        const val FADE_OUT_SAMPLES = SAMPLE_RATE * 250 / 1000
        const val CANCEL_FADE_MS = 60
        const val TAIL_WAIT_MS = 120L
    }
}
