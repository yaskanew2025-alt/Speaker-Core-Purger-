package com.speakercorepurger.app.ui.purge

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private val DomeHiOn = Color(0xFF2A9CBF)
private val DomeMidOn = Color(0xFF0B5575)
private val DomeLowOn = Color(0xFF04202F)
private val DomeHiOff = Color(0xFF5C7384)
private val DomeMidOff = Color(0xFF3A4A58)
private val DomeLowOff = Color(0xFF1A232B)

/**
 * A lit, layered "speaker cone" drawn with gradients to give a soft 3D look:
 * ground shadow, bevelled housing, spherical dome with a specular highlight,
 * expanding sound ripples while running, and a progress ring.
 *
 * @param progress 0..1 for the ring, or a negative value to hide the ring.
 */
@Composable
fun PurgeOrb(
    running: Boolean,
    active: Boolean,
    progress: Float,
    size: Dp,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val scheme = MaterialTheme.colorScheme
    val domeHi by animateColorAsState(if (active) DomeHiOn else DomeHiOff, tween(400), label = "domeHi")
    val domeMid by animateColorAsState(if (active) DomeMidOn else DomeMidOff, tween(400), label = "domeMid")
    val domeLow by animateColorAsState(if (active) DomeLowOn else DomeLowOff, tween(400), label = "domeLow")
    val ringProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(180, easing = LinearEasing),
        label = "ring",
    )

    val ripple = remember { Animatable(0f) }
    LaunchedEffect(running) {
        if (running) {
            while (true) {
                ripple.snapTo(0f)
                ripple.animateTo(1f, tween(2400, easing = LinearEasing))
            }
        } else {
            ripple.snapTo(0f)
        }
    }

    val housingLight = lerp(scheme.surfaceContainerHighest, Color.White, 0.35f)
    val housingDark = lerp(scheme.surfaceContainerHighest, Color.Black, 0.45f)
    val trackColor = scheme.outlineVariant
    val ringColor = scheme.primary
    val rippleColor = scheme.primary
    val showRing = progress >= 0f

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val d = this.size.minDimension
            val c = center
            val outerR = d / 2f * 0.80f
            val domeR = outerR * 0.78f

            // Ground shadow
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Black.copy(alpha = 0.35f), Color.Transparent),
                    center = Offset(c.x, c.y + outerR * 0.96f),
                    radius = outerR * 0.9f,
                ),
                topLeft = Offset(c.x - outerR * 0.9f, c.y + outerR * 0.78f),
                size = Size(outerR * 1.8f, outerR * 0.36f),
            )

            // Ripples
            if (running) {
                val strokeWidth = 3.dp.toPx()
                for (i in 0..2) {
                    val p = (ripple.value + i / 3f) % 1f
                    val r = outerR + (d / 2f - outerR) * p
                    drawCircle(
                        color = rippleColor.copy(alpha = (1f - p) * 0.45f),
                        radius = r,
                        center = c,
                        style = Stroke(width = strokeWidth),
                    )
                }
            }

            // Housing (bevel)
            drawCircle(
                brush = Brush.linearGradient(
                    colors = listOf(housingLight, housingDark),
                    start = Offset(c.x - outerR, c.y - outerR),
                    end = Offset(c.x + outerR, c.y + outerR),
                ),
                radius = outerR,
                center = c,
            )
            // Inner groove
            drawCircle(color = Color.Black.copy(alpha = 0.40f), radius = outerR * 0.88f, center = c)

            // Dome with off-centre light source
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(domeHi, domeMid, domeLow),
                    center = Offset(c.x - domeR * 0.35f, c.y - domeR * 0.40f),
                    radius = domeR * 1.5f,
                ),
                radius = domeR,
                center = c,
            )
            // Fine concentric grille rings
            for (k in 1..3) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.07f),
                    radius = domeR * (0.25f * k + 0.1f),
                    center = c,
                    style = Stroke(width = 1.dp.toPx()),
                )
            }
            // Specular highlight
            drawOval(
                color = Color.White.copy(alpha = 0.22f),
                topLeft = Offset(c.x - domeR * 0.62f, c.y - domeR * 0.80f),
                size = Size(domeR * 0.9f, domeR * 0.42f),
            )

            // Progress ring
            if (showRing) {
                val arcR = outerR * 1.04f
                val arcTopLeft = Offset(c.x - arcR, c.y - arcR)
                val arcSize = Size(arcR * 2f, arcR * 2f)
                val width = 6.dp.toPx()
                drawArc(
                    color = trackColor,
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = arcTopLeft,
                    size = arcSize,
                    style = Stroke(width = width),
                )
                if (ringProgress > 0f) {
                    drawArc(
                        color = ringColor,
                        startAngle = -90f,
                        sweepAngle = 360f * ringProgress,
                        useCenter = false,
                        topLeft = arcTopLeft,
                        size = arcSize,
                        style = Stroke(width = width, cap = StrokeCap.Round),
                    )
                }
            }
        }
        content()
    }
}
