package com.speakercorepurger.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.speakercorepurger.app.audio.CUSTOM_MAX_HZ
import com.speakercorepurger.app.audio.CUSTOM_MIN_HZ
import com.speakercorepurger.app.audio.DEFAULT_CUSTOM_HZ
import com.speakercorepurger.app.audio.DEFAULT_DURATION_SEC
import com.speakercorepurger.app.audio.PURGE_DURATIONS_SEC
import com.speakercorepurger.app.audio.PurgeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val onboardingDone: Boolean = false,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val vibrate: Boolean = true,
    val autoMaxVolume: Boolean = true,
    val mode: PurgeMode = PurgeMode.WATER,
    val durationSec: Int = DEFAULT_DURATION_SEC,
    val customHz: Float = DEFAULT_CUSTOM_HZ,
    /** Epoch millis until which 5-minute purges stay unlocked after a rewarded ad. */
    val extendedUnlockedUntil: Long = 0L,
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val THEME = stringPreferencesKey("theme")
        val VIBRATE = booleanPreferencesKey("vibrate")
        val AUTO_MAX_VOLUME = booleanPreferencesKey("auto_max_volume")
        val MODE = stringPreferencesKey("mode")
        val DURATION = intPreferencesKey("duration_sec")
        val CUSTOM_HZ = floatPreferencesKey("custom_hz")
        val EXTENDED_UNTIL = longPreferencesKey("extended_unlocked_until")
    }

    val settings: Flow<AppSettings> = context.appDataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs ->
            val storedDuration = prefs[Keys.DURATION] ?: DEFAULT_DURATION_SEC
            AppSettings(
                onboardingDone = prefs[Keys.ONBOARDING_DONE] ?: false,
                theme = ThemeMode.entries.firstOrNull { it.name == prefs[Keys.THEME] } ?: ThemeMode.SYSTEM,
                vibrate = prefs[Keys.VIBRATE] ?: true,
                autoMaxVolume = prefs[Keys.AUTO_MAX_VOLUME] ?: true,
                mode = PurgeMode.fromId(prefs[Keys.MODE]),
                durationSec = if (storedDuration in PURGE_DURATIONS_SEC) storedDuration else DEFAULT_DURATION_SEC,
                customHz = (prefs[Keys.CUSTOM_HZ] ?: DEFAULT_CUSTOM_HZ).coerceIn(CUSTOM_MIN_HZ, CUSTOM_MAX_HZ),
                extendedUnlockedUntil = prefs[Keys.EXTENDED_UNTIL] ?: 0L,
            )
        }

    suspend fun setOnboardingDone(done: Boolean) {
        context.appDataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }

    suspend fun setTheme(theme: ThemeMode) {
        context.appDataStore.edit { it[Keys.THEME] = theme.name }
    }

    suspend fun setVibrate(enabled: Boolean) {
        context.appDataStore.edit { it[Keys.VIBRATE] = enabled }
    }

    suspend fun setAutoMaxVolume(enabled: Boolean) {
        context.appDataStore.edit { it[Keys.AUTO_MAX_VOLUME] = enabled }
    }

    suspend fun setMode(mode: PurgeMode) {
        context.appDataStore.edit { it[Keys.MODE] = mode.id }
    }

    suspend fun setDuration(seconds: Int) {
        if (seconds !in PURGE_DURATIONS_SEC) return
        context.appDataStore.edit { it[Keys.DURATION] = seconds }
    }

    suspend fun setCustomHz(hz: Float) {
        context.appDataStore.edit { it[Keys.CUSTOM_HZ] = hz.coerceIn(CUSTOM_MIN_HZ, CUSTOM_MAX_HZ) }
    }

    suspend fun setExtendedUnlockedUntil(epochMillis: Long) {
        context.appDataStore.edit { it[Keys.EXTENDED_UNTIL] = epochMillis }
    }
}
