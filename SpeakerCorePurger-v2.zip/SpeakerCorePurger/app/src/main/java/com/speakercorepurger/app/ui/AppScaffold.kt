package com.speakercorepurger.app.ui

import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.speakercorepurger.app.R
import com.speakercorepurger.app.ads.AdaptiveBanner
import com.speakercorepurger.app.ads.AdsManager
import com.speakercorepurger.app.ui.history.HistoryScreen
import com.speakercorepurger.app.ui.purge.PurgeScreen
import com.speakercorepurger.app.ui.settings.GuideScreen
import com.speakercorepurger.app.ui.settings.SettingsScreen

private object Routes {
    const val PURGE = "purge"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val GUIDE = "guide"
}

private data class TopLevelItem(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector,
)

private val topLevelItems = listOf(
    TopLevelItem(Routes.PURGE, R.string.nav_purge, Icons.Filled.PlayArrow),
    TopLevelItem(Routes.HISTORY, R.string.nav_history, Icons.Filled.DateRange),
    TopLevelItem(Routes.SETTINGS, R.string.nav_settings, Icons.Filled.Settings),
)

@Composable
fun AppScaffold(main: MainViewModel, purge: PurgeViewModel, ads: AdsManager) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val topLevel = route != null && topLevelItems.any { it.route == route }
    val snackbarHostState = remember { SnackbarHostState() }
    val adsReady by ads.ready.collectAsStateWithLifecycle()
    val showBanner = adsReady && ads.bannerConfigured

    fun navigateTopLevel(target: String) {
        navController.navigate(target) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBanner || topLevel) {
                Column {
                    if (showBanner) {
                        AdaptiveBanner(
                            adUnitId = ads.bannerUnitId,
                            modifier = if (topLevel) Modifier else Modifier.navigationBarsPadding(),
                        )
                    }
                    if (topLevel) {
                        NavigationBar {
                            topLevelItems.forEach { item ->
                                NavigationBarItem(
                                    selected = route == item.route,
                                    onClick = { if (route != item.route) navigateTopLevel(item.route) },
                                    icon = { Icon(item.icon, contentDescription = null) },
                                    label = { Text(stringResource(item.label)) },
                                )
                            }
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.PURGE,
            modifier = Modifier
                .padding(innerPadding)
                .consumeWindowInsets(innerPadding),
            enterTransition = { fadeIn(tween(220)) },
            exitTransition = { fadeOut(tween(160)) },
            popEnterTransition = { fadeIn(tween(220)) },
            popExitTransition = { fadeOut(tween(160)) },
        ) {
            composable(Routes.PURGE) {
                PurgeScreen(vm = purge, ads = ads, snackbarHostState = snackbarHostState)
            }
            composable(Routes.HISTORY) {
                HistoryScreen(vm = main, onStartPurge = { navigateTopLevel(Routes.PURGE) })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    vm = main,
                    ads = ads,
                    onOpenGuide = { navController.navigate(Routes.GUIDE) },
                )
            }
            composable(
                Routes.GUIDE,
                enterTransition = {
                    slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(280)) +
                        fadeIn(tween(280))
                },
                popExitTransition = {
                    slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(280)) +
                        fadeOut(tween(280))
                },
            ) {
                GuideScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
