package com.speakercorepurger.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore

/** Single Preferences DataStore shared by the settings and history repositories. */
internal val Context.appDataStore: DataStore<Preferences> by preferencesDataStore(name = "speaker_core_purger")
