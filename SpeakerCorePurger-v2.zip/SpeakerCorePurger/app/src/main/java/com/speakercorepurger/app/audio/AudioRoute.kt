package com.speakercorepurger.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Handle returned by [AudioRoute.requestFocus]; call [abandon] when finished. */
class AudioFocusHandle internal constructor(
    private val audioManager: AudioManager,
    private val listener: AudioManager.OnAudioFocusChangeListener,
    private val request: Any?,
) {
    @Suppress("DEPRECATION")
    fun abandon() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && request is AudioFocusRequest) {
            audioManager.abandonAudioFocusRequest(request)
        } else {
            audioManager.abandonAudioFocus(listener)
        }
    }
}

/** Helpers around audio output routing, volume and audio focus. */
object AudioRoute {

    private fun audioManager(context: Context): AudioManager =
        context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    /**
     * True when the media stream would be routed somewhere other than the phone's own speaker
     * (wired or Bluetooth headphones, USB audio, HDMI, ...).
     */
    fun externalOutputConnected(context: Context): Boolean {
        val devices = audioManager(context).getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        return devices.any { isExternal(it.type) }
    }

    private fun isExternal(type: Int): Boolean {
        when (type) {
            AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_LINE_ANALOG,
            AudioDeviceInfo.TYPE_LINE_DIGITAL,
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_HDMI,
            AudioDeviceInfo.TYPE_USB_DEVICE,
            AudioDeviceInfo.TYPE_USB_ACCESSORY,
            -> return true
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && type == AudioDeviceInfo.TYPE_USB_HEADSET) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && type == AudioDeviceInfo.TYPE_HEARING_AID) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            (type == AudioDeviceInfo.TYPE_BLE_HEADSET || type == AudioDeviceInfo.TYPE_BLE_SPEAKER)
        ) {
            return true
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && type == AudioDeviceInfo.TYPE_BLE_BROADCAST) {
            return true
        }
        return false
    }

    fun volumeFraction(context: Context): Float {
        val am = audioManager(context)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (max <= 0) return 0f
        return am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    /** Raises media volume to maximum. Returns the previous volume index, or null if unchanged. */
    fun raiseVolumeToMax(context: Context): Int? {
        val am = audioManager(context)
        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (current >= max) return null
        return try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0)
            current
        } catch (e: SecurityException) {
            null
        }
    }

    /** Restores [index] only if the volume is still at maximum (i.e. the user did not change it meanwhile). */
    fun restoreVolume(context: Context, index: Int) {
        val am = audioManager(context)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (am.getStreamVolume(AudioManager.STREAM_MUSIC) != max) return
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, index, 0)
        } catch (e: SecurityException) {
            // Ignore: some devices restrict volume changes (e.g. Do Not Disturb policies).
        }
    }

    /**
     * Requests transient audio focus. [onLost] is called on the main thread if another app
     * (for example an incoming call) takes the audio. Returns null if focus was refused.
     */
    @Suppress("DEPRECATION")
    fun requestFocus(context: Context, onLost: () -> Unit): AudioFocusHandle? {
        val am = audioManager(context)
        val listener = AudioManager.OnAudioFocusChangeListener { change ->
            if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                onLost()
            }
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                )
                .setOnAudioFocusChangeListener(listener)
                .build()
            if (am.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                AudioFocusHandle(am, listener, request)
            } else {
                null
            }
        } else {
            val result = am.requestAudioFocus(
                listener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT,
            )
            if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) AudioFocusHandle(am, listener, null) else null
        }
    }
}

/** Repeating gentle vibration pulses played alongside the tone to help shake dust loose. */
class PurgeVibrator(context: Context) {

    private val vibrator: Vibrator? = createVibrator(context.applicationContext)

    @Suppress("DEPRECATION")
    fun start() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val pattern = longArrayOf(0, 350, 150)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            v.vibrate(pattern, 0)
        }
    }

    fun stop() {
        vibrator?.cancel()
    }

    private companion object {
        @Suppress("DEPRECATION")
        fun createVibrator(context: Context): Vibrator? =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
    }
}
