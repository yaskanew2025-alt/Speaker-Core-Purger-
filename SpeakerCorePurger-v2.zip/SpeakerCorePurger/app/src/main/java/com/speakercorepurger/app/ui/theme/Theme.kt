package com.speakercorepurger.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF006A82),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFBDEBF7),
    onPrimaryContainer = Color(0xFF001F28),
    secondary = Color(0xFF4A6270),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCDE6F5),
    onSecondaryContainer = Color(0xFF051E2A),
    tertiary = Color(0xFF1B6B3F),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFC6F0D4),
    onTertiaryContainer = Color(0xFF00210F),
    background = Color(0xFFF4F8FB),
    onBackground = Color(0xFF111C22),
    surface = Color(0xFFF4F8FB),
    onSurface = Color(0xFF111C22),
    surfaceVariant = Color(0xFFDDE7ED),
    onSurfaceVariant = Color(0xFF3F4B52),
    outline = Color(0xFF6A7A84),
    outlineVariant = Color(0xFFC0CCD3),
    error = Color(0xFFB3261E),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B),
    surfaceBright = Color(0xFFF4F8FB),
    surfaceDim = Color(0xFFD3DBE0),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFEEF3F7),
    surfaceContainer = Color(0xFFE8EEF2),
    surfaceContainerHigh = Color(0xFFE2E9EE),
    surfaceContainerHighest = Color(0xFFDCE4E9),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF55D0EA),
    onPrimary = Color(0xFF003642),
    primaryContainer = Color(0xFF004E60),
    onPrimaryContainer = Color(0xFFBDEBF7),
    secondary = Color(0xFFB2CAD8),
    onSecondary = Color(0xFF1C333F),
    secondaryContainer = Color(0xFF334A56),
    onSecondaryContainer = Color(0xFFCDE6F5),
    tertiary = Color(0xFF7FD9A0),
    onTertiary = Color(0xFF00391F),
    tertiaryContainer = Color(0xFF00522F),
    onTertiaryContainer = Color(0xFFC6F0D4),
    background = Color(0xFF0B1217),
    onBackground = Color(0xFFDDE4E8),
    surface = Color(0xFF0B1217),
    onSurface = Color(0xFFDDE4E8),
    surfaceVariant = Color(0xFF2A353D),
    onSurfaceVariant = Color(0xFFBAC8D0),
    outline = Color(0xFF8A9AA3),
    outlineVariant = Color(0xFF3A4850),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    surfaceBright = Color(0xFF2A353D),
    surfaceDim = Color(0xFF0B1217),
    surfaceContainerLowest = Color(0xFF070C10),
    surfaceContainerLow = Color(0xFF111A20),
    surfaceContainer = Color(0xFF151F26),
    surfaceContainerHigh = Color(0xFF1B262D),
    surfaceContainerHighest = Color(0xFF263139),
)

@Composable
fun PurgerTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
