package com.speakercorepurger.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.speakercorepurger.app.PurgerApp
import com.speakercorepurger.app.audio.AudioFailureException
import com.speakercorepurger.app.audio.AudioRoute
import com.speakercorepurger.app.audio.DEFAULT_CUSTOM_HZ
import com.speakercorepurger.app.audio.DEFAULT_DURATION_SEC
import com.speakercorepurger.app.audio.EXTENDED_DURATION_SEC
import com.speakercorepurger.app.audio.FALLBACK_DURATION_SEC
import com.speakercorepurger.app.audio.PurgeMode
import com.speakercorepurger.app.audio.PurgeVibrator
import com.speakercorepurger.app.audio.ToneEngine
import com.speakercorepurger.app.data.AppSettings
import com.speakercorepurger.app.data.PurgeSession
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.ceil
import kotlin.math.roundToInt

enum class PurgePhase { IDLE, RUNNING, COMPLETED }

enum class PurgeMessage {
    HEADPHONES_CONNECTED,
    HEADPHONES_DURING,
    AUDIO_ERROR,
    AUDIO_BUSY,
    INTERRUPTED,
}

data class PurgeUiState(
    val mode: PurgeMode = PurgeMode.WATER,
    val durationSec: Int = DEFAULT_DURATION_SEC,
    val customHz: Float = DEFAULT_CUSTOM_HZ,
    val phase: PurgePhase = PurgePhase.IDLE,
    val progress: Float = 0f,
    val frequencyHz: Int = 0,
    val remainingSec: Int = DEFAULT_DURATION_SEC,
    val volume: Float = 0f,
    val externalOutput: Boolean = false,
    val autoMaxVolume: Boolean = true,
    val extendedLocked: Boolean = false,
    val message: PurgeMessage? = null,
)

private data class RunState(
    val phase: PurgePhase = PurgePhase.IDLE,
    val totalMs: Long = 0L,
    val elapsedMs: Long = 0L,
    val frequencyHz: Float = 0f,
    val volume: Float = 0f,
    val externalOutput: Boolean = false,
    val message: PurgeMessage? = null,
)

private class RouteChangedException : Exception()

class PurgeViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PurgerApp
    private val settingsRepo = app.settingsRepository
    private val historyRepo = app.historyRepository
    private val ads = app.ads
    private val engine = ToneEngine()
    private val vibrator = PurgeVibrator(application)

    private val run = MutableStateFlow(
        RunState(
            volume = AudioRoute.volumeFraction(application),
            externalOutput = AudioRoute.externalOutputConnected(application),
        ),
    )

    private var job: Job? = null

    val uiState: StateFlow<PurgeUiState> = combine(
        settingsRepo.settings,
        run,
        ads.rewardedLoaded,
    ) { settings, state, rewardedLoaded ->
        val locked = isExtendedLocked(settings, rewardedLoaded)
        val duration = effectiveDuration(settings, locked)
        val running = state.phase == PurgePhase.RUNNING
        val remaining = if (running) {
            ceil((state.totalMs - state.elapsedMs) / 1000.0).toInt().coerceAtLeast(0)
        } else {
            duration
        }
        PurgeUiState(
            mode = settings.mode,
            durationSec = duration,
            customHz = settings.customHz,
            phase = state.phase,
            progress = if (state.totalMs > 0) (state.elapsedMs.toFloat() / state.totalMs).coerceIn(0f, 1f) else 0f,
            frequencyHz = state.frequencyHz.roundToInt(),
            remainingSec = remaining,
            volume = state.volume,
            externalOutput = state.externalOutput,
            autoMaxVolume = settings.autoMaxVolume,
            extendedLocked = locked,
            message = state.message,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PurgeUiState())

    // ---- Selection -----------------------------------------------------------------------------

    fun selectMode(mode: PurgeMode) {
        if (run.value.phase == PurgePhase.RUNNING) return
        viewModelScope.launch { settingsRepo.setMode(mode) }
    }

    fun selectDuration(seconds: Int) {
        if (run.value.phase == PurgePhase.RUNNING) return
        viewModelScope.launch { settingsRepo.setDuration(seconds) }
    }

    fun setCustomHz(hz: Float) {
        viewModelScope.launch { settingsRepo.setCustomHz(hz) }
    }

    fun unlockExtended() {
        viewModelScope.launch {
            settingsRepo.setExtendedUnlockedUntil(System.currentTimeMillis() + UNLOCK_DURATION_MS)
            settingsRepo.setDuration(EXTENDED_DURATION_SEC)
        }
    }

    // ---- System state --------------------------------------------------------------------------

    fun refreshSystemState() {
        val volume = AudioRoute.volumeFraction(app)
        val external = AudioRoute.externalOutputConnected(app)
        run.update { it.copy(volume = volume, externalOutput = external) }
    }

    fun maximizeVolume() {
        AudioRoute.raiseVolumeToMax(app)
        refreshSystemState()
    }

    // ---- Purge control -------------------------------------------------------------------------

    fun start() {
        if (job?.isActive == true) return
        job = viewModelScope.launch { runPurge() }
    }

    fun stop() {
        job?.cancel()
    }

    fun acknowledgeCompletion() {
        run.update { if (it.phase == PurgePhase.COMPLETED) it.copy(phase = PurgePhase.IDLE, elapsedMs = 0L) else it }
    }

    fun dismissMessage() {
        run.update { it.copy(message = null) }
    }

    private suspend fun runPurge() {
        val settings = settingsRepo.settings.first()
        val locked = isExtendedLocked(settings, ads.rewardedLoaded.value)
        val durationSec = effectiveDuration(settings, locked)

        refreshSystemState()
        if (AudioRoute.externalOutputConnected(app)) {
            run.update { it.copy(message = PurgeMessage.HEADPHONES_CONNECTED) }
            return
        }

        var failure: PurgeMessage? = null
        val focus = AudioRoute.requestFocus(app) {
            failure = PurgeMessage.INTERRUPTED
            job?.cancel()
        }
        if (focus == null) {
            run.update { it.copy(message = PurgeMessage.AUDIO_BUSY) }
            return
        }

        val totalMs = durationSec * 1000L
        val startedAt = System.currentTimeMillis()
        val played = AtomicLong(0L)
        var completed = false
        val previousVolume = if (settings.autoMaxVolume) AudioRoute.raiseVolumeToMax(app) else null
        if (settings.vibrate) vibrator.start()

        run.update {
            it.copy(
                phase = PurgePhase.RUNNING,
                totalMs = totalMs,
                elapsedMs = 0L,
                frequencyHz = settings.mode.frequencyAt(0.0, settings.customHz).toFloat(),
                message = null,
            )
        }
        refreshSystemState()

        try {
            coroutineScope {
                val watcher = launch {
                    while (true) {
                        delay(ROUTE_POLL_MS)
                        refreshSystemState()
                        if (run.value.externalOutput) throw RouteChangedException()
                    }
                }
                engine.play(settings.mode, settings.customHz, totalMs) { playedMs, hz ->
                    played.set(playedMs)
                    run.update { it.copy(elapsedMs = playedMs, frequencyHz = hz) }
                }
                completed = true
                watcher.cancel()
            }
        } catch (e: RouteChangedException) {
            failure = PurgeMessage.HEADPHONES_DURING
        } catch (e: AudioFailureException) {
            failure = PurgeMessage.AUDIO_ERROR
        } finally {
            withContext(NonCancellable) {
                vibrator.stop()
                previousVolume?.let { AudioRoute.restoreVolume(app, it) }
                focus.abandon()
                val playedSec = (played.get() / 1000L).toInt()
                if (completed || playedSec >= MIN_RECORDED_SEC) {
                    historyRepo.add(
                        PurgeSession(
                            startedAt = startedAt,
                            modeId = settings.mode.id,
                            plannedSec = durationSec,
                            playedSec = if (completed) durationSec else playedSec,
                            completed = completed,
                            customHz = if (settings.mode == PurgeMode.CUSTOM) settings.customHz.roundToInt() else null,
                        ),
                    )
                }
                run.update {
                    it.copy(
                        phase = if (completed) PurgePhase.COMPLETED else PurgePhase.IDLE,
                        elapsedMs = if (completed) it.totalMs else 0L,
                        message = failure,
                    )
                }
                refreshSystemState()
            }
        }
    }

    override fun onCleared() {
        job?.cancel()
        vibrator.stop()
        super.onCleared()
    }

    private fun isExtendedLocked(settings: AppSettings, rewardedLoaded: Boolean): Boolean =
        ads.rewardedConfigured && rewardedLoaded && settings.extendedUnlockedUntil <= System.currentTimeMillis()

    private fun effectiveDuration(settings: AppSettings, locked: Boolean): Int =
        if (locked && settings.durationSec == EXTENDED_DURATION_SEC) FALLBACK_DURATION_SEC else settings.durationSec

    private companion object {
        const val ROUTE_POLL_MS = 400L
        const val MIN_RECORDED_SEC = 3
        const val UNLOCK_DURATION_MS = 24L * 60L * 60L * 1000L
    }
}
