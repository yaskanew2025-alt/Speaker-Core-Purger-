package com.speakercorepurger.app.ads

import android.app.Activity
import android.app.Application
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.speakercorepurger.app.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

/**
 * Owns everything related to advertising:
 *  - Google UMP consent (required in the EEA/UK) before the SDK starts
 *  - the AdMob SDK start-up (only when real IDs are configured)
 *  - interstitial and rewarded ad loading with exponential retry
 *
 * No ad IDs are hard-coded: they come from ads.properties / environment via BuildConfig.
 */
class AdsManager(private val app: Application) {

    private val configured = BuildConfig.ADMOB_APP_ID.isNotBlank()
    val bannerConfigured = configured && BuildConfig.ADMOB_BANNER_ID.isNotBlank()
    val interstitialConfigured = configured && BuildConfig.ADMOB_INTERSTITIAL_ID.isNotBlank()
    val rewardedConfigured = configured && BuildConfig.ADMOB_REWARDED_ID.isNotBlank()
    val bannerUnitId: String = BuildConfig.ADMOB_BANNER_ID

    private val mainHandler = Handler(Looper.getMainLooper())
    private val sdkStarted = AtomicBoolean(false)

    private val _ready = MutableStateFlow(false)
    /** True once the SDK has finished initializing and ads may be requested. */
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _rewardedLoaded = MutableStateFlow(false)
    val rewardedLoaded: StateFlow<Boolean> = _rewardedLoaded.asStateFlow()

    private val _privacyOptionsRequired = MutableStateFlow(false)
    val privacyOptionsRequired: StateFlow<Boolean> = _privacyOptionsRequired.asStateFlow()

    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null
    private var interstitialAttempts = 0
    private var rewardedAttempts = 0
    private var lastInterstitialShownAt = 0L

    // ---- Consent -----------------------------------------------------------------------------

    fun gatherConsentAndStart(activity: Activity) {
        if (!configured) return
        val info = UserMessagingPlatform.getConsentInformation(activity)
        if (info.canRequestAds()) startSdk()
        info.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                    onConsentResolved(info)
                }
            },
            {
                onConsentResolved(info)
            },
        )
    }

    private fun onConsentResolved(info: ConsentInformation) {
        _privacyOptionsRequired.value =
            info.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
        if (info.canRequestAds()) startSdk()
    }

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) {
            onConsentResolved(UserMessagingPlatform.getConsentInformation(activity))
        }
    }

    // ---- SDK start ---------------------------------------------------------------------------

    private fun startSdk() {
        if (!configured || !sdkStarted.compareAndSet(false, true)) return
        // Google recommends initializing off the main thread; the callback arrives on main.
        Thread {
            MobileAds.initialize(app) {
                mainHandler.post {
                    _ready.value = true
                    loadInterstitial()
                    loadRewarded()
                }
            }
        }.start()
    }

    // ---- Interstitial ------------------------------------------------------------------------

    private fun loadInterstitial() {
        if (!interstitialConfigured || interstitial != null) return
        InterstitialAd.load(
            app,
            BuildConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAttempts = 0
                    interstitial = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    interstitialAttempts++
                    mainHandler.postDelayed({ loadInterstitial() }, retryDelayMs(interstitialAttempts))
                }
            },
        )
    }

    /** Shows the interstitial if one is loaded and at least [MIN_INTERSTITIAL_GAP_MS] passed since the last. */
    fun showInterstitialIfEligible(activity: Activity) {
        val ad = interstitial ?: return
        val now = SystemClock.elapsedRealtime()
        if (lastInterstitialShownAt != 0L && now - lastInterstitialShownAt < MIN_INTERSTITIAL_GAP_MS) return
        interstitial = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                lastInterstitialShownAt = SystemClock.elapsedRealtime()
            }

            override fun onAdDismissedFullScreenContent() {
                loadInterstitial()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                loadInterstitial()
            }
        }
        ad.show(activity)
    }

    // ---- Rewarded ----------------------------------------------------------------------------

    private fun loadRewarded() {
        if (!rewardedConfigured || rewarded != null) return
        RewardedAd.load(
            app,
            BuildConfig.ADMOB_REWARDED_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAttempts = 0
                    rewarded = ad
                    _rewardedLoaded.value = true
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewarded = null
                    _rewardedLoaded.value = false
                    rewardedAttempts++
                    mainHandler.postDelayed({ loadRewarded() }, retryDelayMs(rewardedAttempts))
                }
            },
        )
    }

    /** Shows the rewarded ad. [onResult] receives true only if the user earned the reward. */
    fun showRewarded(activity: Activity, onResult: (Boolean) -> Unit) {
        val ad = rewarded
        if (ad == null) {
            onResult(false)
            loadRewarded()
            return
        }
        rewarded = null
        _rewardedLoaded.value = false
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                onResult(earned)
                loadRewarded()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                onResult(false)
                loadRewarded()
            }
        }
        ad.show(activity) { earned = true }
    }

    private fun retryDelayMs(attempt: Int): Long =
        min(RETRY_BASE_MS shl min(attempt - 1, 5), RETRY_MAX_MS)

    private companion object {
        const val MIN_INTERSTITIAL_GAP_MS = 3 * 60 * 1000L
        const val RETRY_BASE_MS = 15_000L
        const val RETRY_MAX_MS = 10 * 60 * 1000L
    }
}
