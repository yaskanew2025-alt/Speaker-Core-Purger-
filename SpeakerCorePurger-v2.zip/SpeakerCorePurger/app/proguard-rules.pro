# The Google Mobile Ads SDK and UMP ship their own consumer ProGuard rules.
# Keep line numbers for readable crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
