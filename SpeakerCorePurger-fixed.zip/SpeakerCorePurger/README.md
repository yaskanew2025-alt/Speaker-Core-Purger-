# Speaker Core Purger

Native Android app (Kotlin, Jetpack Compose, Android 6.0+ / API 23 and newer) that clears water and dust
from the phone speaker with tuned tones and vibration. No WebView.

## Build the APK on GitHub (no Android Studio needed)

1. Create a GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab and run **Build Speaker Core Purger** (it also runs on every push).
3. When the run is green, open it and download the **SpeakerCorePurger-apks** artifact.
   `app-debug.apk` and `app-release.apk` are both installable.

## Add your real AdMob IDs

Never commit fake IDs. Either:

- edit `ads.properties` (four values: app ID, banner, interstitial, rewarded), or
- add GitHub repository secrets with the same names (`ADMOB_APP_ID`, `ADMOB_BANNER_ID`,
  `ADMOB_INTERSTITIAL_ID`, `ADMOB_REWARDED_ID`). Secrets override the file.

Any ad format whose ID is empty is switched off. If `ADMOB_APP_ID` is empty the ad SDK is never started.

Ads in the app: an adaptive banner, an interstitial after a finished purge (at most one every 3 minutes),
and a rewarded ad that unlocks the 5-minute purge for 24 hours. Consent (UMP) is shown where required.

## Release signing (optional, for Google Play)

Without a keystore the release APK is signed with the debug key, which is fine for installing but not for Play.
For Play, add secrets `KEYSTORE_BASE64`, `SIGNING_STORE_PASSWORD`, `SIGNING_KEY_ALIAS`, `SIGNING_KEY_PASSWORD`.

## Local build

Android Studio with Android SDK 36 and JDK 17: open this folder and run the `app` configuration, or run `./gradlew assembleDebug`.

## What's new in 1.3.0

Five tabs: Purge, Tools, Health, History, Settings.

- **Speaker Health Check** (Health tab): plays 8 test tones (250 Hz to 10 kHz), listens with the microphone, measures each tone with the Goertzel algorithm and gives a 0 to 100 score with a result per pitch.
- **Safer volume controls**: set a 30–100% media-volume ceiling, enforce it during playback, and confirm before any run that will use the phone's maximum media volume.
- **Health-check calibration**: the check rejects a noisy lead-in or clipped microphone recording instead of saving an unreliable result.
- **Clean reference**: save a check made while the speaker sounds good; later checks are compared band by band in dB.
- **Smarter guided fix**: weak pitches recommend Water, Dust or Deep clean; after a clean it re-checks, allows at most one further round when results improve, and advises repair when they do not.
- **Backup and restore**: export or import a versioned JSON file containing settings, health history and reference, purge history and saved programs. Restore validates the full file and asks before replacing local data.
- **Home-screen widget**: open Purge, Health or Water Rescue directly; the widget opens screens and never starts audio on its own.
- **Water rescue**: guided steps, 2-minute Water purge, drying timer.
- **Health trend chart, history and share report.**
- **Live spectrum analyzer** (Tools): 24-band spectrum and loudest tone from the microphone.
- **My programs**: chain up to 8 sounds (max 20 minutes) and play them with one tap.
- **Insights** (History): streak, last 7 days chart, most-used mode, CSV export.
- **Drying timer alert** (alarm clock API) and optional **weekly reminder** notification; restored after reboot.
- **App shortcuts** (long-press the icon), **dynamic colour** (Android 12+).

Permissions: `RECORD_AUDIO` (only while a check or the spectrum analyzer runs; audio is analysed in memory, never stored or sent), `POST_NOTIFICATIONS`, `RECEIVE_BOOT_COMPLETED`.

This source snapshot does not include JVM test sources. The GitHub Actions workflow builds installable APKs; run the local build with Android Studio and JDK 17.

## What was new in 1.1.0

- **Tools tab**: tone tester (150–10,000 Hz), 12-step speaker sweep test, and a drying timer that keeps counting after the app is closed.
- **Live sound visualizer** on the purge screen that follows the real output level.
- Guide text updated for the Power and Noise modes.
