package com.speakercorepurger.app.audio

import android.media.AudioRecord
import com.speakercorepurger.app.data.HealthBand
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.log10

/**
 * Plays a short series of test tones through the speaker while listening through the microphone,
 * then measures how loudly each tone arrived. The audio is analysed in memory and discarded; it is
 * never written to a file or sent anywhere.
 */
class SpeakerHealthCheck(private val engine: ToneEngine) {

    /**
     * Runs the test. The caller must already hold the RECORD_AUDIO permission. Progress is a
     * fraction from 0 to 1. Throws [AudioFailureException] if the microphone or speaker can not be used.
     */
    suspend fun run(onProgress: (progress: Float, hz: Int) -> Unit): List<HealthBand> = coroutineScope {
        val record = Mic.open()
        val capacity = (HealthCheckSpec.TOTAL_MS / 1000.0 * SAMPLE_RATE).toInt() + SAMPLE_RATE
        val data = ShortArray(capacity)
        var filled = 0
        val stopping = AtomicBoolean(false)
        var reader: Job? = null
        var readFailure: AudioFailureException? = null

        try {
            record.startRecording()
            if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                throw AudioFailureException("Microphone could not start")
            }
            reader = launch(Dispatchers.IO) {
                val chunk = ShortArray(2_048)
                while (isActive && !stopping.get() && filled < capacity) {
                    val count = record.read(chunk, 0, min(chunk.size, capacity - filled))
                    if (count < 0) {
                        if (!stopping.get()) readFailure = AudioFailureException("Microphone read failed ($count)")
                        break
                    }
                    if (count > 0) {
                        System.arraycopy(chunk, 0, data, filled, count)
                        filled += count
                    }
                }
            }

            val total = HealthCheckSpec.TOTAL_MS.toFloat()
            engine.playVoice(HealthVoice(), HealthCheckSpec.TOTAL_MS) { playedMs, hz, _ ->
                onProgress((playedMs / total).coerceIn(0f, 1f), hz.toInt())
            }
            delay(250)
        } finally {
            stopping.set(true)
            runCatching { record.stop() }
            withContext(NonCancellable) { reader?.join() }
            record.release()
        }

        readFailure?.let { throw it }
        val length = filled
        if (length < SAMPLE_RATE * 2) throw AudioFailureException("Not enough microphone data")
        var loudest = 0
        for (i in 0 until length) loudest = maxOf(loudest, abs(data[i].toInt()))
        if (loudest < MIN_SIGNAL) throw AudioFailureException("Microphone returned silence")

        val baselineCount = min(length, (HealthCheckSpec.LEAD_IN_SEC * SAMPLE_RATE).toInt())
        var baselinePower = 0.0
        for (i in 0 until baselineCount) {
            val sample = data[i].toDouble() / 32768.0
            baselinePower += sample * sample
        }
        val roomNoiseDb = 20.0 * log10(sqrt(baselinePower / baselineCount) + 1e-9)
        if (roomNoiseDb > MAX_ROOM_NOISE_DB) {
            throw HealthCalibrationException(HealthCalibrationIssue.NOISY_ROOM)
        }
        val clipped = (0 until length).count { abs(data[it].toInt()) >= CLIPPING_SAMPLE }
        if (clipped.toFloat() / length > MAX_CLIPPED_FRACTION) {
            throw HealthCalibrationException(HealthCalibrationIssue.INPUT_CLIPPED)
        }

        withContext(Dispatchers.Default) {
            HealthAnalyzer.analyze(data, length, HealthCheckSpec.FREQS_HZ, SAMPLE_RATE)
        }
    }

    private companion object {
        const val SAMPLE_RATE = Mic.SAMPLE_RATE
        const val MIN_SIGNAL = 4
        const val MAX_ROOM_NOISE_DB = -24.0
        const val CLIPPING_SAMPLE = 32_760
        const val MAX_CLIPPED_FRACTION = 0.005f
    }
}

enum class HealthCalibrationIssue { NOISY_ROOM, INPUT_CLIPPED }

class HealthCalibrationException(val issue: HealthCalibrationIssue) : Exception()
