package com.speakercorepurger.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

/** Stores the user's saved purge programs. */
class ProgramRepository(private val context: Context) {

    private val key = stringPreferencesKey("programs")

    val programs: Flow<List<SavedProgram>> = context.appDataStore.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { prefs -> ProgramCodec.decodeAll(prefs[key]) }

    /**
     * Saves [program] (adds it, or replaces the one with the same id). Returns the problem that
     * stopped the save, or null on success.
     */
    suspend fun save(program: SavedProgram): ProgramIssue? {
        val clean = program.copy(name = ProgramCodec.sanitizeName(program.name))
        ProgramCodec.validate(clean)?.let { return it }
        var issue: ProgramIssue? = null
        context.appDataStore.edit { prefs ->
            val current = ProgramCodec.decodeAll(prefs[key])
            val exists = current.any { it.id == clean.id }
            if (!exists && current.size >= ProgramCodec.MAX_PROGRAMS) {
                issue = ProgramIssue.TOO_MANY_PROGRAMS
                return@edit
            }
            val updated = if (exists) current.map { if (it.id == clean.id) clean else it } else current + clean
            prefs[key] = ProgramCodec.encodeAll(updated)
        }
        return issue
    }

    suspend fun delete(id: Long) {
        context.appDataStore.edit { prefs ->
            val updated = ProgramCodec.decodeAll(prefs[key]).filterNot { it.id == id }
            if (updated.isEmpty()) prefs.remove(key) else prefs[key] = ProgramCodec.encodeAll(updated)
        }
    }
}
