package com.speakercorepurger.app.audio

import com.speakercorepurger.app.data.ProgramStep
import kotlin.math.min

/**
 * Plays the steps of a saved program one after another. Every step starts from silence and ends in
 * silence (a 20 ms fade) so that switching between modes never clicks.
 */
class ProgramVoice(private val steps: List<ProgramStep>) : Voice {
    init {
        require(steps.isNotEmpty()) { "a program needs at least one step" }
    }

    private val voices = steps.map { PurgeMode.fromId(it.modeId).createVoice(it.hz.toFloat()) }
    private val starts = DoubleArray(steps.size).also { array ->
        var at = 0.0
        steps.forEachIndexed { index, step ->
            array[index] = at
            at += step.seconds
        }
    }
    private var active = 0

    val totalMs: Long get() = steps.sumOf { it.seconds } * 1000L

    override val hz: Double get() = voices[active].hz

    override fun next(t: Double): Double {
        var index = active
        while (index < steps.lastIndex && t >= starts[index + 1]) index++
        active = index
        val local = t - starts[index]
        val remaining = steps[index].seconds - local
        val fade = min(1.0, min(local / FADE_SEC, remaining / FADE_SEC)).coerceAtLeast(0.0)
        return voices[index].next(local) * fade
    }

    private companion object {
        const val FADE_SEC = 0.02
    }
}
