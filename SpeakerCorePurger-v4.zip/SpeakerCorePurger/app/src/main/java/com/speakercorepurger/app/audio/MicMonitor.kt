package com.speakercorepurger.app.audio

import android.media.AudioRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/**
 * Listens to the microphone and reports a live spectrum until the calling coroutine is cancelled.
 * Nothing is recorded to storage: each block is analysed and then overwritten.
 */
class MicMonitor {

    /** Throws [AudioFailureException] if the microphone cannot be used. */
    suspend fun run(onFrame: (SpectrumFrame) -> Unit) = withContext(Dispatchers.IO) {
        val record = Mic.open()
        try {
            record.startRecording()
            if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                throw AudioFailureException("Microphone could not start")
            }
            val analyzer = SpectrumAnalyzer(size = BLOCK, sampleRate = Mic.SAMPLE_RATE)
            val block = ShortArray(BLOCK)
            while (true) {
                currentCoroutineContext().ensureActive()
                var filled = 0
                while (filled < BLOCK) {
                    val count = record.read(block, filled, BLOCK - filled)
                    if (count < 0) throw AudioFailureException("Microphone read failed ($count)")
                    if (count == 0) {
                        currentCoroutineContext().ensureActive()
                    }
                    filled += count
                }
                onFrame(analyzer.analyze(block, BLOCK))
            }
        } finally {
            withContext(NonCancellable) {
                runCatching { record.stop() }
                record.release()
            }
        }
    }

    private companion object {
        const val BLOCK = 2_048
    }
}
