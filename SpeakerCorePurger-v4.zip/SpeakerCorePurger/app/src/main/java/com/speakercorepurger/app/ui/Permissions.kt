package com.speakercorepurger.app.ui

import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

/** Notifications need a runtime permission only on Android 13 and newer. */
val notificationPermissionRequired: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

/**
 * Returns a function that makes sure [permission] is granted and then reports the outcome to
 * [onResult]. If the permission is already granted (or [required] is false) the result is immediate;
 * otherwise the system permission dialog is shown first.
 */
@Composable
fun rememberPermissionRequest(
    permission: String,
    required: Boolean = true,
    onResult: (granted: Boolean) -> Unit,
): () -> Unit {
    val context = LocalContext.current
    val latest by rememberUpdatedState(onResult)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        latest(granted)
    }
    return {
        val granted = !required ||
            ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        if (granted) latest(true) else launcher.launch(permission)
    }
}
