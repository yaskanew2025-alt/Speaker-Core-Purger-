package com.speakercorepurger.app.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.speakercorepurger.app.PurgerApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private val receiverScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

/** Runs [block] off the main thread while keeping the broadcast alive until it finishes. */
private fun BroadcastReceiver.runAsync(block: suspend () -> Unit) {
    val pending = goAsync()
    receiverScope.launch {
        try {
            block()
        } finally {
            pending.finish()
        }
    }
}

/** Fires when the drying timer ends. */
class DryingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.showDryingDone(context.applicationContext)
    }
}

/** Fires for the weekly reminder; shows it and schedules the next one while the setting is still on. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        runAsync {
            val settings = (app as PurgerApp).settingsRepository.settings.first()
            if (settings.weeklyReminder) {
                Notifier.showReminder(app)
                Notifier.scheduleReminder(app)
            }
        }
    }
}

/** Alarms are cleared when the phone restarts, so this puts them back. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext
        runAsync {
            val settings = (app as PurgerApp).settingsRepository.settings.first()
            if (settings.weeklyReminder) Notifier.scheduleReminder(app)
            if (settings.dryingEndsAt > System.currentTimeMillis()) Notifier.scheduleDrying(app, settings.dryingEndsAt)
        }
    }
}
