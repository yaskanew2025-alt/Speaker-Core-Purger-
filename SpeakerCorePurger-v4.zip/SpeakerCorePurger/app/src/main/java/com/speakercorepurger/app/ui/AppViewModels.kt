package com.speakercorepurger.app.ui

/** All view models of the main screen, created once by the activity and shared with the screens. */
class AppViewModels(
    val main: MainViewModel,
    val purge: PurgeViewModel,
    val tools: ToolsViewModel,
    val health: HealthViewModel,
    val fix: FixViewModel,
    val programs: ProgramsViewModel,
    val spectrum: SpectrumViewModel,
)
