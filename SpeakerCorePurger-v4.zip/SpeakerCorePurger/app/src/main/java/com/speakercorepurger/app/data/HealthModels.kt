package com.speakercorepurger.app.data

import kotlin.math.roundToInt

/** How clearly one test tone came through the microphone. */
enum class BandStatus { CLEAR, WEAK, FAINT }

data class HealthBand(
    val hz: Int,
    /** Loudest level of this tone in dB relative to full scale (always negative). */
    val peakDb: Float,
    /** How far the tone rose above the room noise, in dB. */
    val snrDb: Float,
) {
    val status: BandStatus
        get() = when {
            snrDb >= CLEAR_SNR_DB -> BandStatus.CLEAR
            snrDb >= WEAK_SNR_DB -> BandStatus.WEAK
            else -> BandStatus.FAINT
        }

    companion object {
        const val CLEAR_SNR_DB = 20f
        const val WEAK_SNR_DB = 10f
        const val FULL_SNR_DB = 30f
    }
}

data class HealthResult(val takenAt: Long, val bands: List<HealthBand>) {

    /** Compact single-line text form, e.g. `1700000000000;250,-20.5,31.2|500,-18.0,29.9`. */
    fun encode(): String =
        takenAt.toString() + ";" + bands.joinToString("|") { "${it.hz},${it.peakDb},${it.snrDb}" }

    companion object {
        const val MAX_STORED = 30

        fun decode(text: String): HealthResult? {
            val halves = text.trim().split(';')
            if (halves.size != 2) return null
            val takenAt = halves[0].toLongOrNull() ?: return null
            val bands = mutableListOf<HealthBand>()
            if (halves[1].isNotEmpty()) {
                for (item in halves[1].split('|')) {
                    val parts = item.split(',')
                    if (parts.size != 3) return null
                    val hz = parts[0].toIntOrNull() ?: return null
                    val peak = parts[1].toFloatOrNull() ?: return null
                    val snr = parts[2].toFloatOrNull() ?: return null
                    bands += HealthBand(hz, peak, snr)
                }
            }
            return HealthResult(takenAt, bands)
        }

        fun encodeAll(results: List<HealthResult>): String =
            results.take(MAX_STORED).joinToString("\n") { it.encode() }

        fun decodeAll(text: String?): List<HealthResult> =
            text.orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull { decode(it) }.toList()
    }
}

/** One band of a check, judged on its own and, when a reference exists, against that reference. */
data class BandAssessment(
    val hz: Int,
    val status: BandStatus,
    /** 0 to 1, how healthy this band looks. */
    val fraction: Float,
    /** How many dB quieter than the reference this band is (negative when louder), or null. */
    val dropDb: Float?,
)

/**
 * Judges a check. Without a reference only the absolute level above room noise is used, which can
 * find tones that are weak or missing. With a reference (a check the user saved while the speaker was
 * clean) every band is also compared with its own level then, which is what shows gradual muffling.
 */
class HealthAssessment(val result: HealthResult, val reference: HealthResult?) {

    val hasReference: Boolean get() = reference != null

    val bands: List<BandAssessment> = result.bands.map { band ->
        val ref = reference?.bands?.firstOrNull { it.hz == band.hz }
        val drop = ref?.let { it.peakDb - band.peakDb }
        val absolute = (band.snrDb / HealthBand.FULL_SNR_DB).coerceIn(0f, 1f)
        val relative = if (drop == null) 1f else (1f - (drop - TOLERANCE_DB) / (LOSS_FOR_ZERO_DB - TOLERANCE_DB)).coerceIn(0f, 1f)
        val relStatus = when {
            drop == null -> BandStatus.CLEAR
            drop >= FAINT_DROP_DB -> BandStatus.FAINT
            drop >= WEAK_DROP_DB -> BandStatus.WEAK
            else -> BandStatus.CLEAR
        }
        BandAssessment(band.hz, maxOf(band.status, relStatus), minOf(absolute, relative), drop)
    }

    /** 0 to 100. A relative measure of how clearly the speaker came through the microphone. */
    val score: Int
        get() = if (bands.isEmpty()) 0 else (bands.map { it.fraction }.average() * 100).roundToInt()

    companion object {
        /** Level changes smaller than this are normal measurement variation. */
        const val TOLERANCE_DB = 3f
        const val WEAK_DROP_DB = 6f
        const val FAINT_DROP_DB = 15f
        const val LOSS_FOR_ZERO_DB = 18f
    }
}
