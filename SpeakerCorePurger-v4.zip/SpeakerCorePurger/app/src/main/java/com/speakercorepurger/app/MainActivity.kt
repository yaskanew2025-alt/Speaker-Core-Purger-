package com.speakercorepurger.app

import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.speakercorepurger.app.ui.AppViewModels
import com.speakercorepurger.app.ui.FixViewModel
import com.speakercorepurger.app.ui.HealthViewModel
import com.speakercorepurger.app.ui.MainViewModel
import com.speakercorepurger.app.ui.ProgramsViewModel
import com.speakercorepurger.app.ui.PurgeViewModel
import com.speakercorepurger.app.ui.PurgerRoot
import com.speakercorepurger.app.ui.SpectrumViewModel
import com.speakercorepurger.app.ui.ToolsViewModel

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private val purgeViewModel: PurgeViewModel by viewModels()
    private val toolsViewModel: ToolsViewModel by viewModels()
    private val healthViewModel: HealthViewModel by viewModels()
    private val fixViewModel: FixViewModel by viewModels()
    private val programsViewModel: ProgramsViewModel by viewModels()
    private val spectrumViewModel: SpectrumViewModel by viewModels()

    /** Screen requested by a shortcut or notification, until the UI has opened it. */
    private var launchRoute by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val app = application as PurgerApp

        // Hardware volume keys control the media stream, which is what the purge plays on.
        volumeControlStream = AudioManager.STREAM_MUSIC

        app.ads.gatherConsentAndStart(this)

        // A recreated activity (rotation) must not open the same shortcut screen again.
        if (savedInstanceState == null) launchRoute = intent?.getStringExtra(EXTRA_ROUTE)

        val models = AppViewModels(
            main = mainViewModel,
            purge = purgeViewModel,
            tools = toolsViewModel,
            health = healthViewModel,
            fix = fixViewModel,
            programs = programsViewModel,
            spectrum = spectrumViewModel,
        )

        setContent {
            PurgerRoot(
                models = models,
                ads = app.ads,
                launchRoute = launchRoute,
                onLaunchRouteConsumed = { launchRoute = null },
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(EXTRA_ROUTE)?.let { launchRoute = it }
    }

    override fun onStop() {
        super.onStop()
        // Sound and microphone only run while the screen is visible. Rotation must not stop them.
        if (!isChangingConfigurations) {
            purgeViewModel.stop()
            toolsViewModel.stop()
            healthViewModel.stop()
            spectrumViewModel.stop()
        }
    }

    companion object {
        const val EXTRA_ROUTE = "route"
        const val ROUTE_HEALTH = "health"
        const val ROUTE_TOOLS = "tools"
        const val ROUTE_RESCUE = "rescue"
    }
}
