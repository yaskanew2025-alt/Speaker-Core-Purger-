package com.speakercorepurger.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

class HistoryRepository(private val context: Context) {

    private val key = stringPreferencesKey("history_json")

    val sessions: Flow<List<PurgeSession>> = context.appDataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs -> decode(prefs[key]) }

    suspend fun add(session: PurgeSession) {
        context.appDataStore.edit { prefs ->
            val updated = (listOf(session) + decode(prefs[key])).take(MAX_ENTRIES)
            prefs[key] = encode(updated)
        }
    }

    suspend fun clear() {
        context.appDataStore.edit { it.remove(key) }
    }

    private fun encode(list: List<PurgeSession>): String {
        val array = JSONArray()
        list.forEach { s ->
            array.put(
                JSONObject()
                    .put("t", s.startedAt)
                    .put("m", s.modeId)
                    .put("p", s.plannedSec)
                    .put("d", s.playedSec)
                    .put("c", s.completed)
                    .put("h", s.customHz ?: JSONObject.NULL)
                    .put("l", s.label ?: JSONObject.NULL),
            )
        }
        return array.toString()
    }

    private fun decode(raw: String?): List<PurgeSession> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(
                        PurgeSession(
                            startedAt = o.getLong("t"),
                            modeId = o.getString("m"),
                            plannedSec = o.getInt("p"),
                            playedSec = o.getInt("d"),
                            completed = o.getBoolean("c"),
                            customHz = if (o.isNull("h")) null else o.getInt("h"),
                            label = if (!o.has("l") || o.isNull("l")) null else o.getString("l"),
                        ),
                    )
                }
            }
        } catch (e: JSONException) {
            emptyList()
        }
    }

    private companion object {
        const val MAX_ENTRIES = 100
    }
}
