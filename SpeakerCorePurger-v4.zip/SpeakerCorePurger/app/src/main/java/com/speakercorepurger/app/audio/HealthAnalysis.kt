package com.speakercorepurger.app.audio

import com.speakercorepurger.app.data.HealthBand
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.sqrt

object HealthCheckSpec {
    val FREQS_HZ = intArrayOf(250, 500, 1_000, 2_000, 3_500, 5_000, 8_000, 10_000)
    const val LEAD_IN_SEC = 1.0
    const val STEP_SEC = 1.2
    const val TONE_SEC = 1.1
    const val TAIL_SEC = 0.6
    val TOTAL_MS: Long = ((LEAD_IN_SEC + FREQS_HZ.size * STEP_SEC + TAIL_SEC) * 1000).toLong()
}

/**
 * Measures the level of each test tone in a recording with the Goertzel algorithm. The tone level is
 * the loudest analysis frame over the whole recording, so the result does not depend on how long the
 * phone takes to start playing. The room-noise level comes from the silent lead-in at the start.
 */
object HealthAnalyzer {
    const val SAMPLE_RATE = 44_100
    private const val FRAME = 4_096
    private const val HOP = 2_048
    private const val BASELINE_SEC = 0.8

    fun analyze(samples: ShortArray, count: Int, freqs: IntArray, sampleRate: Int = SAMPLE_RATE): List<HealthBand> {
        require(count in 0..samples.size) { "count out of range" }
        val window = DoubleArray(FRAME) { 0.5 - 0.5 * cos(2.0 * PI * it / (FRAME - 1)) }
        val windowSum = window.sum()
        val baselineEnd = (BASELINE_SEC * sampleRate).toInt()
        val starts = if (count >= FRAME) (0..count - FRAME step HOP).toList() else emptyList()

        return freqs.map { hz ->
            val coefficient = 2.0 * cos(2.0 * PI * hz / sampleRate)
            var peak = 0.0
            var baselineSum = 0.0
            var baselineFrames = 0
            var quietest = Double.MAX_VALUE

            for (start in starts) {
                var s1 = 0.0
                var s2 = 0.0
                for (n in 0 until FRAME) {
                    val s0 = samples[start + n] * window[n] + coefficient * s1 - s2
                    s2 = s1
                    s1 = s0
                }
                val power = (s1 * s1 + s2 * s2 - coefficient * s1 * s2).coerceAtLeast(0.0)
                val amplitude = 2.0 * sqrt(power) / windowSum / 32768.0
                if (amplitude > peak) peak = amplitude
                if (amplitude < quietest) quietest = amplitude
                if (start + FRAME <= baselineEnd) {
                    baselineSum += amplitude * amplitude
                    baselineFrames++
                }
            }

            val baseline = when {
                baselineFrames > 0 -> sqrt(baselineSum / baselineFrames)
                quietest != Double.MAX_VALUE -> quietest
                else -> 0.0
            }
            val peakDb = toDb(peak)
            val snr = (peakDb - toDb(baseline)).coerceAtLeast(0.0)
            HealthBand(hz = hz, peakDb = peakDb.toFloat(), snrDb = snr.toFloat())
        }
    }

    private fun toDb(amplitude: Double): Double = 20.0 * log10(amplitude + 1e-9)
}
