package com.speakercorepurger.app.ui.history

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speakercorepurger.app.R
import com.speakercorepurger.app.audio.PurgeMode
import com.speakercorepurger.app.data.PurgeSession
import com.speakercorepurger.app.logic.HistoryExport
import com.speakercorepurger.app.logic.StatsCalculator
import com.speakercorepurger.app.ui.MainViewModel
import com.speakercorepurger.app.ui.common.SectionCard
import com.speakercorepurger.app.ui.common.WeekBars
import com.speakercorepurger.app.ui.durationLabel
import com.speakercorepurger.app.ui.formatClock
import com.speakercorepurger.app.ui.purge.PurgeOrb
import com.speakercorepurger.app.ui.titleRes
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(
    vm: MainViewModel,
    onStartPurge: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val sessions by vm.history.collectAsStateWithLifecycle()
    val list = sessions
    var showClearDialog by rememberSaveable { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        when {
            list == null -> Unit
            list.isEmpty() -> EmptyState(onStartPurge = onStartPurge)
            else -> HistoryList(list = list, onClear = { showClearDialog = true })
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text(stringResource(R.string.history_clear_title)) },
            text = { Text(stringResource(R.string.history_clear_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearDialog = false
                        vm.clearHistory()
                    },
                ) { Text(stringResource(R.string.history_clear_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}

@Composable
private fun HistoryList(list: List<PurgeSession>, onClear: () -> Unit) {
    val dateFormat = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    val totalSeconds = list.sumOf { it.playedSec }

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 560.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "header") {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.history_title),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.semantics { heading() },
                        )
                        Text(
                            text = stringResource(R.string.history_subtitle),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = onClear) { Text(stringResource(R.string.history_clear)) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(
                        label = stringResource(R.string.history_stat_sessions),
                        value = list.size.toString(),
                        modifier = Modifier.weight(1f),
                    )
                    StatCard(
                        label = stringResource(R.string.history_stat_time),
                        value = formatTotal(totalSeconds),
                        modifier = Modifier.weight(1f),
                    )
                }
                InsightsCard(list = list)
            }
        }
        items(list, key = { it.startedAt }) { session ->
            SessionCard(session = session, dateText = dateFormat.format(Date(session.startedAt)))
        }
    }
}

@Composable
private fun formatTotal(totalSeconds: Int): String =
    if (totalSeconds >= 3600) {
        stringResource(R.string.history_hours_minutes, totalSeconds / 3600, (totalSeconds % 3600) / 60)
    } else {
        formatClock(totalSeconds)
    }

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SessionCard(session: PurgeSession, dateText: String) {
    val mode = PurgeMode.fromId(session.modeId)
    val title = if (session.label != null) {
        stringResource(R.string.history_program_title, session.label)
    } else if (mode == PurgeMode.CUSTOM && session.customHz != null) {
        stringResource(R.string.history_custom_title, stringResource(mode.titleRes()), session.customHz)
    } else {
        stringResource(mode.titleRes())
    }
    val scheme = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = scheme.surfaceContainer),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = stringResource(
                        if (session.completed) R.string.history_completed else R.string.history_stopped,
                    ),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (session.completed) scheme.tertiary else scheme.onSurfaceVariant,
                )
            }
            Text(
                text = dateText,
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
            )
            Text(
                text = stringResource(
                    R.string.history_played,
                    formatClock(session.playedSec),
                    formatClock(session.plannedSec),
                ),
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun EmptyState(onStartPurge: () -> Unit) {
    Column(
        modifier = Modifier
            .widthIn(max = 420.dp)
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        PurgeOrb(running = false, active = false, progress = -1f, size = 160.dp)
        Text(
            text = stringResource(R.string.history_empty_title),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 16.dp)
                .semantics { heading() },
        )
        Text(
            text = stringResource(R.string.history_empty_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp, bottom = 24.dp),
        )
        Button(onClick = onStartPurge) { Text(stringResource(R.string.history_empty_action)) }
    }
}

@Composable
private fun InsightsCard(list: List<PurgeSession>) {
    val context = LocalContext.current
    val stats = remember(list) { StatsCalculator.compute(list, System.currentTimeMillis()) }
    val favorite = stats.favoriteModeId
    val favoriteName = when {
        favorite == null -> null
        favorite == "program" -> stringResource(R.string.history_programs_label)
        else -> stringResource(PurgeMode.fromId(favorite).titleRes())
    }
    val chartDescription = stringResource(R.string.history_week_desc, stats.last7Sec.sum() / 60)
    val shareTitle = stringResource(R.string.history_export)

    SectionCard(title = stringResource(R.string.history_insights_title)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                label = stringResource(R.string.history_stat_streak),
                value = stringResource(R.string.history_streak_days, stats.streakDays),
                modifier = Modifier.weight(1f),
            )
            StatCard(
                label = stringResource(R.string.history_stat_favorite),
                value = favoriteName ?: stringResource(R.string.history_none),
                modifier = Modifier.weight(1f),
            )
        }
        Text(
            text = stringResource(R.string.history_week_title),
            style = MaterialTheme.typography.titleSmall,
        )
        WeekBars(
            seconds = stats.last7Sec,
            description = chartDescription,
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp),
        )
        Text(
            text = stringResource(R.string.history_week_caption),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedButton(
            onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, shareTitle)
                    putExtra(Intent.EXTRA_TEXT, HistoryExport.toCsv(list))
                }
                context.startActivity(Intent.createChooser(send, shareTitle))
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(shareTitle) }
    }
}
