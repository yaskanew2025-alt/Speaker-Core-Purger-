package com.speakercorepurger.app.ui

import androidx.lifecycle.ViewModel
import com.speakercorepurger.app.audio.PurgeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

enum class FixStage { INTRO, PURGE, RECHECK, RESULT }

data class FixUiState(
    val stage: FixStage = FixStage.INTRO,
    /** True for the water-rescue flow, which starts straight away with a purge and no earlier check. */
    val rescue: Boolean = false,
    val mode: PurgeMode = PurgeMode.WATER,
    val durationSec: Int = 60,
    val scoreBefore: Int? = null,
    /** Time the re-check was requested; only a check taken after this counts as "after". */
    val recheckAfter: Long = 0L,
)

/** Keeps track of where the user is in the guided fix or water-rescue flow. */
class FixViewModel : ViewModel() {
    private val _state = MutableStateFlow(FixUiState())
    val state: StateFlow<FixUiState> = _state

    fun begin(rescue: Boolean, mode: PurgeMode, durationSec: Int, scoreBefore: Int?) {
        _state.value = FixUiState(
            stage = FixStage.INTRO,
            rescue = rescue,
            mode = mode,
            durationSec = durationSec,
            scoreBefore = scoreBefore,
        )
    }

    fun toPurge() = _state.update { it.copy(stage = FixStage.PURGE) }

    fun toRecheck(nowMillis: Long) = _state.update { it.copy(stage = FixStage.RECHECK, recheckAfter = nowMillis) }

    fun toResult() = _state.update { it.copy(stage = FixStage.RESULT) }

    /** After a result, another round starts again from the purge with the same plan. */
    fun another(scoreBefore: Int?) = _state.update { it.copy(stage = FixStage.INTRO, scoreBefore = scoreBefore) }
}
