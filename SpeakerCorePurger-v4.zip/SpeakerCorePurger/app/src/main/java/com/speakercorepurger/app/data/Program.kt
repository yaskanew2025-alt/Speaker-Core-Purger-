package com.speakercorepurger.app.data

import com.speakercorepurger.app.audio.CUSTOM_MAX_HZ
import com.speakercorepurger.app.audio.CUSTOM_MIN_HZ
import com.speakercorepurger.app.audio.PurgeMode

/** One part of a saved program. [hz] is only used when the mode is Custom. */
data class ProgramStep(val modeId: String, val seconds: Int, val hz: Int)

data class SavedProgram(val id: Long, val name: String, val steps: List<ProgramStep>) {
    val totalSec: Int get() = steps.sumOf { it.seconds }
}

enum class ProgramIssue { NAME_EMPTY, NO_STEPS, TOO_MANY_STEPS, STEP_LENGTH, TOO_LONG, BAD_MODE, BAD_FREQUENCY, TOO_MANY_PROGRAMS }

object ProgramCodec {
    const val MAX_NAME = 24
    const val MAX_STEPS = 8
    const val MIN_STEP_SEC = 5
    const val MAX_STEP_SEC = 300
    const val MAX_TOTAL_SEC = 1_200
    const val MAX_PROGRAMS = 12

    /** Removes characters used by the storage format and trims the name to [MAX_NAME]. */
    fun sanitizeName(raw: String): String =
        raw.map { if (it == '|' || it == ';' || it == ',' || it == '\n' || it == '\r') ' ' else it }
            .joinToString("")
            .trim()
            .replace(Regex("\\s+"), " ")
            .take(MAX_NAME)
            .trim()

    /** Returns the first problem with [program], or null when it is valid. */
    fun validate(program: SavedProgram): ProgramIssue? {
        if (sanitizeName(program.name).isEmpty()) return ProgramIssue.NAME_EMPTY
        if (program.steps.isEmpty()) return ProgramIssue.NO_STEPS
        if (program.steps.size > MAX_STEPS) return ProgramIssue.TOO_MANY_STEPS
        for (step in program.steps) {
            if (PurgeMode.entries.none { it.id == step.modeId }) return ProgramIssue.BAD_MODE
            if (step.seconds !in MIN_STEP_SEC..MAX_STEP_SEC) return ProgramIssue.STEP_LENGTH
            if (step.modeId == PurgeMode.CUSTOM.id && step.hz.toFloat() !in CUSTOM_MIN_HZ..CUSTOM_MAX_HZ) {
                return ProgramIssue.BAD_FREQUENCY
            }
        }
        if (program.totalSec > MAX_TOTAL_SEC) return ProgramIssue.TOO_LONG
        return null
    }

    fun encodeAll(programs: List<SavedProgram>): String =
        programs.take(MAX_PROGRAMS).joinToString("\n") { program ->
            val steps = program.steps.joinToString(";") { "${it.modeId},${it.seconds},${it.hz}" }
            "${program.id}|${sanitizeName(program.name)}|$steps"
        }

    /** Reads programs back, silently skipping any line that is damaged or no longer valid. */
    fun decodeAll(text: String?): List<SavedProgram> =
        text.orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull { line ->
            val parts = line.split('|')
            if (parts.size != 3) return@mapNotNull null
            val id = parts[0].toLongOrNull() ?: return@mapNotNull null
            val steps = parts[2].split(';').map { raw ->
                val fields = raw.split(',')
                if (fields.size != 3) return@mapNotNull null
                ProgramStep(
                    modeId = fields[0],
                    seconds = fields[1].toIntOrNull() ?: return@mapNotNull null,
                    hz = fields[2].toIntOrNull() ?: return@mapNotNull null,
                )
            }
            SavedProgram(id, parts[1], steps).takeIf { validate(it) == null }
        }.toList()
}
