package com.speakercorepurger.app.logic

import java.util.Calendar
import java.util.TimeZone

/** When the weekly health-check reminder fires: one week from now, at 18:00 local time. */
object ReminderTime {
    const val HOUR = 18

    fun next(nowMillis: Long, zone: TimeZone = TimeZone.getDefault()): Long {
        val calendar = Calendar.getInstance(zone)
        calendar.timeInMillis = nowMillis
        calendar.add(Calendar.DAY_OF_YEAR, 7)
        calendar.set(Calendar.HOUR_OF_DAY, HOUR)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return calendar.timeInMillis
    }
}
