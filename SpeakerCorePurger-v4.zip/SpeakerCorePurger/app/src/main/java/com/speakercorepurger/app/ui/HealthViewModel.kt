package com.speakercorepurger.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.speakercorepurger.app.PurgerApp
import com.speakercorepurger.app.audio.AudioFailureException
import com.speakercorepurger.app.audio.AudioRoute
import com.speakercorepurger.app.audio.HealthCheckSpec
import com.speakercorepurger.app.audio.SpeakerHealthCheck
import com.speakercorepurger.app.audio.ToneEngine
import com.speakercorepurger.app.data.HealthAssessment
import com.speakercorepurger.app.data.HealthResult
import com.speakercorepurger.app.logic.Recommendation
import com.speakercorepurger.app.logic.RecommendationEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

enum class HealthPhase { IDLE, RUNNING }

enum class HealthMessage { HEADPHONES, AUDIO_BUSY, INTERRUPTED, TEST_FAILED, NO_PERMISSION }

/** One point of the trend chart: when the check happened and its score. */
data class HealthPoint(val takenAt: Long, val score: Int)

data class HealthUiState(
    val phase: HealthPhase = HealthPhase.IDLE,
    val progress: Float = 0f,
    val currentHz: Int = 0,
    /** The newest check, judged against the saved reference if there is one. */
    val latest: HealthAssessment? = null,
    val previousScore: Int? = null,
    /** Scores of all stored checks, oldest first, all judged against the current reference. */
    val trend: List<HealthPoint> = emptyList(),
    val hasReference: Boolean = false,
    val latestIsReference: Boolean = false,
    val recommendation: Recommendation? = null,
    val message: HealthMessage? = null,
    val checkCount: Int = 0,
)

private data class HealthRun(
    val phase: HealthPhase = HealthPhase.IDLE,
    val progress: Float = 0f,
    val hz: Int = 0,
    val message: HealthMessage? = null,
)

class HealthViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PurgerApp
    private val repo = app.healthRepository
    private val engine = ToneEngine()
    private val healthCheck = SpeakerHealthCheck(engine)
    private val run = MutableStateFlow(HealthRun())
    private var job: Job? = null

    val uiState: StateFlow<HealthUiState> = combine(repo.results, repo.reference, run) { results, reference, state ->
        val assessed = results.map { HealthAssessment(it, reference) }
        val latest = assessed.firstOrNull()
        HealthUiState(
            phase = state.phase,
            progress = state.progress,
            currentHz = state.hz,
            latest = latest,
            previousScore = assessed.getOrNull(1)?.score,
            trend = assessed.reversed().map { HealthPoint(it.result.takenAt, it.score) },
            hasReference = reference != null,
            latestIsReference = latest != null && reference != null && latest.result.takenAt == reference.takenAt,
            recommendation = latest?.let { RecommendationEngine.recommend(it) },
            message = state.message,
            checkCount = results.size,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HealthUiState())

    fun isRunning(): Boolean = job?.isActive == true

    /** Starts a check. The caller must already hold the microphone permission. */
    fun start() {
        if (job?.isActive == true) return
        job = viewModelScope.launch { runCheck() }
    }

    fun stop() {
        job?.cancel()
    }

    fun dismissMessage() {
        run.update { it.copy(message = null) }
    }

    fun reportPermissionDenied() {
        run.update { it.copy(message = HealthMessage.NO_PERMISSION) }
    }

    fun saveLatestAsReference() {
        val latest = uiState.value.latest ?: return
        viewModelScope.launch { repo.setReference(latest.result) }
    }

    fun clearReference() {
        viewModelScope.launch { repo.clearReference() }
    }

    fun clearAll() {
        viewModelScope.launch { repo.clearAll() }
    }

    private suspend fun runCheck() {
        if (AudioRoute.externalOutputConnected(app)) {
            run.update { it.copy(message = HealthMessage.HEADPHONES) }
            return
        }
        var failure: HealthMessage? = null
        val self = coroutineContext[Job]
        val focus = AudioRoute.requestFocus(app) {
            failure = HealthMessage.INTERRUPTED
            self?.cancel()
        }
        if (focus == null) {
            run.update { it.copy(message = HealthMessage.AUDIO_BUSY) }
            return
        }
        // The test needs a loud, repeatable signal, so the volume always goes to maximum and is restored.
        val previousVolume = AudioRoute.raiseVolumeToMax(app)
        run.update { HealthRun(phase = HealthPhase.RUNNING, hz = HealthCheckSpec.FREQS_HZ[0]) }
        try {
            val bands = healthCheck.run { progress, hz -> run.update { it.copy(progress = progress, hz = hz) } }
            repo.add(HealthResult(System.currentTimeMillis(), bands))
        } catch (e: AudioFailureException) {
            failure = HealthMessage.TEST_FAILED
        } catch (e: SecurityException) {
            failure = HealthMessage.NO_PERMISSION
        } finally {
            withContext(NonCancellable) {
                previousVolume?.let { AudioRoute.restoreVolume(app, it) }
                focus.abandon()
                run.update { HealthRun(message = failure) }
            }
        }
    }

    override fun onCleared() {
        job?.cancel()
        super.onCleared()
    }
}
