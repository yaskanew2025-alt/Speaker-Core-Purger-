package com.speakercorepurger.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.speakercorepurger.app.PurgerApp
import com.speakercorepurger.app.data.AppSettings
import com.speakercorepurger.app.data.PurgeSession
import com.speakercorepurger.app.data.ThemeMode
import com.speakercorepurger.app.notify.Notifier
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Holds app-wide settings and purge history. `null` means "still loading from disk". */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PurgerApp
    private val settingsRepo = app.settingsRepository
    private val historyRepo = app.historyRepository
    private val healthRepo = app.healthRepository

    val settings: StateFlow<AppSettings?> = settingsRepo.settings
        .map<AppSettings, AppSettings?> { it }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val history: StateFlow<List<PurgeSession>?> = historyRepo.sessions
        .map<List<PurgeSession>, List<PurgeSession>?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun setOnboardingDone(done: Boolean) {
        viewModelScope.launch { settingsRepo.setOnboardingDone(done) }
    }

    fun setTheme(theme: ThemeMode) {
        viewModelScope.launch { settingsRepo.setTheme(theme) }
    }

    fun setVibrate(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setVibrate(enabled) }
    }

    fun setAutoMaxVolume(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setAutoMaxVolume(enabled) }
    }

    fun setDynamicColor(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setDynamicColor(enabled) }
    }

    /** Turns the weekly health-check reminder on or off and schedules or cancels its alarm. */
    fun setWeeklyReminder(enabled: Boolean) {
        if (enabled) Notifier.scheduleReminder(app) else Notifier.cancelReminder(app)
        viewModelScope.launch { settingsRepo.setWeeklyReminder(enabled) }
    }

    fun clearHealthData() {
        viewModelScope.launch { healthRepo.clearAll() }
    }

    fun clearHistory() {
        viewModelScope.launch { historyRepo.clear() }
    }
}
