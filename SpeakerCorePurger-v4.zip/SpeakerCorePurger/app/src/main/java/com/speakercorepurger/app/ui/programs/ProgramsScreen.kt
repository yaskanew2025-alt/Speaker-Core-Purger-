package com.speakercorepurger.app.ui.programs

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speakercorepurger.app.R
import com.speakercorepurger.app.audio.CUSTOM_MAX_HZ
import com.speakercorepurger.app.audio.CUSTOM_MIN_HZ
import com.speakercorepurger.app.audio.DEFAULT_CUSTOM_HZ
import com.speakercorepurger.app.audio.PurgeMode
import com.speakercorepurger.app.data.ProgramCodec
import com.speakercorepurger.app.data.ProgramIssue
import com.speakercorepurger.app.data.ProgramStep
import com.speakercorepurger.app.data.SavedProgram
import com.speakercorepurger.app.ui.PurgePhase
import com.speakercorepurger.app.ui.PurgeViewModel
import com.speakercorepurger.app.ui.ProgramsViewModel
import com.speakercorepurger.app.ui.common.SectionCard
import com.speakercorepurger.app.ui.durationLabel
import com.speakercorepurger.app.ui.formatClock
import com.speakercorepurger.app.ui.titleRes
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

private val STEP_SECONDS = listOf(10, 20, 30, 60, 120, 180, 300)

/** Sentinel for "creating a new program" in the editor state (real ids are timestamps). */
private const val NEW_PROGRAM_ID = 0L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgramsScreen(
    programsVm: ProgramsViewModel,
    purge: PurgeViewModel,
    onPlay: () -> Unit,
    onBack: () -> Unit,
) {
    val programs by programsVm.programs.collectAsStateWithLifecycle()
    val purgeState by purge.uiState.collectAsStateWithLifecycle()
    var editingId by rememberSaveable { mutableStateOf<Long?>(null) }
    var deleteTarget by remember { mutableStateOf<SavedProgram?>(null) }
    val list = programs

    val editing: SavedProgram? = when (val id = editingId) {
        null -> null
        NEW_PROGRAM_ID -> SavedProgram(NEW_PROGRAM_ID, "", listOf(ProgramStep(PurgeMode.WATER.id, 30, DEFAULT_CUSTOM_HZ.toInt())))
        else -> list?.firstOrNull { it.id == id }
    }

    BackHandler(enabled = editingId != null) { editingId = null }

    if (editing != null) {
        ProgramEditor(
            initial = editing,
            onSave = { program, onIssue ->
                programsVm.save(program.copy(id = if (program.id == NEW_PROGRAM_ID) System.currentTimeMillis() else program.id)) { issue ->
                    if (issue == null) editingId = null else onIssue(issue)
                }
            },
            onCancel = { editingId = null },
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.programs_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back))
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(
                    text = stringResource(R.string.programs_intro),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(
                    onClick = { editingId = NEW_PROGRAM_ID },
                    enabled = (list?.size ?: 0) < ProgramCodec.MAX_PROGRAMS,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp),
                ) { Text(stringResource(R.string.programs_new)) }

                if (list != null && list.isEmpty()) {
                    Text(
                        text = stringResource(R.string.programs_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                list?.forEach { program ->
                    ProgramCard(
                        program = program,
                        playing = purgeState.phase == PurgePhase.RUNNING,
                        onPlay = {
                            purge.acknowledgeCompletion()
                            purge.startProgram(program)
                            onPlay()
                        },
                        onEdit = { editingId = program.id },
                        onDelete = { deleteTarget = program },
                    )
                }
            }
        }
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(stringResource(R.string.programs_delete_title, target.name)) },
            text = { Text(stringResource(R.string.programs_delete_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        programsVm.delete(target.id)
                        deleteTarget = null
                    },
                ) { Text(stringResource(R.string.programs_delete_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text(stringResource(R.string.action_cancel)) }
            },
        )
    }
}

@Composable
private fun ProgramCard(
    program: SavedProgram,
    playing: Boolean,
    onPlay: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    SectionCard(
        title = program.name,
        body = stringResource(R.string.programs_summary, program.steps.size, formatClock(program.totalSec)),
    ) {
        val stepTexts = program.steps.map { step ->
            stringResource(R.string.programs_step_summary, stringResource(PurgeMode.fromId(step.modeId).titleRes()), step.seconds)
        }
        Text(
            text = stepTexts.joinToString(" → "),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onPlay, enabled = !playing, modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.programs_play))
            }
            OutlinedButton(onClick = onEdit, modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.programs_edit))
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.programs_delete_cd, program.name))
            }
        }
    }
}

/** Editable copy of a [ProgramStep]. */
private class StepDraft(modeId: String, seconds: Int, hz: Int) {
    var modeId by mutableStateOf(modeId)
    var seconds by mutableStateOf(seconds)
    var hz by mutableStateOf(hz)
    fun toStep() = ProgramStep(modeId, seconds, hz)
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun ProgramEditor(
    initial: SavedProgram,
    onSave: (SavedProgram, onIssue: (ProgramIssue) -> Unit) -> Unit,
    onCancel: () -> Unit,
) {
    var name by rememberSaveable(initial.id) { mutableStateOf(initial.name) }
    val steps: SnapshotStateList<StepDraft> = remember(initial.id) {
        initial.steps.map { StepDraft(it.modeId, it.seconds, it.hz) }.toMutableStateList()
    }
    var serverIssue by remember { mutableStateOf<ProgramIssue?>(null) }
    val draft = SavedProgram(initial.id, name, steps.map { it.toStep() })
    val issue = ProgramCodec.validate(draft)
    val total = draft.totalSec

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(stringResource(if (initial.id == NEW_PROGRAM_ID) R.string.programs_new else R.string.programs_edit))
                },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back))
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(ProgramCodec.MAX_NAME) },
                    label = { Text(stringResource(R.string.programs_name)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                steps.forEachIndexed { index, step ->
                    StepEditor(
                        index = index,
                        step = step,
                        canRemove = steps.size > 1,
                        onRemove = { steps.removeAt(index) },
                    )
                }

                OutlinedButton(
                    onClick = { steps.add(StepDraft(PurgeMode.WATER.id, 30, DEFAULT_CUSTOM_HZ.toInt())) },
                    enabled = steps.size < ProgramCodec.MAX_STEPS,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(stringResource(R.string.programs_add_step)) }

                Text(
                    text = stringResource(R.string.programs_total, formatClock(total), ProgramCodec.MAX_TOTAL_SEC / 60),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                val shown = serverIssue ?: issue
                if (shown != null) {
                    Text(
                        text = stringResource(issueText(shown)),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                Button(
                    onClick = { onSave(draft) { serverIssue = it } },
                    enabled = issue == null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp),
                ) { Text(stringResource(R.string.programs_save)) }
                OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        }
    }
}

private fun issueText(issue: ProgramIssue): Int = when (issue) {
    ProgramIssue.NAME_EMPTY -> R.string.programs_issue_name
    ProgramIssue.NO_STEPS -> R.string.programs_issue_steps
    ProgramIssue.TOO_MANY_STEPS -> R.string.programs_issue_too_many
    ProgramIssue.STEP_LENGTH -> R.string.programs_issue_step_length
    ProgramIssue.TOO_LONG -> R.string.programs_issue_too_long
    ProgramIssue.BAD_MODE -> R.string.programs_issue_mode
    ProgramIssue.BAD_FREQUENCY -> R.string.programs_issue_frequency
    ProgramIssue.TOO_MANY_PROGRAMS -> R.string.programs_issue_too_many_programs
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StepEditor(index: Int, step: StepDraft, canRemove: Boolean, onRemove: () -> Unit) {
    SectionCard(title = stringResource(R.string.programs_step, index + 1)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PurgeMode.entries.forEach { mode ->
                FilterChip(
                    selected = step.modeId == mode.id,
                    onClick = { step.modeId = mode.id },
                    label = { Text(stringResource(mode.titleRes())) },
                )
            }
        }
        if (step.modeId == PurgeMode.CUSTOM.id) {
            val logMin = ln(CUSTOM_MIN_HZ)
            val logMax = ln(CUSTOM_MAX_HZ)
            val hz = step.hz.toFloat().coerceIn(CUSTOM_MIN_HZ, CUSTOM_MAX_HZ)
            Text(
                text = stringResource(R.string.custom_frequency_label, hz.roundToInt()),
                style = MaterialTheme.typography.titleSmall,
            )
            Slider(
                value = (ln(hz) - logMin) / (logMax - logMin),
                onValueChange = { step.hz = exp(logMin + it * (logMax - logMin)).roundToInt() },
                valueRange = 0f..1f,
                modifier = Modifier.semantics { contentDescription = "${hz.roundToInt()} Hz" },
            )
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            STEP_SECONDS.forEach { seconds ->
                FilterChip(
                    selected = step.seconds == seconds,
                    onClick = { step.seconds = seconds },
                    label = { Text(durationLabel(seconds)) },
                )
            }
        }
        if (canRemove) {
            TextButton(onClick = onRemove) {
                Text(
                    text = stringResource(R.string.programs_remove_step),
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}
