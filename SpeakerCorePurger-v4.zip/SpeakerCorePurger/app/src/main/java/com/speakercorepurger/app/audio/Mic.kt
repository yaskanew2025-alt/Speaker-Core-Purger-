package com.speakercorepurger.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build

/** Opens the phone microphone for analysis. Audio is only ever processed in memory. */
object Mic {
    const val SAMPLE_RATE = 44_100

    /**
     * Opens a mono 16-bit recorder. The unprocessed source is preferred (no automatic gain or noise
     * suppression, so levels are honest); the normal microphone source is the fallback. The caller must
     * hold the RECORD_AUDIO permission and must call `release()` on the result.
     * Throws [AudioFailureException] when no microphone can be opened.
     */
    @SuppressLint("MissingPermission")
    fun open(): AudioRecord {
        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        if (minBuffer <= 0) throw AudioFailureException("Unsupported microphone configuration ($minBuffer)")
        val bufferBytes = maxOf(minBuffer, SAMPLE_RATE / 2 * 2)
        val sources = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) add(MediaRecorder.AudioSource.UNPROCESSED)
            add(MediaRecorder.AudioSource.MIC)
        }
        for (source in sources) {
            val record = try {
                AudioRecord(
                    source,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferBytes,
                )
            } catch (e: Exception) {
                null
            }
            if (record != null) {
                if (record.state == AudioRecord.STATE_INITIALIZED) return record
                record.release()
            }
        }
        throw AudioFailureException("Microphone could not be opened")
    }
}
