package com.speakercorepurger.app.ui.purge

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.semantics.clearAndSetSemantics
import kotlin.math.PI
import kotlin.math.ln
import kotlin.math.sin

private const val BAR_COUNT = 28

/**
 * Animated bars that follow the real output level of the sound being played. Higher frequencies
 * make the bar pattern ripple faster, so each mode looks different. Decorative only.
 */
@Composable
fun LiveVisualizer(level: Float, hz: Int, modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.primary
    val smoothLevel by animateFloatAsState(level.coerceIn(0f, 1f), tween(120, easing = LinearEasing), label = "level")
    val phase by rememberInfiniteTransition(label = "viz").animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    val spread = 0.25f + 0.9f * (ln(hz.coerceIn(150, 10_000) / 150f) / ln(10_000f / 150f))

    Canvas(modifier = modifier.clearAndSetSemantics { }) {
        val gap = size.width / (BAR_COUNT * 2f)
        val barWidth = (size.width - gap * (BAR_COUNT - 1)) / BAR_COUNT
        for (i in 0 until BAR_COUNT) {
            val wave = 0.5f + 0.5f * sin(phase + i * spread)
            val fraction = (0.10f + 0.90f * smoothLevel * wave).coerceIn(0.08f, 1f)
            val barHeight = size.height * fraction
            drawRoundRect(
                color = color.copy(alpha = 0.45f + 0.55f * fraction),
                topLeft = Offset(i * (barWidth + gap), (size.height - barHeight) / 2f),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
            )
        }
    }
}
