package com.speakercorepurger.app.logic

import com.speakercorepurger.app.data.PurgeSession
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class UsageStats(
    val sessions: Int,
    val completed: Int,
    val totalSec: Int,
    /** Consecutive days with at least one session, counting back from today (or yesterday). */
    val streakDays: Int,
    /** Seconds played on each of the last 7 days, oldest first; the last entry is today. */
    val last7Sec: List<Int>,
    /** Total seconds per mode id (programs are grouped under "program"). */
    val secondsByMode: Map<String, Int>,
    val favoriteModeId: String?,
)

object StatsCalculator {
    private const val DAY_MS = 86_400_000L

    /** [offsetMillis] returns the time-zone offset in milliseconds for an instant. */
    fun compute(
        sessions: List<PurgeSession>,
        nowMillis: Long,
        offsetMillis: (Long) -> Int = { TimeZone.getDefault().getOffset(it) },
    ): UsageStats {
        fun dayOf(ms: Long): Long = Math.floorDiv(ms + offsetMillis(ms), DAY_MS)

        val today = dayOf(nowMillis)
        val secondsPerDay = HashMap<Long, Int>()
        val byMode = LinkedHashMap<String, Int>()
        var total = 0
        for (s in sessions) {
            val seconds = s.playedSec.coerceAtLeast(0)
            total += seconds
            val day = dayOf(s.startedAt)
            secondsPerDay[day] = (secondsPerDay[day] ?: 0) + seconds
            byMode[s.modeId] = (byMode[s.modeId] ?: 0) + seconds
        }

        val activeDays = sessions.map { dayOf(it.startedAt) }.toSet()
        var cursor = when {
            today in activeDays -> today
            (today - 1) in activeDays -> today - 1
            else -> Long.MIN_VALUE
        }
        var streak = 0
        while (cursor != Long.MIN_VALUE && cursor in activeDays) {
            streak++
            cursor--
        }

        val last7 = (6 downTo 0).map { secondsPerDay[today - it] ?: 0 }
        val favorite = byMode.maxByOrNull { it.value }?.takeIf { it.value > 0 }?.key
        return UsageStats(
            sessions = sessions.size,
            completed = sessions.count { it.completed },
            totalSec = total,
            streakDays = streak,
            last7Sec = last7,
            secondsByMode = byMode,
            favoriteModeId = favorite,
        )
    }
}

object HistoryExport {
    /** CSV text with one row per session, newest first, ready to share. */
    fun toCsv(sessions: List<PurgeSession>, zone: TimeZone = TimeZone.getDefault()): String {
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = zone }
        val out = StringBuilder("started_at,mode,program,planned_seconds,played_seconds,completed,custom_hz\n")
        for (s in sessions) {
            out.append(format.format(Date(s.startedAt))).append(',')
                .append(csvField(s.modeId)).append(',')
                .append(csvField(s.label.orEmpty())).append(',')
                .append(s.plannedSec).append(',')
                .append(s.playedSec).append(',')
                .append(if (s.completed) "yes" else "no").append(',')
                .append(s.customHz?.toString().orEmpty()).append('\n')
        }
        return out.toString()
    }

    private fun csvField(value: String): String =
        if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }
}
