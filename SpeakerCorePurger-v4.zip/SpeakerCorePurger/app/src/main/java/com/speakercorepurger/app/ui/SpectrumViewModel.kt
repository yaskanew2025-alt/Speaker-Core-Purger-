package com.speakercorepurger.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.speakercorepurger.app.audio.AudioFailureException
import com.speakercorepurger.app.audio.MicMonitor
import com.speakercorepurger.app.audio.SpectrumFrame
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SpectrumUiState(
    val listening: Boolean = false,
    val frame: SpectrumFrame? = null,
    val failed: Boolean = false,
)

/** Live microphone spectrum for the Tools screen. Starts and stops on request; nothing is recorded. */
class SpectrumViewModel(application: Application) : AndroidViewModel(application) {

    private val monitor = MicMonitor()
    private val _state = MutableStateFlow(SpectrumUiState())
    val uiState: StateFlow<SpectrumUiState> = _state
    private var job: Job? = null

    /** Starts listening. The caller must already hold the microphone permission. */
    fun start() {
        if (job?.isActive == true) return
        _state.value = SpectrumUiState(listening = true)
        job = viewModelScope.launch {
            try {
                monitor.run { frame -> _state.update { it.copy(frame = frame) } }
            } catch (e: AudioFailureException) {
                _state.update { it.copy(failed = true) }
            } catch (e: SecurityException) {
                _state.update { it.copy(failed = true) }
            } finally {
                _state.update { it.copy(listening = false) }
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    fun reportFailure() {
        _state.update { it.copy(failed = true) }
    }

    fun dismissFailure() {
        _state.update { it.copy(failed = false) }
    }

    override fun onCleared() {
        job?.cancel()
        super.onCleared()
    }
}
