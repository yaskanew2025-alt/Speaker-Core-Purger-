package com.speakercorepurger.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

/** Stores speaker health checks (newest first) and the optional clean reference check. */
class HealthRepository(private val context: Context) {

    private val resultsKey = stringPreferencesKey("health_results")
    private val referenceKey = stringPreferencesKey("health_reference")

    val results: Flow<List<HealthResult>> = context.appDataStore.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { prefs -> HealthResult.decodeAll(prefs[resultsKey]) }

    val reference: Flow<HealthResult?> = context.appDataStore.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { prefs -> prefs[referenceKey]?.let { HealthResult.decode(it) } }

    suspend fun add(result: HealthResult) {
        context.appDataStore.edit { prefs ->
            val updated = listOf(result) + HealthResult.decodeAll(prefs[resultsKey])
            prefs[resultsKey] = HealthResult.encodeAll(updated)
        }
    }

    suspend fun setReference(result: HealthResult) {
        context.appDataStore.edit { it[referenceKey] = result.encode() }
    }

    suspend fun clearReference() {
        context.appDataStore.edit { it.remove(referenceKey) }
    }

    suspend fun clearAll() {
        context.appDataStore.edit {
            it.remove(resultsKey)
            it.remove(referenceKey)
        }
    }
}
