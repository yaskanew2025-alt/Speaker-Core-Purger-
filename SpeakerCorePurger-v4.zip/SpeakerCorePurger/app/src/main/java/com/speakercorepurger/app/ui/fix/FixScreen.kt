package com.speakercorepurger.app.ui.fix

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speakercorepurger.app.R
import com.speakercorepurger.app.ui.FixStage
import com.speakercorepurger.app.ui.FixViewModel
import com.speakercorepurger.app.ui.HealthMessage
import com.speakercorepurger.app.ui.HealthPhase
import com.speakercorepurger.app.ui.HealthViewModel
import com.speakercorepurger.app.ui.PurgeMessage
import com.speakercorepurger.app.ui.PurgePhase
import com.speakercorepurger.app.ui.PurgeViewModel
import com.speakercorepurger.app.ui.ToolsViewModel
import com.speakercorepurger.app.ui.common.MessageBanner
import com.speakercorepurger.app.ui.common.SectionCard
import com.speakercorepurger.app.ui.formatClock
import com.speakercorepurger.app.ui.purge.LiveVisualizer
import com.speakercorepurger.app.ui.purge.PurgeOrb
import com.speakercorepurger.app.ui.rememberPermissionRequest
import com.speakercorepurger.app.ui.textRes
import com.speakercorepurger.app.ui.titleRes

private const val DRYING_MINUTES_AFTER_RESCUE = 30

/**
 * The guided fix (after a health check) and the water-rescue flow share this screen:
 * purge, then check again and compare. The flow is started by [FixViewModel.begin] before navigating here.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FixScreen(
    fix: FixViewModel,
    purge: PurgeViewModel,
    health: HealthViewModel,
    tools: ToolsViewModel,
    onClose: () -> Unit,
) {
    val fixState by fix.state.collectAsStateWithLifecycle()
    val purgeState by purge.uiState.collectAsStateWithLifecycle()
    val healthState by health.uiState.collectAsStateWithLifecycle()
    val tool by tools.uiState.collectAsStateWithLifecycle()
    val view = LocalView.current

    val purgeRunning = purgeState.phase == PurgePhase.RUNNING
    val healthRunning = healthState.phase == HealthPhase.RUNNING
    val busy = purgeRunning || healthRunning
    val latestAt = healthState.latest?.result?.takenAt ?: 0L

    DisposableEffect(busy) {
        view.keepScreenOn = busy
        onDispose { view.keepScreenOn = false }
    }

    // Leaving the screen stops whatever this flow started.
    val purgeRunningNow by rememberUpdatedState(purgeRunning)
    val healthRunningNow by rememberUpdatedState(healthRunning)
    DisposableEffect(Unit) {
        onDispose {
            if (purgeRunningNow) purge.stop()
            if (healthRunningNow) health.stop()
        }
    }

    // A new check taken after "check again" ends the flow with a result.
    LaunchedEffect(latestAt, fixState.stage, fixState.recheckAfter) {
        if (fixState.stage == FixStage.RECHECK && latestAt > fixState.recheckAfter) fix.toResult()
    }

    val requestCheck = rememberPermissionRequest(Manifest.permission.RECORD_AUDIO) { granted ->
        if (granted) {
            fix.toRecheck(System.currentTimeMillis())
            health.start()
        } else {
            health.reportPermissionDenied()
        }
    }

    BackHandler(enabled = busy) { /* the stop buttons are the way out while something is playing */ }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(stringResource(if (fixState.rescue) R.string.rescue_title else R.string.fix_title))
                },
                navigationIcon = {
                    IconButton(onClick = onClose, enabled = !busy) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back))
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                healthState.message?.let { message ->
                    MessageBanner(text = stringResource(healthMessageRes(message)), onDismiss = health::dismissMessage)
                }
                when (fixState.stage) {
                    FixStage.INTRO -> IntroStage(
                        rescue = fixState.rescue,
                        modeTitle = stringResource(fixState.mode.titleRes()),
                        minutes = fixState.durationSec / 60,
                        scoreBefore = fixState.scoreBefore,
                        onStart = {
                            purge.acknowledgeCompletion()
                            purge.startPlan(fixState.mode, fixState.durationSec)
                            fix.toPurge()
                        },
                        onCancel = onClose,
                    )

                    FixStage.PURGE -> PurgeStage(
                        rescue = fixState.rescue,
                        phase = purgeState.phase,
                        progress = purgeState.progress,
                        remainingSec = purgeState.remainingSec,
                        hz = purgeState.frequencyHz,
                        level = purgeState.level,
                        message = purgeState.message,
                        dryingActive = tool.dryingEndsAt > System.currentTimeMillis(),
                        onStop = purge::stop,
                        onRetry = {
                            purge.dismissMessage()
                            purge.startPlan(fixState.mode, fixState.durationSec)
                        },
                        onDismissMessage = purge::dismissMessage,
                        onStartDrying = { tools.startDrying(DRYING_MINUTES_AFTER_RESCUE) },
                        onCheck = {
                            purge.acknowledgeCompletion()
                            requestCheck()
                        },
                        onLeave = onClose,
                    )

                    FixStage.RECHECK -> RecheckStage(
                        running = healthRunning,
                        progress = healthState.progress,
                        hz = healthState.currentHz,
                        onStop = health::stop,
                        onRetry = requestCheck,
                        onLeave = onClose,
                    )

                    FixStage.RESULT -> ResultStage(
                        scoreBefore = fixState.scoreBefore,
                        scoreAfter = healthState.latest?.score ?: 0,
                        hasReference = healthState.hasReference,
                        onAnother = { fix.another(healthState.latest?.score) },
                        onDone = onClose,
                    )
                }
            }
        }
    }
}

private fun healthMessageRes(message: HealthMessage): Int = when (message) {
    HealthMessage.HEADPHONES -> R.string.health_msg_headphones
    HealthMessage.AUDIO_BUSY -> R.string.msg_audio_busy
    HealthMessage.INTERRUPTED -> R.string.health_msg_interrupted
    HealthMessage.TEST_FAILED -> R.string.health_msg_failed
    HealthMessage.NO_PERMISSION -> R.string.health_msg_permission
}

@Composable
private fun IntroStage(
    rescue: Boolean,
    modeTitle: String,
    minutes: Int,
    scoreBefore: Int?,
    onStart: () -> Unit,
    onCancel: () -> Unit,
) {
    if (rescue) {
        SectionCard(
            title = stringResource(R.string.rescue_steps_title),
            body = stringResource(R.string.rescue_steps_body),
        ) {
            Text(stringResource(R.string.rescue_step_1), style = MaterialTheme.typography.bodyMedium)
            Text(stringResource(R.string.rescue_step_2), style = MaterialTheme.typography.bodyMedium)
            Text(stringResource(R.string.rescue_step_3), style = MaterialTheme.typography.bodyMedium)
            Text(stringResource(R.string.rescue_step_4), style = MaterialTheme.typography.bodyMedium)
        }
    } else {
        SectionCard(
            title = stringResource(R.string.fix_plan_title),
            body = stringResource(R.string.fix_plan_body, modeTitle, minutes),
        ) {
            if (scoreBefore != null) {
                Text(
                    text = stringResource(R.string.fix_score_before, scoreBefore),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
    Text(
        text = stringResource(R.string.info_safety),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Button(
        onClick = onStart,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp),
    ) {
        Text(
            text = if (rescue) {
                stringResource(R.string.rescue_start, minutes)
            } else {
                stringResource(R.string.fix_start, modeTitle, minutes)
            },
            style = MaterialTheme.typography.titleMedium,
        )
    }
    OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.action_cancel))
    }
}

@Composable
private fun PurgeStage(
    rescue: Boolean,
    phase: PurgePhase,
    progress: Float,
    remainingSec: Int,
    hz: Int,
    level: Float,
    message: PurgeMessage?,
    dryingActive: Boolean,
    onStop: () -> Unit,
    onRetry: () -> Unit,
    onDismissMessage: () -> Unit,
    onStartDrying: () -> Unit,
    onCheck: () -> Unit,
    onLeave: () -> Unit,
) {
    when (phase) {
        PurgePhase.RUNNING -> {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                PurgeOrb(running = true, active = true, progress = progress, size = 220.dp) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = formatClock(remainingSec),
                            color = Color.White,
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = stringResource(R.string.orb_hz, hz),
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                }
                LiveVisualizer(level = level, hz = hz, modifier = Modifier.fillMaxWidth().height(40.dp))
                Button(
                    onClick = onStop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError,
                    ),
                ) { Text(stringResource(R.string.action_stop), style = MaterialTheme.typography.titleMedium) }
            }
        }

        PurgePhase.COMPLETED -> {
            SectionCard(
                title = stringResource(R.string.fix_purge_done_title),
                body = stringResource(R.string.fix_purge_done_body),
            ) {
                if (rescue) {
                    if (dryingActive) {
                        Text(
                            text = stringResource(R.string.rescue_drying_started),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.tertiary,
                        )
                    } else {
                        OutlinedButton(onClick = onStartDrying, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.rescue_start_drying, DRYING_MINUTES_AFTER_RESCUE))
                        }
                    }
                }
            }
            Button(onClick = onCheck, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text(stringResource(R.string.fix_check_again), style = MaterialTheme.typography.titleMedium)
            }
            OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.action_done))
            }
        }

        PurgePhase.IDLE -> {
            message?.let { MessageBanner(text = stringResource(it.textRes()), onDismiss = onDismissMessage) }
            Text(
                text = stringResource(R.string.fix_purge_idle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(onClick = onRetry, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text(stringResource(R.string.fix_try_again), style = MaterialTheme.typography.titleMedium)
            }
            OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.fix_leave))
            }
        }
    }
}

@Composable
private fun RecheckStage(
    running: Boolean,
    progress: Float,
    hz: Int,
    onStop: () -> Unit,
    onRetry: () -> Unit,
    onLeave: () -> Unit,
) {
    if (running) {
        SectionCard(
            title = stringResource(R.string.health_running_title),
            body = stringResource(R.string.health_running_body),
        ) {
            Text(
                text = stringResource(R.string.health_running_tone, hz),
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = onStop,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError,
                ),
            ) { Text(stringResource(R.string.action_stop)) }
        }
    } else {
        Text(
            text = stringResource(R.string.fix_recheck_stopped),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
            Text(stringResource(R.string.fix_check_again), style = MaterialTheme.typography.titleMedium)
        }
        OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.fix_leave))
        }
    }
}

@Composable
private fun ResultStage(
    scoreBefore: Int?,
    scoreAfter: Int,
    hasReference: Boolean,
    onAnother: () -> Unit,
    onDone: () -> Unit,
) {
    val delta = scoreBefore?.let { scoreAfter - it }
    val verdict = when {
        scoreAfter >= 85 -> stringResource(R.string.fix_result_clear)
        delta == null -> stringResource(R.string.fix_result_unknown)
        delta >= 10 -> stringResource(R.string.fix_result_better)
        delta <= -10 -> stringResource(R.string.fix_result_worse)
        else -> stringResource(R.string.fix_result_same)
    }
    SectionCard(title = stringResource(R.string.fix_result_title), body = verdict) {
        if (scoreBefore != null) {
            Text(
                text = stringResource(R.string.fix_result_scores, scoreBefore, scoreAfter),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        } else {
            Text(
                text = stringResource(R.string.fix_result_score_only, scoreAfter),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        if (!hasReference) {
            Text(
                text = stringResource(R.string.health_no_reference_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
    if (scoreAfter < 85) {
        Button(onClick = onAnother, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
            Text(stringResource(R.string.fix_another), style = MaterialTheme.typography.titleMedium)
        }
        OutlinedButton(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.action_done))
        }
    } else {
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
            Text(stringResource(R.string.action_done), style = MaterialTheme.typography.titleMedium)
        }
    }
}
