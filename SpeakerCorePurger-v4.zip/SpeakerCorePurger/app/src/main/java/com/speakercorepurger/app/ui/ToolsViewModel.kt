package com.speakercorepurger.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.speakercorepurger.app.PurgerApp
import com.speakercorepurger.app.audio.AudioFailureException
import com.speakercorepurger.app.audio.AudioRoute
import com.speakercorepurger.app.audio.CUSTOM_MAX_HZ
import com.speakercorepurger.app.audio.CUSTOM_MIN_HZ
import com.speakercorepurger.app.audio.PureToneVoice
import com.speakercorepurger.app.audio.SweepVoice
import com.speakercorepurger.app.audio.ToneEngine
import com.speakercorepurger.app.audio.Voice
import com.speakercorepurger.app.notify.Notifier
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.roundToInt

enum class ToolPlayback { NONE, TONE, SWEEP }

enum class ToolMessage { HEADPHONES_CONNECTED, AUDIO_ERROR, AUDIO_BUSY, INTERRUPTED }

data class ToolsUiState(
    val playing: ToolPlayback = ToolPlayback.NONE,
    val toneHz: Float = DEFAULT_TONE_HZ,
    val currentHz: Int = 0,
    /** 1-based step of the sweep test while it plays, otherwise 0. */
    val sweepStep: Int = 0,
    val level: Float = 0f,
    val message: ToolMessage? = null,
    /** Epoch millis when the drying timer ends, or 0 when none is running. */
    val dryingEndsAt: Long = 0L,
)

private data class ToolRun(
    val playing: ToolPlayback = ToolPlayback.NONE,
    val toneHz: Float = DEFAULT_TONE_HZ,
    val currentHz: Int = 0,
    val sweepStep: Int = 0,
    val level: Float = 0f,
    val message: ToolMessage? = null,
)

private const val DEFAULT_TONE_HZ = 1_000f
private const val TONE_MAX_MS = 60_000L

/** Tone tester, sweep test and drying timer. Playback never changes the system volume. */
class ToolsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as PurgerApp
    private val settingsRepo = app.settingsRepository
    private val engine = ToneEngine()
    private val run = MutableStateFlow(ToolRun())
    private var job: Job? = null

    val uiState: StateFlow<ToolsUiState> = combine(settingsRepo.settings, run) { settings, state ->
        ToolsUiState(
            playing = state.playing,
            toneHz = state.toneHz,
            currentHz = state.currentHz,
            sweepStep = state.sweepStep,
            level = state.level,
            message = state.message,
            dryingEndsAt = settings.dryingEndsAt,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ToolsUiState())

    // ---- Tone tester ---------------------------------------------------------------------------

    fun setToneHz(hz: Float) {
        val clamped = hz.coerceIn(CUSTOM_MIN_HZ, CUSTOM_MAX_HZ)
        val wasPlaying = run.value.playing == ToolPlayback.TONE
        run.update { it.copy(toneHz = clamped) }
        if (wasPlaying) startTone()
    }

    fun toggleTone() {
        if (run.value.playing == ToolPlayback.TONE) stop() else startTone()
    }

    private fun startTone() {
        val hz = run.value.toneHz
        launchPlayback(ToolPlayback.TONE, PureToneVoice(hz.toDouble()), TONE_MAX_MS)
    }

    // ---- Sweep test ----------------------------------------------------------------------------

    fun toggleSweep() {
        if (run.value.playing == ToolPlayback.SWEEP) stop() else {
            launchPlayback(ToolPlayback.SWEEP, SweepVoice(), SweepVoice.TOTAL_MS)
        }
    }

    // ---- Shared playback -----------------------------------------------------------------------

    fun stop() {
        job?.cancel()
    }

    fun dismissMessage() {
        run.update { it.copy(message = null) }
    }

    private fun launchPlayback(kind: ToolPlayback, voice: Voice, durationMs: Long) {
        val previous = job
        job = viewModelScope.launch {
            previous?.cancelAndJoin()

            if (AudioRoute.externalOutputConnected(app)) {
                run.update { it.copy(message = ToolMessage.HEADPHONES_CONNECTED) }
                return@launch
            }
            var failure: ToolMessage? = null
            val self = coroutineContext[Job]
            val focus = AudioRoute.requestFocus(app) {
                failure = ToolMessage.INTERRUPTED
                self?.cancel()
            }
            if (focus == null) {
                run.update { it.copy(message = ToolMessage.AUDIO_BUSY) }
                return@launch
            }

            run.update {
                it.copy(playing = kind, currentHz = voice.hz.roundToInt(), sweepStep = 0, level = 0f, message = null)
            }
            try {
                engine.playVoice(voice, durationMs) { playedMs, hz, level ->
                    val step = if (kind == ToolPlayback.SWEEP) {
                        ((playedMs / (SweepVoice.STEP_SEC * 1000)).toInt() + 1).coerceAtMost(SweepVoice.STEP_COUNT)
                    } else {
                        0
                    }
                    run.update { it.copy(currentHz = hz.roundToInt(), sweepStep = step, level = level) }
                }
            } catch (e: AudioFailureException) {
                failure = ToolMessage.AUDIO_ERROR
            } finally {
                withContext(NonCancellable) {
                    focus.abandon()
                    run.update {
                        it.copy(playing = ToolPlayback.NONE, sweepStep = 0, level = 0f, message = failure ?: it.message)
                    }
                }
            }
        }
    }

    // ---- Drying timer --------------------------------------------------------------------------

    fun startDrying(minutes: Int) {
        val endsAt = System.currentTimeMillis() + minutes * 60_000L
        Notifier.scheduleDrying(app, endsAt)
        viewModelScope.launch { settingsRepo.setDryingEndsAt(endsAt) }
    }

    fun cancelDrying() {
        Notifier.cancelDrying(app)
        viewModelScope.launch { settingsRepo.setDryingEndsAt(0L) }
    }

    override fun onCleared() {
        job?.cancel()
        super.onCleared()
    }
}
