package com.speakercorepurger.app.ui.health

import android.Manifest
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speakercorepurger.app.R
import com.speakercorepurger.app.audio.HealthCheckSpec
import com.speakercorepurger.app.data.BandAssessment
import com.speakercorepurger.app.data.BandStatus
import com.speakercorepurger.app.logic.FixAdvice
import com.speakercorepurger.app.logic.HealthReport
import com.speakercorepurger.app.logic.Recommendation
import com.speakercorepurger.app.ui.HealthMessage
import com.speakercorepurger.app.ui.HealthPhase
import com.speakercorepurger.app.ui.HealthUiState
import com.speakercorepurger.app.ui.HealthViewModel
import com.speakercorepurger.app.ui.common.MessageBanner
import com.speakercorepurger.app.ui.common.ScoreChart
import com.speakercorepurger.app.ui.common.ScreenTitle
import com.speakercorepurger.app.ui.common.SectionCard
import com.speakercorepurger.app.ui.rememberPermissionRequest
import com.speakercorepurger.app.ui.titleRes
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

private val Amber = Color(0xFFE0A100)

@Composable
fun HealthScreen(
    vm: HealthViewModel,
    onStartFix: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val view = LocalView.current
    val running = state.phase == HealthPhase.RUNNING
    var confirmClear by rememberSaveable { mutableStateOf(false) }

    val requestStart = rememberPermissionRequest(Manifest.permission.RECORD_AUDIO) { granted ->
        if (granted) vm.start() else vm.reportPermissionDenied()
    }

    // Leaving the screen stops a running check, and the screen stays awake while it runs.
    DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(Unit) {
        onDispose { vm.stop() }
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            ScreenTitle(
                title = stringResource(R.string.health_title),
                subtitle = stringResource(R.string.health_subtitle),
            )

            state.message?.let { message ->
                MessageBanner(text = stringResource(message.textRes()), onDismiss = vm::dismissMessage)
            }

            if (running) {
                RunningCard(state = state, onStop = vm::stop)
            } else {
                state.latest?.let { latest ->
                    ScoreCard(state = state, score = latest.score, takenAt = latest.result.takenAt)
                }
                StartCard(hasResult = state.latest != null, onStart = requestStart)
            }

            state.latest?.let { latest ->
                if (!running) {
                    BandsCard(bands = latest.bands, hasReference = latest.hasReference)
                    state.recommendation?.let { recommendation ->
                        RecommendationCard(recommendation = recommendation, onStartFix = onStartFix)
                    }
                }
            }

            ReferenceCard(
                state = state,
                onSave = vm::saveLatestAsReference,
                onRemove = vm::clearReference,
            )

            if (state.trend.size >= 2) {
                TrendCard(state = state)
            }

            state.latest?.let { latest ->
                ShareButton(text = HealthReport.toText(latest, state.previousScore))
            }

            if (state.checkCount > 0) {
                TextButton(onClick = { confirmClear = true }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text(stringResource(R.string.health_clear))
                }
            }

            Text(
                text = stringResource(R.string.health_disclaimer),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(stringResource(R.string.health_clear_title)) },
            text = { Text(stringResource(R.string.health_clear_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmClear = false
                        vm.clearAll()
                    },
                ) { Text(stringResource(R.string.health_clear_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text(stringResource(R.string.action_cancel)) }
            },
        )
    }
}

private fun HealthMessage.textRes(): Int = when (this) {
    HealthMessage.HEADPHONES -> R.string.health_msg_headphones
    HealthMessage.AUDIO_BUSY -> R.string.msg_audio_busy
    HealthMessage.INTERRUPTED -> R.string.health_msg_interrupted
    HealthMessage.TEST_FAILED -> R.string.health_msg_failed
    HealthMessage.NO_PERMISSION -> R.string.health_msg_permission
}

@Composable
private fun StartCard(hasResult: Boolean, onStart: () -> Unit) {
    SectionCard(
        title = stringResource(R.string.health_prepare_title),
        body = stringResource(R.string.health_prepare_body, HealthCheckSpec.TOTAL_MS / 1000),
    ) {
        Button(
            onClick = onStart,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp),
        ) {
            Icon(Icons.Filled.Favorite, contentDescription = null, modifier = Modifier.width(20.dp))
            Text(
                text = stringResource(if (hasResult) R.string.health_run_again else R.string.health_run),
                modifier = Modifier.padding(start = 8.dp),
                style = MaterialTheme.typography.titleMedium,
            )
        }
        Text(
            text = stringResource(R.string.health_privacy_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun RunningCard(state: HealthUiState, onStop: () -> Unit) {
    SectionCard(
        title = stringResource(R.string.health_running_title),
        body = stringResource(R.string.health_running_body),
    ) {
        Text(
            text = stringResource(R.string.health_running_tone, state.currentHz),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
        )
        LinearProgressIndicator(
            progress = { state.progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
        )
        Button(
            onClick = onStop,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.error,
                contentColor = MaterialTheme.colorScheme.onError,
            ),
        ) { Text(stringResource(R.string.action_stop)) }
    }
}

@Composable
private fun ScoreCard(state: HealthUiState, score: Int, takenAt: Long) {
    val dateText = remember(takenAt) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(takenAt))
    }
    val delta = state.previousScore?.let { score - it }
    SectionCard(title = stringResource(R.string.health_score_title)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = score.toString(),
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = scoreColor(score),
            )
            Text(
                text = "/100",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
            )
        }
        Text(
            text = scoreLabel(score),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        if (delta != null) {
            val text = when {
                delta > 0 -> stringResource(R.string.health_delta_up, delta)
                delta < 0 -> stringResource(R.string.health_delta_down, -delta)
                else -> stringResource(R.string.health_delta_same)
            }
            Text(text = text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(text = dateText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (!state.hasReference) {
            Text(
                text = stringResource(R.string.health_no_reference_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun scoreLabel(score: Int): String = when {
    score >= 85 -> stringResource(R.string.health_label_clear)
    score >= 55 -> stringResource(R.string.health_label_slight)
    else -> stringResource(R.string.health_label_muffled)
}

@Composable
private fun scoreColor(score: Int): Color = when {
    score >= 85 -> MaterialTheme.colorScheme.tertiary
    score >= 55 -> Amber
    else -> MaterialTheme.colorScheme.error
}

@Composable
private fun BandsCard(bands: List<BandAssessment>, hasReference: Boolean) {
    SectionCard(
        title = stringResource(R.string.health_bands_title),
        body = stringResource(if (hasReference) R.string.health_bands_body_ref else R.string.health_bands_body),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            bands.forEach { band -> BandRow(band) }
        }
    }
}

@Composable
private fun BandRow(band: BandAssessment) {
    val color = when (band.status) {
        BandStatus.CLEAR -> MaterialTheme.colorScheme.tertiary
        BandStatus.WEAK -> Amber
        BandStatus.FAINT -> MaterialTheme.colorScheme.error
    }
    val statusText = when (band.status) {
        BandStatus.CLEAR -> stringResource(R.string.health_status_clear)
        BandStatus.WEAK -> stringResource(R.string.health_status_weak)
        BandStatus.FAINT -> stringResource(R.string.health_status_faint)
    }
    val drop = band.dropDb?.roundToInt()
    val description = stringResource(R.string.health_band_desc, band.hz, statusText)
    Column(
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.semantics(mergeDescendants = true) { contentDescription = description },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stringResource(R.string.orb_hz, band.hz),
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.width(72.dp),
            )
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelLarge,
                color = color,
                modifier = Modifier.weight(1f),
            )
            if (drop != null && drop > 0) {
                Text(
                    text = stringResource(R.string.health_drop_db, drop),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHighest),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(band.fraction.coerceIn(0.03f, 1f))
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color),
            )
        }
    }
}

@Composable
private fun RecommendationCard(recommendation: Recommendation, onStartFix: () -> Unit) {
    val body = when (recommendation.advice) {
        FixAdvice.CLEAR -> stringResource(R.string.health_rec_clear)
        FixAdvice.LOW_WEAK -> stringResource(R.string.health_rec_low)
        FixAdvice.HIGH_WEAK -> stringResource(R.string.health_rec_high)
        FixAdvice.BOTH_WEAK -> stringResource(R.string.health_rec_both)
        FixAdvice.SLIGHT -> stringResource(R.string.health_rec_slight)
    }
    SectionCard(title = stringResource(R.string.health_rec_title), body = body) {
        val mode = recommendation.mode
        if (mode != null) {
            Text(
                text = stringResource(
                    R.string.health_rec_plan,
                    stringResource(mode.titleRes()),
                    recommendation.durationSec / 60,
                ),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
            )
            Button(onClick = onStartFix, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.health_rec_action))
            }
        }
    }
}

@Composable
private fun ReferenceCard(state: HealthUiState, onSave: () -> Unit, onRemove: () -> Unit) {
    SectionCard(
        title = stringResource(R.string.health_ref_title),
        body = stringResource(if (state.hasReference) R.string.health_ref_body_saved else R.string.health_ref_body),
    ) {
        if (state.latest != null && !state.latestIsReference) {
            OutlinedButton(onClick = onSave, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(if (state.hasReference) R.string.health_ref_replace else R.string.health_ref_save))
            }
        }
        if (state.latestIsReference) {
            Text(
                text = stringResource(R.string.health_ref_is_latest),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.tertiary,
            )
        }
        if (state.hasReference) {
            TextButton(onClick = onRemove) { Text(stringResource(R.string.health_ref_remove)) }
        }
    }
}

@Composable
private fun TrendCard(state: HealthUiState) {
    val scores = state.trend.map { it.score }
    SectionCard(
        title = stringResource(R.string.health_trend_title),
        body = stringResource(R.string.health_trend_body, scores.size),
    ) {
        ScoreChart(
            values = scores,
            description = stringResource(R.string.health_trend_desc, scores.first(), scores.last()),
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
        )
    }
}

@Composable
private fun ShareButton(text: String) {
    val context = LocalContext.current
    val chooserTitle = stringResource(R.string.health_share)
    OutlinedButton(
        onClick = {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(send, chooserTitle))
        },
        modifier = Modifier.fillMaxWidth(),
    ) {
        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.width(18.dp))
        Text(text = chooserTitle, modifier = Modifier.padding(start = 8.dp))
    }
}
