package com.speakercorepurger.app.ui.tools

import android.Manifest
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speakercorepurger.app.R
import com.speakercorepurger.app.audio.CUSTOM_MAX_HZ
import com.speakercorepurger.app.audio.CUSTOM_MIN_HZ
import com.speakercorepurger.app.audio.SweepVoice
import com.speakercorepurger.app.ui.SpectrumUiState
import com.speakercorepurger.app.ui.SpectrumViewModel
import com.speakercorepurger.app.ui.ToolMessage
import com.speakercorepurger.app.ui.ToolPlayback
import com.speakercorepurger.app.ui.ToolsViewModel
import com.speakercorepurger.app.ui.common.MessageBanner
import com.speakercorepurger.app.ui.common.SectionCard
import com.speakercorepurger.app.ui.common.SpectrumBars
import com.speakercorepurger.app.ui.formatClock
import com.speakercorepurger.app.ui.notificationPermissionRequired
import com.speakercorepurger.app.ui.rememberPermissionRequest
import com.speakercorepurger.app.ui.purge.LiveVisualizer
import kotlinx.coroutines.delay
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

private val PRESETS_HZ = listOf(150, 440, 1_000, 5_000, 10_000)
private val DRYING_MINUTES = listOf(15, 30, 60, 120)

@Composable
fun ToolsScreen(
    vm: ToolsViewModel,
    spectrum: SpectrumViewModel,
    programCount: Int,
    onOpenPrograms: () -> Unit,
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val spectrumState by spectrum.uiState.collectAsStateWithLifecycle()
    var pendingMinutes by remember { mutableIntStateOf(0) }
    var notificationsOff by remember { mutableStateOf(false) }

    val askNotifications = rememberPermissionRequest(
        permission = Manifest.permission.POST_NOTIFICATIONS,
        required = notificationPermissionRequired,
    ) { granted ->
        notificationsOff = !granted
        vm.startDrying(pendingMinutes)
    }
    val askMicrophone = rememberPermissionRequest(Manifest.permission.RECORD_AUDIO) { granted ->
        if (granted) spectrum.start() else spectrum.reportFailure()
    }

    // Leaving the screen always stops the sound and the microphone.
    DisposableEffect(Unit) {
        onDispose {
            vm.stop()
            spectrum.stop()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column {
            Text(
                text = stringResource(R.string.tools_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = stringResource(R.string.tools_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        state.message?.let { message ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = stringResource(message.textRes()),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = vm::dismissMessage) { Text(stringResource(R.string.action_dismiss)) }
                }
            }
        }

        ToneTesterCard(
            hz = state.toneHz,
            playing = state.playing == ToolPlayback.TONE,
            level = state.level,
            onHz = vm::setToneHz,
            onToggle = vm::toggleTone,
        )

        SweepCard(
            playing = state.playing == ToolPlayback.SWEEP,
            step = state.sweepStep,
            hz = state.currentHz,
            level = state.level,
            onToggle = vm::toggleSweep,
        )

        SpectrumCard(
            state = spectrumState,
            onStart = askMicrophone,
            onStop = spectrum::stop,
            onDismissFailure = spectrum::dismissFailure,
        )

        DryingCard(
            endsAt = state.dryingEndsAt,
            onStart = { minutes ->
                pendingMinutes = minutes
                askNotifications()
            },
            onCancel = vm::cancelDrying,
            notificationsOff = notificationsOff,
        )

        SectionCard(
            title = stringResource(R.string.tool_programs_title),
            body = stringResource(R.string.tool_programs_body),
        ) {
            OutlinedButton(onClick = onOpenPrograms, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.tool_programs_open, programCount))
            }
        }
    }
}

private fun ToolMessage.textRes(): Int = when (this) {
    ToolMessage.HEADPHONES_CONNECTED -> R.string.msg_headphones_connected
    ToolMessage.AUDIO_ERROR -> R.string.msg_audio_error
    ToolMessage.AUDIO_BUSY -> R.string.msg_audio_busy
    ToolMessage.INTERRUPTED -> R.string.msg_interrupted
}

@Composable
private fun ToolCard(title: String, body: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ToneTesterCard(
    hz: Float,
    playing: Boolean,
    level: Float,
    onHz: (Float) -> Unit,
    onToggle: () -> Unit,
) {
    val logMin = ln(CUSTOM_MIN_HZ)
    val logMax = ln(CUSTOM_MAX_HZ)
    var draft by remember(hz) { androidx.compose.runtime.mutableFloatStateOf(hz) }

    ToolCard(
        title = stringResource(R.string.tool_tone_title),
        body = stringResource(R.string.tool_tone_body),
    ) {
        Text(
            text = stringResource(R.string.custom_frequency_label, draft.roundToInt()),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
        )
        Slider(
            value = (ln(draft) - logMin) / (logMax - logMin),
            onValueChange = { draft = exp(logMin + it * (logMax - logMin)) },
            onValueChangeFinished = { onHz(draft) },
            valueRange = 0f..1f,
            modifier = Modifier.semantics { contentDescription = "${draft.roundToInt()} Hz" },
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PRESETS_HZ.forEach { preset ->
                FilterChip(
                    selected = draft.roundToInt() == preset,
                    onClick = { draft = preset.toFloat(); onHz(preset.toFloat()) },
                    label = { Text(stringResource(R.string.orb_hz, preset)) },
                )
            }
        }
        if (playing) {
            LiveVisualizer(
                level = level,
                hz = hz.roundToInt(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
            )
        }
        Button(onClick = onToggle, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(if (playing) R.string.action_stop else R.string.tool_tone_play))
        }
    }
}

@Composable
private fun SweepCard(playing: Boolean, step: Int, hz: Int, level: Float, onToggle: () -> Unit) {
    ToolCard(
        title = stringResource(R.string.tool_sweep_title),
        body = stringResource(R.string.tool_sweep_body),
    ) {
        if (playing) {
            Text(
                text = stringResource(R.string.tool_sweep_step, step.coerceAtLeast(1), SweepVoice.STEP_COUNT, hz),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
            )
            LinearProgressIndicator(
                progress = { step.coerceAtLeast(1) / SweepVoice.STEP_COUNT.toFloat() },
                modifier = Modifier.fillMaxWidth(),
            )
            LiveVisualizer(
                level = level,
                hz = hz,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
            )
        }
        Button(onClick = onToggle, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(if (playing) R.string.action_stop else R.string.tool_sweep_start))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DryingCard(endsAt: Long, onStart: (Int) -> Unit, onCancel: () -> Unit, notificationsOff: Boolean) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(endsAt) {
        while (endsAt > 0L) {
            now = System.currentTimeMillis()
            if (now >= endsAt) break
            delay(1_000)
        }
    }
    val remainingSec = if (endsAt > 0L) ((endsAt - now + 999) / 1000).toInt().coerceAtLeast(0) else 0
    val running = endsAt > 0L && remainingSec > 0
    val finished = endsAt > 0L && remainingSec == 0

    ToolCard(
        title = stringResource(R.string.tool_dry_title),
        body = stringResource(R.string.tool_dry_body),
    ) {
        when {
            running -> {
                Text(
                    text = formatDryingClock(remainingSec),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.tool_dry_cancel))
                }
            }
            finished -> {
                Text(
                    text = stringResource(R.string.tool_dry_done),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.tertiary,
                )
                Button(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.action_done))
                }
            }
            else -> {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    DRYING_MINUTES.forEach { minutes ->
                        FilterChip(
                            selected = false,
                            onClick = { onStart(minutes) },
                            label = { Text(dryingLabel(minutes)) },
                        )
                    }
                }
            }
        }
        if (notificationsOff && running) {
            Text(
                text = stringResource(R.string.tool_dry_notifications_off),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = stringResource(R.string.tool_dry_tips),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.widthIn(max = 560.dp),
        )
    }
}

@Composable
private fun dryingLabel(minutes: Int): String =
    if (minutes >= 60) stringResource(R.string.duration_hours, minutes / 60) else stringResource(R.string.duration_minutes, minutes)

private fun formatDryingClock(totalSeconds: Int): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else formatClock(totalSeconds)
}

@Composable
private fun SpectrumCard(
    state: SpectrumUiState,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onDismissFailure: () -> Unit,
) {
    ToolCard(
        title = stringResource(R.string.tool_spectrum_title),
        body = stringResource(R.string.tool_spectrum_body),
    ) {
        if (state.failed) {
            MessageBanner(text = stringResource(R.string.tool_spectrum_failed), onDismiss = onDismissFailure)
        }
        val frame = state.frame
        if (state.listening && frame != null) {
            SpectrumBars(
                bars = frame.bars,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(96.dp),
            )
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (frame.peakHz > 0) {
                        stringResource(R.string.tool_spectrum_peak, frame.peakHz)
                    } else {
                        stringResource(R.string.tool_spectrum_no_peak)
                    },
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = stringResource(R.string.tool_spectrum_level, frame.levelDb.roundToInt()),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                text = stringResource(R.string.tool_spectrum_scale),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Button(
            onClick = if (state.listening) onStop else onStart,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(stringResource(if (state.listening) R.string.action_stop else R.string.tool_spectrum_start))
        }
    }
}
