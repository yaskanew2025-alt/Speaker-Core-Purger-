package com.speakercorepurger.app.audio

import android.media.AudioRecord
import com.speakercorepurger.app.data.HealthBand
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.min

/**
 * Plays a short series of test tones through the speaker while listening through the microphone,
 * then measures how loudly each tone arrived. The audio is analysed in memory and discarded; it is
 * never written to a file or sent anywhere.
 */
class SpeakerHealthCheck(private val engine: ToneEngine) {

    /**
     * Runs the test. The caller must already hold the RECORD_AUDIO permission. Progress is a
     * fraction from 0 to 1. Throws [AudioFailureException] if the microphone or speaker can not be used.
     */
    suspend fun run(onProgress: (progress: Float, hz: Int) -> Unit): List<HealthBand> = coroutineScope {
        val record = Mic.open()
        val capacity = (HealthCheckSpec.TOTAL_MS / 1000.0 * SAMPLE_RATE).toInt() + SAMPLE_RATE
        val data = ShortArray(capacity)
        var filled = 0
        val stopping = AtomicBoolean(false)
        var reader: Job? = null
        var readFailure: AudioFailureException? = null

        try {
            record.startRecording()
            if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                throw AudioFailureException("Microphone could not start")
            }
            reader = launch(Dispatchers.IO) {
                val chunk = ShortArray(2_048)
                while (isActive && !stopping.get() && filled < capacity) {
                    val count = record.read(chunk, 0, min(chunk.size, capacity - filled))
                    if (count < 0) {
                        if (!stopping.get()) readFailure = AudioFailureException("Microphone read failed ($count)")
                        break
                    }
                    if (count > 0) {
                        System.arraycopy(chunk, 0, data, filled, count)
                        filled += count
                    }
                }
            }

            val total = HealthCheckSpec.TOTAL_MS.toFloat()
            engine.playVoice(HealthVoice(), HealthCheckSpec.TOTAL_MS) { playedMs, hz, _ ->
                onProgress((playedMs / total).coerceIn(0f, 1f), hz.toInt())
            }
            delay(250)
        } finally {
            stopping.set(true)
            runCatching { record.stop() }
            withContext(NonCancellable) { reader?.join() }
            record.release()
        }

        readFailure?.let { throw it }
        val length = filled
        if (length < SAMPLE_RATE * 2) throw AudioFailureException("Not enough microphone data")
        var loudest = 0
        for (i in 0 until length) loudest = maxOf(loudest, abs(data[i].toInt()))
        if (loudest < MIN_SIGNAL) throw AudioFailureException("Microphone returned silence")

        withContext(Dispatchers.Default) {
            HealthAnalyzer.analyze(data, length, HealthCheckSpec.FREQS_HZ, SAMPLE_RATE)
        }
    }

    private companion object {
        const val SAMPLE_RATE = Mic.SAMPLE_RATE
        const val MIN_SIGNAL = 4
    }
}
