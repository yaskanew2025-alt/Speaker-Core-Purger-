package com.speakercorepurger.app.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.speakercorepurger.app.R

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.semantics { heading() },
        )
        if (subtitle != null) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** A titled card with a short description and free content below it. */
@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    body: String? = null,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.semantics { heading() },
            )
            if (body != null) {
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            content()
        }
    }
}

/** Error banner with a dismiss button. */
@Composable
fun MessageBanner(text: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
        modifier = modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Warning, contentDescription = null)
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
            )
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_dismiss)) }
        }
    }
}

/**
 * Line chart of values between 0 and 100 over equally spaced points. Draws nothing for fewer than
 * two points. [description] is read out by screen readers.
 */
@Composable
fun ScoreChart(values: List<Int>, description: String, modifier: Modifier = Modifier) {
    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier = modifier.semantics { contentDescription = description }) {
        val w = size.width
        val h = size.height
        for (g in 0..2) {
            val y = h * g / 2f
            drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }
        if (values.size < 2) return@Canvas
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = w * i / (values.size - 1).toFloat()
            val y = h * (1f - v.coerceIn(0, 100) / 100f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, line, style = Stroke(width = 5f))
        values.forEachIndexed { i, v ->
            val x = w * i / (values.size - 1).toFloat()
            val y = h * (1f - v.coerceIn(0, 100) / 100f)
            drawCircle(line, radius = 7f, center = Offset(x, y))
        }
    }
}

/** Seven vertical bars (oldest left). The tallest bar fills the height; empty days show a small stub. */
@Composable
fun WeekBars(seconds: List<Int>, description: String, modifier: Modifier = Modifier) {
    val bar = MaterialTheme.colorScheme.primary
    val empty = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier = modifier.semantics { contentDescription = description }) {
        val count = seconds.size
        if (count == 0) return@Canvas
        val maxValue = (seconds.maxOrNull() ?: 0).coerceAtLeast(1)
        val gap = size.width / (count * 3f)
        val barWidth = (size.width - gap * (count - 1)) / count
        seconds.forEachIndexed { i, value ->
            val fraction = if (value <= 0) 0.04f else (value / maxValue.toFloat()).coerceIn(0.08f, 1f)
            val barHeight = size.height * fraction
            drawRoundRect(
                color = if (value <= 0) empty else bar,
                topLeft = Offset(i * (barWidth + gap), size.height - barHeight),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 4f, barWidth / 4f),
            )
        }
    }
}

/** Bars of a live spectrum (values 0 to 1). */
@Composable
fun SpectrumBars(bars: FloatArray, modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.primary
    Canvas(modifier = modifier) {
        val count = bars.size
        if (count == 0) return@Canvas
        val gap = size.width / (count * 3f)
        val barWidth = (size.width - gap * (count - 1)) / count
        bars.forEachIndexed { i, value ->
            val fraction = value.coerceIn(0.02f, 1f)
            val barHeight = size.height * fraction
            drawRoundRect(
                color = color.copy(alpha = 0.4f + 0.6f * fraction),
                topLeft = Offset(i * (barWidth + gap), size.height - barHeight),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 3f, barWidth / 3f),
            )
        }
    }
}

