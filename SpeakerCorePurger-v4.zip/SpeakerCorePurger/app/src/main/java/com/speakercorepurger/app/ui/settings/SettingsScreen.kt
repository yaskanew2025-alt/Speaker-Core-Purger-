package com.speakercorepurger.app.ui.settings

import android.Manifest
import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speakercorepurger.app.BuildConfig
import com.speakercorepurger.app.R
import com.speakercorepurger.app.ads.AdsManager
import com.speakercorepurger.app.data.ThemeMode
import com.speakercorepurger.app.ui.MainViewModel
import com.speakercorepurger.app.ui.findActivity
import com.speakercorepurger.app.ui.notificationPermissionRequired
import com.speakercorepurger.app.ui.rememberPermissionRequest

@Composable
fun SettingsScreen(
    vm: MainViewModel,
    ads: AdsManager,
    onOpenGuide: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val privacyRequired by ads.privacyOptionsRequired.collectAsStateWithLifecycle()
    val current = settings ?: return
    val context = LocalContext.current
    var confirmClearHealth by rememberSaveable { mutableStateOf(false) }
    var reminderBlocked by rememberSaveable { mutableStateOf(false) }
    val askNotifications = rememberPermissionRequest(
        permission = Manifest.permission.POST_NOTIFICATIONS,
        required = notificationPermissionRequired,
    ) { granted ->
        reminderBlocked = !granted
        vm.setWeeklyReminder(granted)
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = stringResource(R.string.settings_title),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.semantics { heading() },
            )

            SettingsGroup(title = stringResource(R.string.settings_section_appearance)) {
                Column(modifier = Modifier.selectableGroup()) {
                    ThemeOption(
                        label = stringResource(R.string.settings_theme_system),
                        selected = current.theme == ThemeMode.SYSTEM,
                        onClick = { vm.setTheme(ThemeMode.SYSTEM) },
                    )
                    ThemeOption(
                        label = stringResource(R.string.settings_theme_light),
                        selected = current.theme == ThemeMode.LIGHT,
                        onClick = { vm.setTheme(ThemeMode.LIGHT) },
                    )
                    ThemeOption(
                        label = stringResource(R.string.settings_theme_dark),
                        selected = current.theme == ThemeMode.DARK,
                        onClick = { vm.setTheme(ThemeMode.DARK) },
                    )
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    SwitchRow(
                        title = stringResource(R.string.settings_dynamic_title),
                        description = stringResource(R.string.settings_dynamic_desc),
                        checked = current.dynamicColor,
                        onCheckedChange = vm::setDynamicColor,
                    )
                }
            }

            SettingsGroup(title = stringResource(R.string.settings_section_purge)) {
                SwitchRow(
                    title = stringResource(R.string.settings_vibrate_title),
                    description = stringResource(R.string.settings_vibrate_desc),
                    checked = current.vibrate,
                    onCheckedChange = vm::setVibrate,
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                SwitchRow(
                    title = stringResource(R.string.settings_auto_volume_title),
                    description = stringResource(R.string.settings_auto_volume_desc),
                    checked = current.autoMaxVolume,
                    onCheckedChange = vm::setAutoMaxVolume,
                )
            }

            SettingsGroup(title = stringResource(R.string.settings_section_health)) {
                SwitchRow(
                    title = stringResource(R.string.settings_reminder_title),
                    description = stringResource(
                        if (reminderBlocked && !current.weeklyReminder) {
                            R.string.settings_reminder_blocked
                        } else {
                            R.string.settings_reminder_desc
                        },
                    ),
                    checked = current.weeklyReminder,
                    onCheckedChange = { enabled ->
                        if (enabled) {
                            askNotifications()
                        } else {
                            reminderBlocked = false
                            vm.setWeeklyReminder(false)
                        }
                    },
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                ClickRow(
                    title = stringResource(R.string.settings_clear_health_title),
                    description = stringResource(R.string.settings_clear_health_desc),
                    onClick = { confirmClearHealth = true },
                )
            }

            SettingsGroup(title = stringResource(R.string.settings_section_help)) {
                ClickRow(
                    title = stringResource(R.string.settings_guide),
                    description = stringResource(R.string.settings_guide_desc),
                    onClick = onOpenGuide,
                )
                if (privacyRequired) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    ClickRow(
                        title = stringResource(R.string.settings_privacy_options),
                        description = stringResource(R.string.settings_privacy_options_desc),
                        onClick = { context.findActivity()?.let { ads.showPrivacyOptions(it) } },
                    )
                }
            }

            Text(
                text = stringResource(R.string.settings_version, BuildConfig.VERSION_NAME),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }

    if (confirmClearHealth) {
        AlertDialog(
            onDismissRequest = { confirmClearHealth = false },
            title = { Text(stringResource(R.string.health_clear_title)) },
            text = { Text(stringResource(R.string.health_clear_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmClearHealth = false
                        vm.clearHealthData()
                    },
                ) { Text(stringResource(R.string.health_clear_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearHealth = false }) { Text(stringResource(R.string.action_cancel)) }
            },
        )
    }
}

@Composable
private fun SettingsGroup(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.semantics { heading() },
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        ) {
            Column(modifier = Modifier.padding(vertical = 4.dp)) { content() }
        }
    }
}

@Composable
private fun ThemeOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(start = 16.dp),
        )
    }
}

@Composable
private fun SwitchRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onCheckedChange)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = null,
            modifier = Modifier.padding(start = 16.dp),
        )
    }
}

@Composable
private fun ClickRow(title: String, description: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(
            description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
