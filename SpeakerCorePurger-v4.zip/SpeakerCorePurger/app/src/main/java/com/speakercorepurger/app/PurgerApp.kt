package com.speakercorepurger.app

import android.app.Application
import com.speakercorepurger.app.ads.AdsManager
import com.speakercorepurger.app.data.HealthRepository
import com.speakercorepurger.app.data.HistoryRepository
import com.speakercorepurger.app.data.ProgramRepository
import com.speakercorepurger.app.data.SettingsRepository

class PurgerApp : Application() {
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
    val historyRepository: HistoryRepository by lazy { HistoryRepository(this) }
    val healthRepository: HealthRepository by lazy { HealthRepository(this) }
    val programRepository: ProgramRepository by lazy { ProgramRepository(this) }
    val ads: AdsManager by lazy { AdsManager(this) }
}
