package com.speakercorepurger.app.data

data class PurgeSession(
    /** Epoch millis when the purge started; also used as a unique key. */
    val startedAt: Long,
    val modeId: String,
    val plannedSec: Int,
    val playedSec: Int,
    val completed: Boolean,
    /** Only set for custom-tone sessions. */
    val customHz: Int?,
    /** Name of the saved program that was played, or null for the built-in modes. */
    val label: String? = null,
)
