package com.speakercorepurger.app.logic

import com.speakercorepurger.app.data.BandStatus
import com.speakercorepurger.app.data.HealthAssessment
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

object HealthReport {
    fun label(score: Int): String = when {
        score >= RecommendationEngine.CLEAR_SCORE -> "Clear"
        score >= 55 -> "Slightly muffled"
        else -> "Muffled"
    }

    /** Plain-text report of one check; [previousScore] is the score of the check before it, if any. */
    fun toText(
        assessment: HealthAssessment,
        previousScore: Int?,
        zone: TimeZone = TimeZone.getDefault(),
    ): String {
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = zone }
        val score = assessment.score
        val out = StringBuilder()
        out.append("Speaker Core Purger - speaker health check\n")
        out.append(format.format(Date(assessment.result.takenAt))).append('\n')
        out.append("Score: ").append(score).append("/100 (").append(label(score)).append(")\n")
        if (previousScore != null) {
            val delta = score - previousScore
            out.append("Change since the previous check: ").append(if (delta > 0) "+" else "").append(delta).append(" points\n")
        }
        out.append(if (assessment.hasReference) "Compared with your saved clean reference.\n" else "No clean reference saved yet.\n")
        out.append('\n')
        for ((band, raw) in assessment.bands.zip(assessment.result.bands)) {
            val status = when (band.status) {
                BandStatus.CLEAR -> "clear"
                BandStatus.WEAK -> "weak"
                BandStatus.FAINT -> "barely heard"
            }
            out.append(band.hz).append(" Hz: ").append(raw.snrDb.roundToInt()).append(" dB above room noise")
            band.dropDb?.let { out.append(", ").append(describeDrop(it)).append(" than reference") }
            out.append(" (").append(status).append(")\n")
        }
        out.append("\nMeasured with the phone's own microphone. Room noise, volume and phone position affect the result.")
        return out.toString()
    }

    private fun describeDrop(drop: Float): String {
        val rounded = drop.roundToInt()
        return if (rounded >= 0) "$rounded dB quieter" else "${-rounded} dB louder"
    }
}
