package com.speakercorepurger.app.logic

import com.speakercorepurger.app.audio.PurgeMode
import com.speakercorepurger.app.data.BandAssessment
import com.speakercorepurger.app.data.BandStatus
import com.speakercorepurger.app.data.HealthAssessment

enum class FixAdvice { CLEAR, LOW_WEAK, HIGH_WEAK, BOTH_WEAK, SLIGHT }

/**
 * Suggested next step after a health check. It is a rule based on which test tones came through
 * weakly, not a diagnosis: low tones (up to 1 kHz) are matched with the Water mode, higher tones with
 * the Dust mode, and a weak result in both with Deep clean.
 */
data class Recommendation(
    val advice: FixAdvice,
    val mode: PurgeMode?,
    val durationSec: Int,
    val weakHz: List<Int>,
)

object RecommendationEngine {
    const val CLEAR_SCORE = 85
    private const val LOW_MAX_HZ = 1_000
    private const val GROUP_WEAK_BELOW = 0.67f

    fun recommend(assessment: HealthAssessment): Recommendation {
        val bands = assessment.bands
        if (bands.isEmpty()) return Recommendation(FixAdvice.SLIGHT, PurgeMode.DEEP, 60, emptyList())
        val weak = bands.filter { it.status != BandStatus.CLEAR }.map { it.hz }

        if (assessment.score >= CLEAR_SCORE && bands.none { it.status == BandStatus.FAINT }) {
            return Recommendation(FixAdvice.CLEAR, null, 0, weak)
        }

        val lowWeak = average(bands.filter { it.hz <= LOW_MAX_HZ }) < GROUP_WEAK_BELOW
        val highWeak = average(bands.filter { it.hz > LOW_MAX_HZ }) < GROUP_WEAK_BELOW
        return when {
            lowWeak && highWeak -> Recommendation(FixAdvice.BOTH_WEAK, PurgeMode.DEEP, 120, weak)
            highWeak -> Recommendation(FixAdvice.HIGH_WEAK, PurgeMode.DUST, 60, weak)
            lowWeak -> Recommendation(FixAdvice.LOW_WEAK, PurgeMode.WATER, 60, weak)
            else -> Recommendation(FixAdvice.SLIGHT, PurgeMode.DEEP, 60, weak)
        }
    }

    private fun average(bands: List<BandAssessment>): Float =
        if (bands.isEmpty()) 1f else bands.map { it.fraction }.average().toFloat()
}
