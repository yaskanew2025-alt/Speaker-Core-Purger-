package com.speakercorepurger.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.speakercorepurger.app.PurgerApp
import com.speakercorepurger.app.data.ProgramIssue
import com.speakercorepurger.app.data.SavedProgram
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProgramsViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = (application as PurgerApp).programRepository

    /** `null` while loading. */
    val programs: StateFlow<List<SavedProgram>?> = repo.programs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /** Saves a program; [onResult] receives the problem that stopped the save, or null on success. */
    fun save(program: SavedProgram, onResult: (ProgramIssue?) -> Unit) {
        viewModelScope.launch { onResult(repo.save(program)) }
    }

    fun delete(id: Long) {
        viewModelScope.launch { repo.delete(id) }
    }
}
