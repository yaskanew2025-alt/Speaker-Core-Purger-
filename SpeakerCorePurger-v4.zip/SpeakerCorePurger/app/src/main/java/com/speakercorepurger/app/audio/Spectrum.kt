package com.speakercorepurger.app.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/** In-place radix-2 FFT helpers. */
object Fft {
    /** Returns true when [n] is a positive power of two. */
    fun isPowerOfTwo(n: Int): Boolean = n > 0 && (n and (n - 1)) == 0

    /** Transforms [re] and [im] in place. Their size must be a power of two. */
    fun transform(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        require(im.size == n && isPowerOfTwo(n)) { "size must be a power of two" }
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val angle = -2.0 * PI / len
            val wRe = cos(angle)
            val wIm = sin(angle)
            var i = 0
            while (i < n) {
                var curRe = 1.0
                var curIm = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k
                    val b = a + len / 2
                    val tRe = re[b] * curRe - im[b] * curIm
                    val tIm = re[b] * curIm + im[b] * curRe
                    re[b] = re[a] - tRe
                    im[b] = im[a] - tIm
                    re[a] += tRe
                    im[a] += tIm
                    val nextRe = curRe * wRe - curIm * wIm
                    curIm = curRe * wIm + curIm * wRe
                    curRe = nextRe
                }
                i += len
            }
            len = len shl 1
        }
    }
}

/** One analysed slice of microphone audio. */
class SpectrumFrame(
    /** Bar heights from 0 to 1, from low to high frequency. */
    val bars: FloatArray,
    /** Frequency of the strongest clear tone in Hz, or 0 when nothing stands out. */
    val peakHz: Int,
    /** Overall level in dB relative to full scale (about -90 when silent, 0 at the loudest). */
    val levelDb: Float,
)

/**
 * Turns blocks of microphone samples into a log-spaced spectrum for display. Nothing is stored:
 * every call only looks at the block it is given.
 */
class SpectrumAnalyzer(
    private val size: Int = 2_048,
    private val sampleRate: Int = 44_100,
    private val barCount: Int = 24,
) {
    init {
        require(Fft.isPowerOfTwo(size)) { "size must be a power of two" }
    }

    private val window = DoubleArray(size) { 0.5 - 0.5 * cos(2.0 * PI * it / (size - 1)) }
    private val windowSum = window.sum()
    private val re = DoubleArray(size)
    private val im = DoubleArray(size)
    private val binHz = sampleRate.toDouble() / size

    /** Analyses the first [size] samples of [samples]; shorter input is padded with silence. */
    fun analyze(samples: ShortArray, count: Int = samples.size): SpectrumFrame {
        val usable = minOf(count, samples.size)
        var sumSquares = 0.0
        for (i in 0 until size) {
            val x = if (i < usable) samples[i] / 32768.0 else 0.0
            sumSquares += x * x
            re[i] = x * window[i]
            im[i] = 0.0
        }
        Fft.transform(re, im)

        val half = size / 2
        val amplitude = DoubleArray(half) { 2.0 * sqrt(re[it] * re[it] + im[it] * im[it]) / windowSum }

        val bars = FloatArray(barCount)
        val logMin = ln(MIN_HZ)
        val logMax = ln(MAX_HZ)
        for (bar in 0 until barCount) {
            val lo = kotlin.math.exp(logMin + (logMax - logMin) * bar / barCount)
            val hi = kotlin.math.exp(logMin + (logMax - logMin) * (bar + 1) / barCount)
            val first = (lo / binHz).toInt().coerceIn(1, half - 1)
            val last = maxOf(first, (hi / binHz).toInt()).coerceAtMost(half - 1)
            var best = 0.0
            for (bin in first..last) if (amplitude[bin] > best) best = amplitude[bin]
            bars[bar] = ((toDb(best) - FLOOR_DB) / (CEILING_DB - FLOOR_DB)).toFloat().coerceIn(0f, 1f)
        }

        val firstBin = (PEAK_MIN_HZ / binHz).toInt().coerceAtLeast(2)
        val lastBin = (PEAK_MAX_HZ / binHz).toInt().coerceAtMost(half - 2)
        var peakBin = firstBin
        for (bin in firstBin..lastBin) if (amplitude[bin] > amplitude[peakBin]) peakBin = bin
        val peakHz = if (toDb(amplitude[peakBin]) >= PEAK_THRESHOLD_DB) {
            // Parabolic interpolation between neighbouring bins for sub-bin accuracy.
            val a = ln(amplitude[peakBin - 1] + 1e-12)
            val b = ln(amplitude[peakBin] + 1e-12)
            val c = ln(amplitude[peakBin + 1] + 1e-12)
            val denominator = a - 2 * b + c
            val shift = if (abs(denominator) < 1e-12) 0.0 else 0.5 * (a - c) / denominator
            ((peakBin + shift.coerceIn(-0.5, 0.5)) * binHz).toInt()
        } else {
            0
        }

        val rms = sqrt(sumSquares / size)
        return SpectrumFrame(bars, peakHz, toDb(rms).toFloat().coerceAtLeast(FLOOR_DB.toFloat()))
    }

    private fun toDb(value: Double): Double = 20.0 * log10(value + 1e-9)

    private companion object {
        const val MIN_HZ = 100.0
        const val MAX_HZ = 12_000.0
        const val PEAK_MIN_HZ = 80.0
        const val PEAK_MAX_HZ = 12_000.0
        const val FLOOR_DB = -90.0
        const val CEILING_DB = -20.0
        const val PEAK_THRESHOLD_DB = -60.0
    }
}
