package com.speakercorepurger.app.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.speakercorepurger.app.MainActivity
import com.speakercorepurger.app.R
import com.speakercorepurger.app.logic.ReminderTime

/** Notifications and alarms: the drying-timer alert and the weekly health-check reminder. */
object Notifier {
    private const val CHANNEL_TIMER = "timer"
    private const val CHANNEL_REMINDER = "reminder"
    private const val ID_TIMER = 101
    private const val ID_REMINDER = 102
    private const val REQUEST_DRYING = 201
    private const val REQUEST_REMINDER = 202
    private const val REQUEST_OPEN = 203

    /** True when the app may show notifications (always true before Android 13). */
    fun canNotify(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    private fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_TIMER,
                context.getString(R.string.channel_timer_name),
                NotificationManager.IMPORTANCE_HIGH,
            ).apply { description = context.getString(R.string.channel_timer_desc) },
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_REMINDER,
                context.getString(R.string.channel_reminder_name),
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply { description = context.getString(R.string.channel_reminder_desc) },
        )
    }

    private fun openAppIntent(context: Context, route: String): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_ROUTE, route)
        }
        return PendingIntent.getActivity(
            context,
            REQUEST_OPEN,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }

    private fun broadcast(context: Context, request: Int, receiver: Class<*>): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            request,
            Intent(context, receiver),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    // ---- Drying timer --------------------------------------------------------------------------

    /** Schedules an alarm for the drying timer. It uses the alarm-clock API, which needs no special permission. */
    fun scheduleDrying(context: Context, endsAt: Long) {
        val alarms = context.getSystemService(AlarmManager::class.java) ?: return
        val info = AlarmManager.AlarmClockInfo(endsAt, openAppIntent(context, MainActivity.ROUTE_TOOLS))
        alarms.setAlarmClock(info, broadcast(context, REQUEST_DRYING, DryingReceiver::class.java))
    }

    fun cancelDrying(context: Context) {
        val alarms = context.getSystemService(AlarmManager::class.java) ?: return
        alarms.cancel(broadcast(context, REQUEST_DRYING, DryingReceiver::class.java))
    }

    @SuppressLint("MissingPermission")
    fun showDryingDone(context: Context) {
        if (!canNotify(context)) return
        ensureChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_TIMER)
            .setSmallIcon(R.drawable.ic_stat_speaker)
            .setContentTitle(context.getString(R.string.notif_drying_title))
            .setContentText(context.getString(R.string.notif_drying_body))
            .setStyle(NotificationCompat.BigTextStyle().bigText(context.getString(R.string.notif_drying_body)))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(context, MainActivity.ROUTE_HEALTH))
            .build()
        NotificationManagerCompat.from(context).notify(ID_TIMER, notification)
    }

    // ---- Weekly reminder -----------------------------------------------------------------------

    /** Schedules the next weekly reminder. The system may deliver it a little late to save battery. */
    fun scheduleReminder(context: Context, nowMillis: Long = System.currentTimeMillis()) {
        val alarms = context.getSystemService(AlarmManager::class.java) ?: return
        alarms.setAndAllowWhileIdle(
            AlarmManager.RTC,
            ReminderTime.next(nowMillis),
            broadcast(context, REQUEST_REMINDER, ReminderReceiver::class.java),
        )
    }

    fun cancelReminder(context: Context) {
        val alarms = context.getSystemService(AlarmManager::class.java) ?: return
        alarms.cancel(broadcast(context, REQUEST_REMINDER, ReminderReceiver::class.java))
    }

    @SuppressLint("MissingPermission")
    fun showReminder(context: Context) {
        if (!canNotify(context)) return
        ensureChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDER)
            .setSmallIcon(R.drawable.ic_stat_speaker)
            .setContentTitle(context.getString(R.string.notif_reminder_title))
            .setContentText(context.getString(R.string.notif_reminder_body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(context, MainActivity.ROUTE_HEALTH))
            .build()
        NotificationManagerCompat.from(context).notify(ID_REMINDER, notification)
    }
}
