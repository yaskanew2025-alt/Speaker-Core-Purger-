package com.speakercorepurger.app.audio

import kotlin.math.PI
import kotlin.math.sin

const val CUSTOM_MIN_HZ = 100f
const val CUSTOM_MAX_HZ = 1000f
const val DEFAULT_CUSTOM_HZ = 165f

/** Allowed purge lengths in seconds. The last one is the "extended" length. */
val PURGE_DURATIONS_SEC = listOf(30, 60, 120, 300)
const val DEFAULT_DURATION_SEC = 60
const val FALLBACK_DURATION_SEC = 120
const val EXTENDED_DURATION_SEC = 300

/**
 * The tone programs the app can play. Every program is a pure function of time,
 * which keeps the audio engine simple and makes the programs easy to reason about.
 */
enum class PurgeMode(val id: String) {
    /** Slowly wobbling tone around 165 Hz, the frequency commonly used for water ejection. */
    WATER("water"),

    /** Triangle sweep between 120 and 520 Hz to shake dust loose. */
    DUST("dust"),

    /** 30-second cycle: water tone, upward sweep, then a mid-range sweep. */
    DEEP("deep"),

    /** One fixed frequency chosen by the user. */
    CUSTOM("custom");

    fun frequencyAt(tSec: Double, customHz: Float): Double = when (this) {
        WATER -> waterTone(tSec)
        DUST -> dustSweep(tSec)
        DEEP -> {
            val cycle = tSec % 30.0
            when {
                cycle < 10.0 -> waterTone(cycle)
                cycle < 20.0 -> lerp(120.0, 520.0, (cycle - 10.0) / 10.0)
                else -> lerp(300.0, 800.0, (cycle - 20.0) / 10.0)
            }
        }
        CUSTOM -> customHz.toDouble()
    }

    companion object {
        fun fromId(id: String?): PurgeMode = entries.firstOrNull { it.id == id } ?: WATER

        private fun waterTone(t: Double): Double = 165.0 + 12.0 * sin(2.0 * PI * 0.4 * t)

        private fun dustSweep(t: Double): Double {
            val position = (t % 12.0) / 12.0
            val triangle = if (position < 0.5) position * 2.0 else 2.0 - position * 2.0
            return lerp(120.0, 520.0, triangle)
        }

        private fun lerp(from: Double, to: Double, fraction: Double): Double =
            from + (to - from) * fraction.coerceIn(0.0, 1.0)
    }
}
