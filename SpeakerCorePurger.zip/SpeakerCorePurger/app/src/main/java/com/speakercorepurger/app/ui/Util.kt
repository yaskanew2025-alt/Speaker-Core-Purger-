package com.speakercorepurger.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.speakercorepurger.app.R
import com.speakercorepurger.app.audio.PurgeMode
import java.util.Locale

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Formats seconds as M:SS. */
fun formatClock(totalSeconds: Int): String {
    val s = totalSeconds.coerceAtLeast(0)
    return String.format(Locale.getDefault(), "%d:%02d", s / 60, s % 60)
}

/** Short duration label such as "30 s" or "2 min". */
@Composable
fun durationLabel(seconds: Int): String =
    if (seconds >= 60 && seconds % 60 == 0) {
        stringResource(R.string.duration_minutes, seconds / 60)
    } else {
        stringResource(R.string.duration_seconds, seconds)
    }

@StringRes
fun PurgeMode.titleRes(): Int = when (this) {
    PurgeMode.WATER -> R.string.mode_water_title
    PurgeMode.DUST -> R.string.mode_dust_title
    PurgeMode.DEEP -> R.string.mode_deep_title
    PurgeMode.CUSTOM -> R.string.mode_custom_title
}

@StringRes
fun PurgeMode.descriptionRes(): Int = when (this) {
    PurgeMode.WATER -> R.string.mode_water_desc
    PurgeMode.DUST -> R.string.mode_dust_desc
    PurgeMode.DEEP -> R.string.mode_deep_desc
    PurgeMode.CUSTOM -> R.string.mode_custom_desc
}

@StringRes
fun PurgeMessage.textRes(): Int = when (this) {
    PurgeMessage.HEADPHONES_CONNECTED -> R.string.msg_headphones_connected
    PurgeMessage.HEADPHONES_DURING -> R.string.msg_headphones_during
    PurgeMessage.AUDIO_ERROR -> R.string.msg_audio_error
    PurgeMessage.AUDIO_BUSY -> R.string.msg_audio_busy
    PurgeMessage.INTERRUPTED -> R.string.msg_interrupted
}
