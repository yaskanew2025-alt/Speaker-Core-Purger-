package com.speakercorepurger.app.audio

import kotlin.math.PI
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh
import kotlin.random.Random

private const val SR = 44_100.0
private const val TWO_PI = 2.0 * PI
private const val MAX_HARMONIC_HZ = 19_000.0

/**
 * A stateful sound generator. [next] must be called with strictly increasing times, one call per
 * output sample. [hz] is the frequency to show in the UI (centre frequency for noise).
 */
interface Voice {
    val hz: Double
    fun next(t: Double): Double
}

/** Oscillator with a fixed harmonic recipe; harmonics above ~19 kHz are skipped to avoid aliasing. */
private class HarmonicOsc(private val weights: DoubleArray) {
    private var phase = 0.0
    fun next(f: Double): Double {
        phase += TWO_PI * f / SR
        if (phase >= TWO_PI) phase -= TWO_PI
        var sum = 0.0
        var power = 0.0
        for (k in weights.indices) {
            val h = k + 1
            if (h * f < MAX_HARMONIC_HZ) {
                sum += weights[k] * sin(h * phase)
                power += weights[k] * weights[k]
            }
        }
        return if (power > 0.0) sum / sqrt(power) * 0.8 else 0.0
    }
}

/** Smooth on/off gate: [on] seconds of sound at the start of a period, with [ramp] second edges. */
private fun gate(pos: Double, on: Double, ramp: Double): Double = when {
    pos >= on -> 0.0
    pos < ramp -> pos / ramp
    pos > on - ramp -> (on - pos) / ramp
    else -> 1.0
}

private fun soft(x: Double): Double = tanh(x * 1.4)

class WaterVoice : Voice {
    private val osc = HarmonicOsc(doubleArrayOf(1.0, 0.7, 0.45, 0.25))
    override var hz = STEPS[0]
        private set

    override fun next(t: Double): Double {
        hz = STEPS[((t / STEP_SEC).toInt()) % STEPS.size]
        val g = gate(t % PULSE_SEC, PULSE_ON, 0.006)
        return soft(osc.next(hz) * g)
    }

    private companion object {
        const val STEP_SEC = 0.48
        const val PULSE_SEC = 0.12
        const val PULSE_ON = 0.085
        val STEPS = doubleArrayOf(160.0, 420.0, 230.0, 640.0, 300.0, 800.0, 190.0, 520.0, 350.0, 720.0, 260.0, 480.0)
    }
}

class DustVoice : Voice {
    private val osc = HarmonicOsc(doubleArrayOf(1.0, 0.55, 0.3))
    override var hz = STARTS[0]
        private set

    override fun next(t: Double): Double {
        val index = (t / PERIOD).toInt()
        val pos = t % PERIOD
        val f0 = STARTS[index % STARTS.size]
        val f1 = min(f0 * 1.5, 10_000.0)
        hz = f0 * (f1 / f0).pow(min(pos / CHIRP, 1.0))
        return soft(osc.next(hz) * gate(pos, CHIRP, 0.003))
    }

    private companion object {
        const val PERIOD = 0.14
        const val CHIRP = 0.09
        val STARTS = doubleArrayOf(2000.0, 3200.0, 5000.0, 7000.0, 2600.0, 4200.0, 6000.0, 6700.0)
    }
}

class PowerVoice : Voice {
    private var phase = 0.0
    override var hz = FREQS[0]
        private set

    override fun next(t: Double): Double {
        hz = FREQS[((t / 0.4).toInt()) % FREQS.size]
        phase += TWO_PI * hz / SR
        if (phase >= TWO_PI) phase -= TWO_PI
        // Hard-driven sine: close to a square wave, so it is much louder and harsher.
        return tanh(5.0 * sin(phase)) * gate(t % 0.2, 0.15, 0.004)
    }

    private companion object {
        val FREQS = doubleArrayOf(300.0, 2400.0, 150.0, 4800.0, 600.0, 9600.0, 1200.0, 6000.0)
    }
}

class NoiseVoice : Voice {
    private val rng = Random(1234)
    private var low = 0.0
    private var band = 0.0
    private var step = -1
    private var f = 0.0
    private var gain = 1.0
    override var hz = CENTERS[0]
        private set

    override fun next(t: Double): Double {
        val s = (t / STEP_SEC).toInt()
        if (s != step) {
            step = s
            hz = CENTERS[s % CENTERS.size]
            f = 2.0 * sin(PI * hz / SR)
            val fraction = min(1.0, (PI / 2.0) * (hz / Q) / (SR / 2.0))
            gain = 0.45 / (0.577 * sqrt(fraction))
        }
        val x = rng.nextDouble() * 2.0 - 1.0
        low += f * band
        val high = x - low - band / Q
        band += f * high
        return soft(band * gain * gate(t % STEP_SEC, 0.36, 0.02))
    }

    private companion object {
        const val STEP_SEC = 0.5
        const val Q = 1.5
        val CENTERS = doubleArrayOf(700.0, 1800.0, 3500.0, 6000.0, 2500.0, 5000.0, 1200.0, 7000.0)
    }
}

class CustomVoice(private val freq: Double) : Voice {
    private val osc = HarmonicOsc(doubleArrayOf(1.0, 0.6, 0.35))
    override val hz: Double get() = freq
    override fun next(t: Double): Double = soft(osc.next(freq))
}

class DeepVoice : Voice {
    private val voices = arrayOf(WaterVoice(), NoiseVoice(), DustVoice(), PowerVoice())
    private var active = 0
    override val hz: Double get() = voices[active].hz

    override fun next(t: Double): Double {
        val cycle = t % 40.0
        active = (cycle / 10.0).toInt().coerceIn(0, 3)
        return voices[active].next(cycle % 10.0)
    }
}

/** A clean sine tone with no harmonics, for the tone tester. */
class PureToneVoice(private val freq: Double) : Voice {
    private val osc = HarmonicOsc(doubleArrayOf(1.0))
    override val hz: Double get() = freq
    override fun next(t: Double): Double = osc.next(freq) * 0.9
}

/**
 * Steps through [STEP_COUNT] frequencies from 150 Hz to 10,000 Hz (log spaced), [STEP_SEC] seconds
 * each, so the listener can hear which ranges rattle, buzz or sound muffled.
 */
class SweepVoice : Voice {
    private val osc = HarmonicOsc(doubleArrayOf(1.0, 0.25))
    override var hz = frequencyOfStep(0)
        private set

    override fun next(t: Double): Double {
        val step = ((t / STEP_SEC).toInt()).coerceAtMost(STEP_COUNT - 1)
        hz = frequencyOfStep(step)
        return osc.next(hz) * gate(t - step * STEP_SEC, STEP_SEC - 0.1, 0.02)
    }

    companion object {
        const val STEP_COUNT = 12
        const val STEP_SEC = 2.5
        const val TOTAL_MS = (STEP_COUNT * STEP_SEC * 1000).toLong()

        fun frequencyOfStep(step: Int): Double {
            val fraction = step.coerceIn(0, STEP_COUNT - 1) / (STEP_COUNT - 1).toDouble()
            return 150.0 * (10_000.0 / 150.0).pow(fraction)
        }
    }
}
