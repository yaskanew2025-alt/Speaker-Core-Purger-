package com.speakercorepurger.app.ui

import android.graphics.Color as AndroidColor
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speakercorepurger.app.ads.AdsManager
import com.speakercorepurger.app.data.ThemeMode
import com.speakercorepurger.app.ui.onboarding.OnboardingScreen
import com.speakercorepurger.app.ui.theme.PurgerTheme

@Composable
fun PurgerRoot(main: MainViewModel, purge: PurgeViewModel, tools: ToolsViewModel, ads: AdsManager) {
    val settings by main.settings.collectAsStateWithLifecycle()
    val current = settings
    val systemDark = isSystemInDarkTheme()
    val dark = when (current?.theme ?: ThemeMode.SYSTEM) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    // Keep status/navigation bar icon colours readable when the in-app theme differs from the system.
    val context = LocalContext.current
    DisposableEffect(dark) {
        (context.findActivity() as? ComponentActivity)?.enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT) { dark },
            navigationBarStyle = SystemBarStyle.auto(
                AndroidColor.argb(0xE6, 0xFF, 0xFF, 0xFF),
                AndroidColor.argb(0x80, 0x1B, 0x1B, 0x1B),
            ) { dark },
        )
        onDispose { }
    }

    PurgerTheme(darkTheme = dark) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when {
                current == null -> Unit
                !current.onboardingDone -> OnboardingScreen(onFinished = { main.setOnboardingDone(true) })
                else -> AppScaffold(main = main, purge = purge, tools = tools, ads = ads)
            }
        }
    }
}
