package com.speakercorepurger.app

import android.media.AudioManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.speakercorepurger.app.ui.MainViewModel
import com.speakercorepurger.app.ui.PurgeViewModel
import com.speakercorepurger.app.ui.PurgerRoot
import com.speakercorepurger.app.ui.ToolsViewModel

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private val purgeViewModel: PurgeViewModel by viewModels()
    private val toolsViewModel: ToolsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val app = application as PurgerApp

        // Hardware volume keys control the media stream, which is what the purge plays on.
        volumeControlStream = AudioManager.STREAM_MUSIC

        app.ads.gatherConsentAndStart(this)

        setContent {
            PurgerRoot(
                main = mainViewModel,
                purge = purgeViewModel,
                tools = toolsViewModel,
                ads = app.ads,
            )
        }
    }

    override fun onStop() {
        super.onStop()
        // A purge only runs while the screen is visible. Rotation must not stop it.
        if (!isChangingConfigurations) {
            purgeViewModel.stop()
            toolsViewModel.stop()
        }
    }
}
